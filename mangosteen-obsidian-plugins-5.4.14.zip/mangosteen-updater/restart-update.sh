#!/bin/bash
set -Eeuo pipefail

VAULT_PATH=""
WAIT_PROCESS_ID=0
SKIP_RELAUNCH=0
REQUEST_QUIT=0
LAST_ERROR=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --vault-path) VAULT_PATH="${2:-}"; shift 2 ;;
    --wait-process-id) WAIT_PROCESS_ID="${2:-0}"; shift 2 ;;
    --skip-relaunch) SKIP_RELAUNCH=1; shift ;;
    --request-quit) REQUEST_QUIT=1; shift ;;
    *) echo "未知参数：$1" >&2; exit 2 ;;
  esac
done

[[ "$VAULT_PATH" == /* && -d "$VAULT_PATH" ]] || { echo "知识库路径无效" >&2; exit 2; }
UPDATER_ROOT="$VAULT_PATH/.mangosteen-updater"
STAGING="$UPDATER_ROOT/staging"
EXTRACTED="$STAGING/extracted"
PENDING="$STAGING/pending.json"
PLUGINS="$VAULT_PATH/.obsidian/plugins"
ENABLED="$VAULT_PATH/.obsidian/community-plugins.json"
BACKUP="$UPDATER_ROOT/backup"
COMPONENTS="$UPDATER_ROOT/components.tsv"
JOURNAL="$BACKUP/journal.tsv"
VERSION_FILE="$UPDATER_ROOT/version.txt"
RESULT="$UPDATER_ROOT/result.json"
TARGETS=(mangosteen-media-core mangosteen-claudian mangosteen-image mangosteen-video mangosteen-workbench mangosteen-updater)
LEGACY=(mangosteen-agent)

write_result() {
  python3 - "$RESULT" "$1" "$2" "${3:-}" <<'PY'
import json, os, sys
path, status, version, diagnostic = sys.argv[1:]
temporary = path + ".tmp"
with open(temporary, "w", encoding="utf-8") as handle:
    json.dump({"status": status, "version": version, "diagnostic": diagnostic}, handle, ensure_ascii=False)
    handle.write("\n")
os.replace(temporary, path)
PY
}

rollback() {
  [[ -f "$JOURNAL" ]] || return 0
  while IFS=$'\t' read -r plugin_id had_original; do
    [[ -n "$plugin_id" ]] || continue
    destination="$PLUGINS/$plugin_id"
    rm -rf "$destination"
    if [[ "$had_original" == "1" && -d "$BACKUP/plugins/$plugin_id" ]]; then
      /usr/bin/ditto "$BACKUP/plugins/$plugin_id" "$destination"
    fi
  done < "$JOURNAL"
  if [[ -f "$BACKUP/community-plugins.existed" ]]; then
    cp "$BACKUP/community-plugins.json" "$ENABLED"
  else
    rm -f "$ENABLED"
  fi
}

failed() {
  local status="${1:-1}" line="${2:-unknown}" command="${3:-unknown}"
  trap - ERR
  rollback || true
  local version diagnostic
  version="$(cat "$VERSION_FILE" 2>/dev/null || true)"
  diagnostic="$UPDATER_ROOT/mac-update-error.txt"
  {
    printf '山竹插件更新失败，旧版本已恢复。\n'
    [[ -n "$LAST_ERROR" ]] && printf '原因：%s\n' "$LAST_ERROR"
    printf '位置：第 %s 行\n命令：%s\n' "$line" "$command"
  } > "$diagnostic"
  write_result "failed" "$version" "$diagnostic" || true
  exit "$status"
}
trap 'failed "$?" "$LINENO" "$BASH_COMMAND"' ERR

[[ -f "$PENDING" && -d "$EXTRACTED" ]] || { echo "更新暂存文件不完整" >&2; exit 1; }
mkdir -p "$UPDATER_ROOT" "$PLUGINS"
rm -rf "$BACKUP"
mkdir -p "$BACKUP/plugins"
rm -f "$COMPONENTS" "$VERSION_FILE"

if validation_output="$(python3 - "$PENDING" "$EXTRACTED" "$COMPONENTS" "$VERSION_FILE" 2>&1 <<'PY'
import json, re, sys
from pathlib import Path
pending_path, extracted_path, components_path, version_path = map(Path, sys.argv[1:])
pending = json.loads(pending_path.read_text(encoding="utf-8-sig"))
components = pending.get("components")
allowed = {"mangosteen-media-core", "mangosteen-image", "mangosteen-video", "mangosteen-workbench", "mangosteen-updater", "mangosteen-claudian"}
if pending.get("schemaVersion") != 2 or not isinstance(components, dict) or set(components) != allowed:
    raise SystemExit("更新组件清单无效")
if pending.get("removeAfterVerify") != ["mangosteen-agent"]:
    raise SystemExit("旧插件迁移清单无效")
lines = []
for plugin_id in sorted(components):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", plugin_id):
        raise SystemExit("插件 ID 无效")
    manifest = json.loads((extracted_path / plugin_id / "manifest.json").read_text(encoding="utf-8-sig"))
    if manifest.get("id") != plugin_id or manifest.get("version") != components[plugin_id]:
        raise SystemExit("更新插件版本无效")
    if not (extracted_path / plugin_id / "main.js").is_file():
        raise SystemExit("更新插件文件不完整")
    lines.append(f"{plugin_id}\t{components[plugin_id]}")
components_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
version_path.write_text(str(pending.get("version", "")), encoding="utf-8")
PY
)"; then :; else
  validation_status="$?"
  LAST_ERROR="$validation_output"
  printf '%s\n' "$LAST_ERROR" >&2
  failed "$validation_status" "$LINENO" "校验更新清单"
fi

if [[ "$REQUEST_QUIT" == "1" ]]; then
  /usr/bin/osascript -e 'tell application id "md.obsidian" to quit' >/dev/null 2>&1 || { LAST_ERROR="无法请求 Obsidian 完整退出"; false; }
fi
if [[ "$WAIT_PROCESS_ID" =~ ^[0-9]+$ && "$WAIT_PROCESS_ID" -gt 0 ]]; then
  for _attempt in $(seq 1 60); do kill -0 "$WAIT_PROCESS_ID" 2>/dev/null || break; sleep 2; done
  if kill -0 "$WAIT_PROCESS_ID" 2>/dev/null; then LAST_ERROR="等待 Obsidian 退出超时"; false; fi
fi

if [[ -f "$ENABLED" ]]; then
  cp "$ENABLED" "$BACKUP/community-plugins.json"
  : > "$BACKUP/community-plugins.existed"
fi
for plugin_id in "${TARGETS[@]}" "${LEGACY[@]}"; do
  destination="$PLUGINS/$plugin_id"
  had_original=0
  if [[ -d "$destination" ]]; then
    /usr/bin/ditto "$destination" "$BACKUP/plugins/$plugin_id"
    had_original=1
  fi
  printf '%s\t%s\n' "$plugin_id" "$had_original" >> "$JOURNAL"
done

while IFS=$'\t' read -r plugin_id _version; do
  [[ -n "$plugin_id" ]] || continue
  destination="$PLUGINS/$plugin_id"
  incoming="$EXTRACTED/$plugin_id"
  preserved="$UPDATER_ROOT/$plugin_id.data.json"
  rm -f "$preserved"
  [[ -f "$destination/data.json" ]] && cp "$destination/data.json" "$preserved"
  replaced=0
  for _attempt in $(seq 1 60); do
    if rm -rf "$destination" && /usr/bin/ditto "$incoming" "$destination"; then replaced=1; break; fi
    sleep 2
  done
  if [[ "$replaced" != "1" ]]; then LAST_ERROR="插件文件占用超时：$plugin_id"; false; fi
  [[ -f "$preserved" ]] && cp "$preserved" "$destination/data.json"
done < "$COMPONENTS"

python3 - "$ENABLED" "${TARGETS[@]}" <<'PY'
import json, os, sys
path, *targets = sys.argv[1:]
try:
    with open(path, "r", encoding="utf-8-sig") as handle:
        enabled = json.load(handle)
except (FileNotFoundError, json.JSONDecodeError):
    enabled = []
enabled = [str(item) for item in enabled if str(item) != "mangosteen-agent" and str(item) not in targets]
enabled = [*targets, *enabled]
temporary = path + ".tmp"
os.makedirs(os.path.dirname(path), exist_ok=True)
with open(temporary, "w", encoding="utf-8") as handle:
    json.dump(enabled, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
os.replace(temporary, path)
PY
rm -rf "$PLUGINS/mangosteen-agent"

version="$(cat "$VERSION_FILE")"
if [[ "$SKIP_RELAUNCH" != "1" ]]; then
  /usr/bin/open -a Obsidian "$VAULT_PATH"
  started=0
  for _attempt in $(seq 1 30); do if /usr/bin/pgrep -x Obsidian >/dev/null 2>&1; then started=1; break; fi; sleep 1; done
  if [[ "$started" != "1" ]]; then LAST_ERROR="Obsidian 重新启动失败"; false; fi
fi

write_result "success" "$version" ""
rm -rf "$STAGING"
exit 0
