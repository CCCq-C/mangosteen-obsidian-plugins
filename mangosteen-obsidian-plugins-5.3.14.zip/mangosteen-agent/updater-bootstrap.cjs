"use strict";

const fs = require("fs");
const path = require("path");

const REQUIRED_FILES = ["main.js", "updater-core.cjs", "restart-update.ps1", "update-progress.ps1", "manifest.json"];

function compareVersions(left, right) {
  const a = String(left || "0").split(".").map((value) => Number(value) || 0);
  const b = String(right || "0").split(".").map((value) => Number(value) || 0);
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    if ((a[index] || 0) !== (b[index] || 0)) return (a[index] || 0) > (b[index] || 0) ? 1 : -1;
  }
  return 0;
}

function readManifest(folder) {
  return JSON.parse(fs.readFileSync(path.join(folder, "manifest.json"), "utf8"));
}

function syncBundledUpdater({ agentRoot, pluginsRoot }) {
  const bundle = path.join(agentRoot, "bundled-updater");
  const installed = path.join(pluginsRoot, "mangosteen-updater");
  const bundledManifest = readManifest(bundle);
  if (bundledManifest.id !== "mangosteen-updater" || !/^\d+\.\d+\.\d+$/.test(String(bundledManifest.version || ""))) {
    throw new Error("BUNDLED_UPDATER_INVALID");
  }
  for (const file of REQUIRED_FILES) {
    if (!fs.statSync(path.join(bundle, file)).isFile()) throw new Error("BUNDLED_UPDATER_INVALID");
  }
  let installedVersion = "0.0.0";
  try {
    const manifest = readManifest(installed);
    if (manifest.id === "mangosteen-updater") installedVersion = String(manifest.version || installedVersion);
  } catch (_) {}
  if (compareVersions(bundledManifest.version, installedVersion) <= 0) {
    return { updated: false, fromVersion: installedVersion, toVersion: bundledManifest.version };
  }
  fs.mkdirSync(installed, { recursive: true });
  for (const file of REQUIRED_FILES) fs.copyFileSync(path.join(bundle, file), path.join(installed, file));
  return { updated: true, fromVersion: installedVersion, toVersion: bundledManifest.version };
}

module.exports = { compareVersions, syncBundledUpdater };
