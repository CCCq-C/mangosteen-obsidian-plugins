﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$VaultPath,

    [Parameter(Mandatory = $true)]
    [int]$WaitProcessId,

    [switch]$SkipRelaunch,

    [switch]$SkipProgressUi
)

$ErrorActionPreference = 'Stop'
$updaterRoot = Join-Path $VaultPath '.mangosteen-updater'
$stagingRoot = Join-Path $updaterRoot 'staging'
$extractedRoot = Join-Path $stagingRoot 'extracted'
$pluginsRoot = Join-Path $VaultPath '.obsidian\plugins'
$backupRoot = Join-Path $updaterRoot 'backup'
$resultPath = Join-Path $updaterRoot 'result.json'
$progressStatusPath = Join-Path $updaterRoot 'progress.json'
$pluginIds = @('mangosteen-agent', 'mangosteen-image', 'mangosteen-video', 'mangosteen-workbench', 'mangosteen-updater')
$journal = New-Object System.Collections.ArrayList

function Set-UpdateStatus {
    param([string]$State, [string]$Message)
    if ($SkipProgressUi) { return }
    New-Item -ItemType Directory -Path $updaterRoot -Force | Out-Null
    $temporary = "$progressStatusPath.tmp"
    [ordered]@{ state = $State; message = $Message; time = (Get-Date).ToString('s') } |
        ConvertTo-Json -Compress | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $progressStatusPath -Force
}

function Start-UpdateProgressWindow {
    if ($SkipProgressUi) { return }
    $progressScript = Join-Path $PSScriptRoot 'update-progress.ps1'
    if (-not (Test-Path -LiteralPath $progressScript)) { return }
    Set-UpdateStatus -State 'waiting' -Message '正在关闭后台服务，请勿手动重新打开 Obsidian…'
    $escapedScript = $progressScript.Replace("'", "''")
    $escapedStatus = $progressStatusPath.Replace("'", "''")
    $command = "& '$escapedScript' -StatusPath '$escapedStatus'"
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
    Start-Process -FilePath 'powershell.exe' -ArgumentList @(
        '-NoLogo', '-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encoded
    ) -WindowStyle Hidden | Out-Null
}

function Remove-PluginDirectoryWithRetry {
    param([string]$Path, [string]$PluginId)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $deadline = (Get-Date).AddMinutes(2)
    while ($true) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force
            return
        }
        catch {
            if ((Get-Date) -ge $deadline) {
                throw "等待后台服务释放文件超时（2 分钟）：$PluginId；$($_.Exception.Message)"
            }
            Set-UpdateStatus -State 'waiting' -Message '正在等待后台服务完全退出，较慢电脑可能需要 1–2 分钟…'
            Start-Sleep -Seconds 1
        }
    }
}

function Save-Result {
    param([string]$Status, [string]$Version, [string]$Message, [string]$Diagnostic = '')
    [ordered]@{
        status = $Status
        version = $Version
        message = $Message
        diagnostic = $Diagnostic
        time = (Get-Date).ToString('s')
    } | ConvertTo-Json -Compress | Set-Content -LiteralPath $resultPath -Encoding UTF8
}

function Restore-Backup {
    for ($index = $journal.Count - 1; $index -ge 0; $index--) {
        $item = $journal[$index]
        $destination = Join-Path $pluginsRoot $item.Id
        if (Test-Path -LiteralPath $destination) {
            Remove-Item -LiteralPath $destination -Recurse -Force
        }
        if ($item.HadOriginal) {
            Copy-Item -LiteralPath (Join-Path $backupRoot $item.Id) -Destination $destination -Recurse -Force
        }
    }
}

$version = ''
Start-UpdateProgressWindow
try {
    if ($WaitProcessId -gt 0) {
        $deadline = (Get-Date).AddMinutes(2)
        while (Get-Process -Id $WaitProcessId -ErrorAction SilentlyContinue) {
            if ((Get-Date) -ge $deadline) { throw 'Timed out waiting for Obsidian to exit.' }
            Start-Sleep -Milliseconds 250
        }
    }

    $manifest = Get-Content -LiteralPath (Join-Path $stagingRoot 'pending.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $version = [string]$manifest.version
    if ($manifest.schemaVersion -ne 1 -or $version -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid update manifest.' }

    foreach ($id in $pluginIds) {
        $source = Join-Path $extractedRoot $id
        $pluginManifestPath = Join-Path $source 'manifest.json'
        if (-not (Test-Path -LiteralPath (Join-Path $source 'main.js')) -or -not (Test-Path -LiteralPath $pluginManifestPath)) {
            throw "Missing plugin in update package: $id"
        }
        $pluginManifest = Get-Content -LiteralPath $pluginManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$pluginManifest.id -ne $id -or [string]$pluginManifest.version -ne [string]$manifest.components.$id) {
            throw "Plugin manifest mismatch: $id"
        }
    }

    if (Test-Path -LiteralPath $backupRoot) { Remove-Item -LiteralPath $backupRoot -Recurse -Force }
    Set-UpdateStatus -State 'working' -Message '后台服务已关闭，正在备份当前插件…'
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $pluginsRoot -Force | Out-Null

    foreach ($id in $pluginIds) {
        $source = Join-Path $extractedRoot $id
        $destination = Join-Path $pluginsRoot $id
        $hadOriginal = Test-Path -LiteralPath $destination
        if ($hadOriginal) {
            Copy-Item -LiteralPath $destination -Destination (Join-Path $backupRoot $id) -Recurse -Force
        }
        [void]$journal.Add([pscustomobject]@{ Id = $id; HadOriginal = $hadOriginal })
        Set-UpdateStatus -State 'working' -Message "正在更新插件：$id"
        if ($hadOriginal) { Remove-PluginDirectoryWithRetry -Path $destination -PluginId $id }
        Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force
        $oldData = Join-Path (Join-Path $backupRoot $id) 'data.json'
        if ($hadOriginal -and (Test-Path -LiteralPath $oldData)) {
            Copy-Item -LiteralPath $oldData -Destination (Join-Path $destination 'data.json') -Force
        }
    }

    $journal | ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $backupRoot 'journal.json') -Encoding UTF8
    Save-Result -Status 'success' -Version $version -Message 'Update complete.'
    Set-UpdateStatus -State 'success' -Message '更新完成，正在重新打开 Obsidian…'
    Remove-Item -LiteralPath $stagingRoot -Recurse -Force
}
catch {
    try { Restore-Backup } catch {}
    $desktop = [Environment]::GetFolderPath('Desktop')
    if (-not $desktop -or -not (Test-Path -LiteralPath $desktop)) { $desktop = $VaultPath }
    $diagnostic = Join-Path $desktop ("Mangosteen-Update-Error-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    @(
        "Time: $((Get-Date).ToString('s'))",
        "Version: $version",
        "Error: $($_.Exception.Message)",
        'Please send this file to support.'
    ) | Set-Content -LiteralPath $diagnostic -Encoding UTF8
    Save-Result -Status 'failed' -Version $version -Message $_.Exception.Message -Diagnostic $diagnostic
    Set-UpdateStatus -State 'failed' -Message '更新失败，已安全恢复旧版本。'
    exit 1
}
finally {
    if (-not $SkipRelaunch) {
        Start-Process -FilePath ('obsidian://open?path=' + [Uri]::EscapeDataString($VaultPath))
    }
}
