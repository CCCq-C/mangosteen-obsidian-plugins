#!/bin/bash
set -Eeuo pipefail

VAULT_PATH=""
WAIT_PROCESS_ID=0
SKIP_RELAUNCH=0
REQUEST_QUIT=0
LAST_ERROR=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --vault-path) VAULT_PATH="${2:-}"; shift 2 ;;
    --wait-process-id) WAIT_PROCESS_ID="${2:-0}"; shift 2 ;;
    --skip-relaunch) SKIP_RELAUNCH=1; shift ;;
    --request-quit) REQUEST_QUIT=1; shift ;;
    *) echo "未知参数：$1" >&2; exit 2 ;;
  esac
done

[[ "$VAULT_PATH" == /* && -d "$VAULT_PATH" ]] || { echo "知识库路径无效" >&2; exit 2; }
UPDATER_ROOT="$VAULT_PATH/.mangosteen-updater"
STAGING="$UPDATER_ROOT/staging"
EXTRACTED="$STAGING/extracted"
PENDING="$STAGING/pending.json"
PLUGINS="$VAULT_PATH/.obsidian/plugins"
BACKUP="$UPDATER_ROOT/backup"
COMPONENTS="$UPDATER_ROOT/components.tsv"
VERSION_FILE="$UPDATER_ROOT/version.txt"
RESULT="$UPDATER_ROOT/result.json"

write_result() {
  python3 - "$RESULT" "$1" "$2" "${3:-}" <<'PY'
import json, os, sys
path, status, version, diagnostic = sys.argv[1:]
temporary = path + ".tmp"
with open(temporary, "w", encoding="utf-8") as handle:
    json.dump({"status": status, "version": version, "diagnostic": diagnostic}, handle, ensure_ascii=False)
    handle.write("\n")
os.replace(temporary, path)
PY
}

rollback() {
  [[ -f "$COMPONENTS" ]] || return 0
  while IFS=$'\t' read -r plugin_id _version; do
    [[ -n "$plugin_id" ]] || continue
    [[ -f "$BACKUP/$plugin_id.touched" ]] || continue
    destination="$PLUGINS/$plugin_id"
    rm -rf "$destination"
    if [[ -f "$BACKUP/$plugin_id.had-original" && -d "$BACKUP/$plugin_id" ]]; then
      /usr/bin/ditto "$BACKUP/$plugin_id" "$destination"
    fi
  done < "$COMPONENTS"
}

failed() {
  local status="${1:-1}" line="${2:-unknown}" command="${3:-unknown}"
  trap - ERR
  rollback || true
  local version diagnostic
  version="$(cat "$VERSION_FILE" 2>/dev/null || true)"
  diagnostic="$UPDATER_ROOT/mac-update-error.txt"
  {
    printf '山竹插件更新失败，旧版本已恢复。\n'
    [[ -n "$LAST_ERROR" ]] && printf '原因：%s\n' "$LAST_ERROR"
    printf '位置：第 %s 行\n命令：%s\n' "$line" "$command"
  } > "$diagnostic"
  write_result "failed" "$version" "$diagnostic" || true
  exit "$status"
}
trap 'failed "$?" "$LINENO" "$BASH_COMMAND"' ERR

[[ -f "$PENDING" && -d "$EXTRACTED" ]] || { echo "更新暂存文件不完整" >&2; exit 1; }
mkdir -p "$UPDATER_ROOT" "$PLUGINS"
rm -rf "$BACKUP"
mkdir -p "$BACKUP"
rm -f "$COMPONENTS" "$VERSION_FILE"

if validation_output="$(python3 - "$PENDING" "$EXTRACTED" "$COMPONENTS" "$VERSION_FILE" 2>&1 <<'PY'
import json, re, sys
from pathlib import Path
pending_path, extracted_path, components_path, version_path = map(Path, sys.argv[1:])
pending = json.loads(pending_path.read_text(encoding="utf-8-sig"))
components = pending.get("components")
allowed = {"mangosteen-agent", "mangosteen-image", "mangosteen-video", "mangosteen-workbench"}
if not isinstance(components, dict) or set(components) != allowed:
    raise SystemExit("更新组件清单无效")
lines = []
for plugin_id in sorted(components):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", plugin_id):
        raise SystemExit("插件 ID 无效")
    manifest = json.loads((extracted_path / plugin_id / "manifest.json").read_text(encoding="utf-8-sig"))
    if manifest.get("id") != plugin_id or manifest.get("version") != components[plugin_id]:
        raise SystemExit("更新插件版本无效")
    if not (extracted_path / plugin_id / "main.js").is_file():
        raise SystemExit("更新插件文件不完整")
    lines.append(f"{plugin_id}\t{components[plugin_id]}")
components_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
version_path.write_text(str(pending.get("version", "")), encoding="utf-8")
PY
)"; then
  :
else
  validation_status="$?"
  LAST_ERROR="$validation_output"
  printf '%s\n' "$LAST_ERROR" >&2
  failed "$validation_status" "$LINENO" "校验更新清单"
fi

if [[ "$REQUEST_QUIT" == "1" ]]; then
  /usr/bin/osascript -e 'tell application id "md.obsidian" to quit' >/dev/null 2>&1 || {
    LAST_ERROR="无法请求 Obsidian 完整退出"
    false
  }
fi

if [[ "$WAIT_PROCESS_ID" =~ ^[0-9]+$ && "$WAIT_PROCESS_ID" -gt 0 ]]; then
  for _attempt in $(seq 1 60); do
    kill -0 "$WAIT_PROCESS_ID" 2>/dev/null || break
    sleep 2
  done
  if kill -0 "$WAIT_PROCESS_ID" 2>/dev/null; then
    LAST_ERROR="等待 Obsidian 退出超时"
    false
  fi
fi

while IFS=$'\t' read -r plugin_id _version; do
  [[ -n "$plugin_id" ]] || continue
  destination="$PLUGINS/$plugin_id"
  incoming="$EXTRACTED/$plugin_id"
  preserved="$UPDATER_ROOT/$plugin_id.data.json"
  rm -f "$preserved"
  if [[ -d "$destination" ]]; then
    /usr/bin/ditto "$destination" "$BACKUP/$plugin_id"
    : > "$BACKUP/$plugin_id.had-original"
    [[ -f "$destination/data.json" ]] && cp "$destination/data.json" "$preserved"
  fi
  : > "$BACKUP/$plugin_id.touched"
  replaced=0
  for _attempt in $(seq 1 60); do
    if rm -rf "$destination" && /usr/bin/ditto "$incoming" "$destination"; then
      replaced=1
      break
    fi
    sleep 2
  done
  if [[ "$replaced" != "1" ]]; then
    LAST_ERROR="插件文件占用超时：$plugin_id"
    false
  fi
  [[ -f "$preserved" ]] && cp "$preserved" "$destination/data.json"
done < "$COMPONENTS"

version="$(cat "$VERSION_FILE")"
if [[ "$SKIP_RELAUNCH" != "1" ]]; then
  /usr/bin/open -a Obsidian "$VAULT_PATH"
  started=0
  for _attempt in $(seq 1 30); do
    if /usr/bin/pgrep -x Obsidian >/dev/null 2>&1; then started=1; break; fi
    sleep 1
  done
  if [[ "$started" != "1" ]]; then
    LAST_ERROR="Obsidian 重新启动失败"
    false
  fi
fi

write_result "success" "$version" ""
rm -rf "$STAGING"
exit 0
