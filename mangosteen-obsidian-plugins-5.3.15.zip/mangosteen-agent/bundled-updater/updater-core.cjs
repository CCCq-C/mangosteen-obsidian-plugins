"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const TARGET_PLUGIN_IDS = ["mangosteen-agent", "mangosteen-image", "mangosteen-video", "mangosteen-workbench"];
const MANIFEST_URLS = [
  "https://gitee.com/Chance-Ccc/mangosteen-obsidian-plugins/raw/master/latest.json",
  "https://raw.githubusercontent.com/CCCq-C/mangosteen-obsidian-plugins/main/latest.json",
];

function codedError(code, cause) { const error = new Error(cause?.message || String(cause || code)); error.code = code; return error; }

function compareVersions(left, right) {
  const a = String(left || "0").split(".").map((part) => Number(part) || 0);
  const b = String(right || "0").split(".").map((part) => Number(part) || 0);
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    if ((a[index] || 0) !== (b[index] || 0)) return (a[index] || 0) > (b[index] || 0) ? 1 : -1;
  }
  return 0;
}

function validateManifest(value) {
  if (!value || Number(value.schemaVersion) !== 1 || !/^\d+\.\d+\.\d+$/.test(String(value.version || ""))) throw codedError("MANIFEST_INVALID");
  if (!/^[A-Za-z0-9._-]+\.zip$/.test(String(value.package || "")) || !/^[a-f0-9]{64}$/i.test(String(value.sha256 || ""))) throw codedError("MANIFEST_INVALID");
  if (TARGET_PLUGIN_IDS.some((id) => !/^\d+\.\d+\.\d+$/.test(String(value.components?.[id] || "")))) throw codedError("MANIFEST_INVALID");
  return value;
}

function bytesFrom(response) {
  const value = response?.arrayBuffer;
  if (Buffer.isBuffer(value)) return value;
  if (value instanceof ArrayBuffer) return Buffer.from(value);
  if (ArrayBuffer.isView(value)) return Buffer.from(value.buffer, value.byteOffset, value.byteLength);
  throw codedError("DOWNLOAD_INVALID");
}

function extractWithSystemTool(zipPath, destination) {
  if (process.platform === "win32") {
    const psLiteral = (value) => `'${String(value).replace(/'/g, "''")}'`;
    const command = `$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath ${psLiteral(zipPath)} -DestinationPath ${psLiteral(destination)} -Force`;
    execFileSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command], { windowsHide: true });
    return;
  }
  execFileSync(process.platform === "darwin" ? "ditto" : "unzip", process.platform === "darwin" ? ["-x", "-k", zipPath, destination] : ["-q", "-o", zipPath, "-d", destination]);
}

function verifyExtracted(extracted, manifest) {
  for (const id of TARGET_PLUGIN_IDS) {
    let pluginManifest;
    try { pluginManifest = JSON.parse(fs.readFileSync(path.join(extracted, id, "manifest.json"), "utf8")); } catch (_) { throw codedError("PACKAGE_INVALID"); }
    if (pluginManifest.id !== id || String(pluginManifest.version) !== String(manifest.components[id]) || !fs.existsSync(path.join(extracted, id, "main.js"))) throw codedError("PACKAGE_INVALID");
  }
}

function classifyPluginHealth(value = {}) {
  if (!value.folderExists || !value.manifestValid || !value.mainExists) return "PLUGIN_FILES_MISSING";
  if (!value.enabled) return "PLUGIN_DISABLED";
  if (!value.loaded) return "PLUGIN_LOAD_FAILED";
  return "OK";
}

function createUpdaterCore(options = {}) {
  const request = options.request;
  const manifestUrls = options.manifestUrls || MANIFEST_URLS;
  const extractArchive = options.extractArchive || extractWithSystemTool;
  const roots = (vaultPath) => {
    const root = path.join(vaultPath, ".mangosteen-updater");
    return { root, staging: path.join(root, "staging"), extracted: path.join(root, "staging", "extracted"), backup: path.join(root, "backup"), plugins: path.join(vaultPath, ".obsidian", "plugins") };
  };

  async function check(currentVersion) {
    if (typeof request !== "function") throw codedError("UPDATE_CHECK_FAILED");
    for (const manifestUrl of manifestUrls) {
      try {
        const response = await request({ url: manifestUrl, method: "GET", headers: { "Cache-Control": "no-cache" } });
        if (Number(response?.status || 0) >= 400) continue;
        const manifest = validateManifest(response?.json);
        return { ok: true, updateAvailable: compareVersions(manifest.version, currentVersion) > 0, manifest, manifestUrl };
      } catch (_) {}
    }
    throw codedError("UPDATE_CHECK_FAILED");
  }

  async function prepare({ vaultPath, currentVersion, onStatus = () => {} }) {
    onStatus("正在检查新版本…");
    const checked = await check(currentVersion);
    if (!checked.updateAvailable) return { ok: true, prepared: false, version: checked.manifest.version };
    const packageUrl = new URL(checked.manifest.package, checked.manifestUrl).href;
    onStatus(`正在下载 ${checked.manifest.version}…`);
    const response = await request({ url: packageUrl, method: "GET", headers: { "Cache-Control": "no-cache" } });
    if (Number(response?.status || 0) >= 400) throw codedError("DOWNLOAD_FAILED");
    const archive = bytesFrom(response);
    if (crypto.createHash("sha256").update(archive).digest("hex").toLowerCase() !== checked.manifest.sha256.toLowerCase()) throw codedError("HASH_MISMATCH");
    const target = roots(vaultPath);
    fs.rmSync(target.staging, { recursive: true, force: true });
    fs.mkdirSync(target.extracted, { recursive: true });
    const zipPath = path.join(target.staging, checked.manifest.package);
    fs.writeFileSync(zipPath, archive);
    try {
      extractArchive(zipPath, target.extracted);
      verifyExtracted(target.extracted, checked.manifest);
      fs.writeFileSync(path.join(target.staging, "pending.json"), JSON.stringify(checked.manifest), "utf8");
      return { ok: true, prepared: true, version: checked.manifest.version, components: Object.keys(checked.manifest.components) };
    } catch (error) {
      fs.rmSync(target.staging, { recursive: true, force: true });
      throw error?.code ? error : codedError("PACKAGE_INVALID", error);
    }
  }

  function restoreFromBackup(target, journal) {
    for (const item of [...journal].reverse()) {
      const destination = path.join(target.plugins, item.id);
      fs.rmSync(destination, { recursive: true, force: true });
      if (item.hadOriginal) fs.cpSync(path.join(target.backup, item.id), destination, { recursive: true, force: true });
    }
  }

  function apply({ vaultPath }) {
    const target = roots(vaultPath);
    let manifest;
    try { manifest = validateManifest(JSON.parse(fs.readFileSync(path.join(target.staging, "pending.json"), "utf8"))); verifyExtracted(target.extracted, manifest); }
    catch (_) { throw codedError("PACKAGE_INVALID"); }
    fs.rmSync(target.backup, { recursive: true, force: true });
    fs.mkdirSync(target.backup, { recursive: true });
    const journal = [];
    try {
      fs.mkdirSync(target.plugins, { recursive: true });
      for (const id of TARGET_PLUGIN_IDS) {
        const destination = path.join(target.plugins, id);
        const hadOriginal = fs.existsSync(destination);
        if (hadOriginal) fs.cpSync(destination, path.join(target.backup, id), { recursive: true, force: true });
        journal.push({ id, hadOriginal });
        fs.rmSync(destination, { recursive: true, force: true });
        fs.cpSync(path.join(target.extracted, id), destination, { recursive: true, force: true });
        const oldData = path.join(target.backup, id, "data.json");
        if (hadOriginal && fs.existsSync(oldData)) fs.copyFileSync(oldData, path.join(destination, "data.json"));
      }
      fs.writeFileSync(path.join(target.backup, "journal.json"), JSON.stringify(journal), "utf8");
      return { ok: true, updated: true, version: manifest.version, backupReady: true };
    } catch (cause) {
      try { restoreFromBackup(target, journal); } catch (_) {}
      throw codedError("INSTALL_FAILED", cause);
    }
  }

  function rollback({ vaultPath }) {
    const target = roots(vaultPath);
    let journal;
    try { journal = JSON.parse(fs.readFileSync(path.join(target.backup, "journal.json"), "utf8")); } catch (_) { throw codedError("ROLLBACK_UNAVAILABLE"); }
    restoreFromBackup(target, journal);
    return { ok: true, restored: journal.map((item) => item.id) };
  }

  function complete({ vaultPath }) {
    const target = roots(vaultPath);
    fs.rmSync(target.staging, { recursive: true, force: true });
    fs.rmSync(target.backup, { recursive: true, force: true });
  }

  return { check, prepare, apply, rollback, complete };
}

module.exports = { MANIFEST_URLS, TARGET_PLUGIN_IDS, classifyPluginHealth, compareVersions, createUpdaterCore, validateManifest };
