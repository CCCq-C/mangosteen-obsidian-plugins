"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFile, spawn } = require("child_process");
const { Modal, Notice, Plugin, requestUrl } = require("obsidian");
let TARGET_PLUGIN_IDS;
let classifyPluginHealth;
let createUpdaterCore;

const LABELS = { "mangosteen-agent": "山竹智能体", "mangosteen-image": "山竹出图", "mangosteen-video": "山竹视频", "mangosteen-workbench": "山竹工作台" };
const ERROR_TEXT = {
  UPDATE_CHECK_FAILED: "暂时无法连接 Gitee 或 GitHub，请检查网络后重试。",
  DOWNLOAD_FAILED: "更新包下载失败，请检查网络后重试。",
  HASH_MISMATCH: "更新包安全校验失败，当前插件没有被修改。",
  PACKAGE_INVALID: "更新包内容不完整，当前插件没有被修改。",
  UPDATE_LAUNCH_FAILED: "后台更新程序启动失败，Obsidian 没有关闭，当前版本没有被修改。",
  INSTALL_FAILED: "插件文件替换失败，已恢复旧版本。",
  PLUGIN_FILES_MISSING: "插件文件不完整，请重新安装完整包。",
  PLUGIN_DISABLED: "插件当前被关闭，可以点击一键修复重新启用。",
  PLUGIN_LOAD_FAILED: "插件已启用但加载失败，可以点击一键修复重新加载。",
};

class UpdateConfirmModal extends Modal {
  constructor(app, version, notes, resolve) {
    super(app);
    this.version = version;
    this.notes = (Array.isArray(notes) ? notes : []).map((note) => String(note || "").trim().slice(0, 120)).filter(Boolean).slice(0, 5);
    this.resolve = resolve;
  }
  onOpen() {
    this.contentEl.createEl("h2", { text: "发现山竹插件新版本" });
    this.contentEl.createEl("p", { text: `新版本 ${this.version} 已发布。是否现在下载并更新？` });
    this.notes.forEach((note) => this.contentEl.createEl("p", { text: "· " + note }));
    this.contentEl.createEl("p", { text: "更新时 Obsidian 会自动关闭。较慢电脑可能需要 1–2 分钟，请勿手动重新打开，完成后会自动启动。" });
    const actions = this.contentEl.createDiv();
    const later = actions.createEl("button", { text: "稍后" });
    const update = actions.createEl("button", { text: "立即更新", cls: "mod-cta" });
    later.onclick = () => { this.resolve(false); this.close(); };
    update.onclick = () => { this.resolve(true); this.close(); };
  }
  onClose() { if (this.resolve) { this.resolve(false); this.resolve = null; } }
}

class RecoveryModal extends Modal {
  constructor(app, plugin, id, code) { super(app); this.plugin = plugin; this.id = id; this.code = code; }
  onOpen() {
    this.contentEl.createEl("h2", { text: "山竹插件加载故障" });
    this.contentEl.createEl("p", { text: `${LABELS[this.id] || this.id}：${ERROR_TEXT[this.code] || "加载状态异常。"}` });
    this.contentEl.createEl("p", { text: "一键修复失败时，桌面会生成诊断文件，请把它发给售后老师。" });
    const repair = this.contentEl.createEl("button", { text: "一键修复", cls: "mod-cta" });
    repair.onclick = async () => { repair.disabled = true; const result = await this.plugin.repairPlugin(this.id); if (result.ok) this.close(); else repair.setText("修复失败，诊断文件已放到桌面"); };
  }
}

module.exports = class MangosteenUpdaterPlugin extends Plugin {
  async onload() {
    const vaultBasePath = this.app.vault?.adapter?.getBasePath?.() || this.app.vault?.adapter?.basePath || process.cwd();
    const pluginRoot = path.join(vaultBasePath, ...String(this.manifest.dir || "").split(/[\\/]/));
    this.pluginRoot = pluginRoot;
    const corePath = path.join(pluginRoot, "updater-core.cjs");
    delete require.cache[require.resolve(corePath)];
    ({ TARGET_PLUGIN_IDS, classifyPluginHealth, createUpdaterCore } = require(corePath));
    this.core = createUpdaterCore({ request: (options) => requestUrl({ ...options, throw: false }) });
    this.running = false;
    this.app.workspace.onLayoutReady(() => {
      window.setTimeout(() => this.showDeferredResult(), 800);
      window.setTimeout(() => void this.checkRequiredPlugins(), 1200);
      window.setTimeout(() => void this.checkForUpdates({ manual: false }), 3000);
    });
  }

  getUpdaterBridge() { return { checkForUpdates: (options) => this.checkForUpdates(options), repairPlugin: (id) => this.repairPlugin(id) }; }
  vaultPath() { return this.app.vault?.adapter?.getBasePath?.() || this.app.vault?.adapter?.basePath || process.cwd(); }
  currentVersion() { return String(this.app.plugins?.manifests?.["mangosteen-agent"]?.version || this.manifest.version || "0.0.0"); }

  confirmUpdate(version, notes) {
    return new Promise((resolve) => {
      let settled = false;
      const finish = (value) => { if (!settled) { settled = true; resolve(value); } };
      const modal = new UpdateConfirmModal(this.app, version, notes, finish);
      modal.open();
    });
  }

  async checkForUpdates({ manual = false } = {}) {
    if (this.running) return { ok: false, code: "BUSY" };
    this.running = true;
    try {
      const checked = await this.core.check(this.currentVersion());
      if (!checked.updateAvailable) { if (manual) new Notice(`已经是最新版（${checked.manifest.version}）`); return checked; }
      if (!await this.confirmUpdate(checked.manifest.version, checked.manifest.notes)) return { ok: true, cancelled: true };
      return await this.installConfirmedUpdate();
    } catch (error) {
      if (manual) new Notice(ERROR_TEXT[error?.code] || "检查更新失败，请稍后重试。", 12000);
      return { ok: false, code: error?.code || "UPDATE_FAILED" };
    } finally { this.running = false; }
  }

  async installConfirmedUpdate() {
    const vaultPath = this.vaultPath();
    const status = new Notice("正在准备山竹插件更新…", 0);
    try {
      const prepared = await this.core.prepare({ vaultPath, currentVersion: this.currentVersion(), onStatus: (text) => status.setMessage?.(text) });
      if (!prepared.prepared) return prepared;
      await this.launchDeferredInstall({ vaultPath, version: prepared.version });
      status.hide?.();
      new Notice("更新包校验完成，正在重启 Obsidian 完成更新…", 0);
      window.setTimeout(() => window.close(), 500);
      return { ok: true, prepared: true, restarting: true, version: prepared.version };
    } catch (error) {
      status.hide?.();
      const diagnostic = this.writeDiagnostic(error?.pluginId || "update", error?.code || "UPDATE_FAILED", error);
      new Notice(`${ERROR_TEXT[error?.code] || "更新启动失败，当前插件没有被修改。"}\n诊断文件：${diagnostic}`, 20000);
      return { ok: false, code: error?.code || "UPDATE_FAILED", diagnostic };
    }
  }

  launchDeferredInstall({ vaultPath }) {
    if (process.platform === "darwin") {
      const helper = path.join(this.pluginRoot, "restart-update.sh");
      if (!fs.existsSync(helper)) throw Object.assign(new Error("缺少 Mac 重启更新程序"), { code: "PACKAGE_INVALID" });
      return new Promise((resolve, reject) => {
        let child;
        try {
          child = spawn("/bin/bash", [
            helper, "--vault-path", vaultPath, "--wait-process-id", String(process.pid),
            "--request-quit",
          ], { detached: true, stdio: "ignore" });
        } catch (error) {
          reject(Object.assign(error, { code: "UPDATE_LAUNCH_FAILED" }));
          return;
        }
        child.once("error", (error) => reject(Object.assign(error, { code: "UPDATE_LAUNCH_FAILED" })));
        child.once("spawn", () => { child.unref(); resolve(child.pid); });
      });
    }
    if (process.platform !== "win32") {
      throw Object.assign(new Error(`不支持的系统：${process.platform}`), { code: "UPDATE_LAUNCH_FAILED" });
    }
    const helper = path.join(this.pluginRoot, "restart-update.ps1");
    if (!fs.existsSync(helper)) throw Object.assign(new Error("缺少重启更新程序"), { code: "PACKAGE_INVALID" });
    const psLiteral = (value) => `'${String(value).replace(/'/g, "''")}'`;
    const innerScript = `& ${psLiteral(helper)} -VaultPath ${psLiteral(vaultPath)} -WaitProcessId ${process.pid}`;
    const innerEncoded = Buffer.from(innerScript, "utf16le").toString("base64");
    const outerScript = [
      "$exe=Join-Path $env:SystemRoot 'System32\\WindowsPowerShell\\v1.0\\powershell.exe'",
      `$commandLine='"'+$exe+'" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ${innerEncoded}'`,
      "$created=Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{CommandLine=$commandLine} -ErrorAction Stop",
      "if([int]$created.ReturnValue -ne 0 -or [int]$created.ProcessId -le 0){throw ('Win32_Process.Create failed: '+[string]$created.ReturnValue)}",
      "Write-Output ('PROCESS_ID='+[string]$created.ProcessId)",
    ].join(";");
    const encoded = Buffer.from(outerScript, "utf16le").toString("base64");
    return new Promise((resolve, reject) => {
      execFile("powershell.exe", [
        "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded,
      ], { windowsHide: true, timeout: 15000 }, (error, stdout, stderr) => {
        const match = String(stdout || "").match(/PROCESS_ID=(\d+)/);
        if (error || !match) {
          const detail = String(stderr || error?.message || "CIM 未返回更新进程编号").trim();
          reject(Object.assign(new Error(detail), { code: "UPDATE_LAUNCH_FAILED" }));
          return;
        }
        resolve(Number(match[1]));
      });
    });
  }

  showDeferredResult() {
    const file = path.join(this.vaultPath(), ".mangosteen-updater", "result.json");
    if (!fs.existsSync(file)) return;
    try {
      const result = JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
      if (result.status === "success") new Notice(`山竹插件已更新到 ${result.version}。`, 12000);
      else new Notice(`更新失败，旧版本已恢复。\n诊断文件：${result.diagnostic || "请联系售后老师"}`, 20000);
    } finally { fs.rmSync(file, { force: true }); }
  }

  isLoaded(id) { return Boolean(this.app.plugins?.plugins?.[id]); }
  isEnabled(id) { return Boolean(this.app.plugins?.enabledPlugins?.has?.(id) || this.isLoaded(id)); }

  inspectPlugin(id) {
    const folder = path.join(this.vaultPath(), ".obsidian", "plugins", id);
    const manifestPath = path.join(folder, "manifest.json");
    let manifestValid = false;
    try { manifestValid = JSON.parse(fs.readFileSync(manifestPath, "utf8"))?.id === id; } catch (_) {}
    return {
      folderExists: fs.existsSync(folder), manifestValid, mainExists: fs.existsSync(path.join(folder, "main.js")),
      enabled: this.isEnabled(id), loaded: this.isLoaded(id),
    };
  }

  async checkRequiredPlugins() {
    for (const id of TARGET_PLUGIN_IDS) {
      const code = classifyPluginHealth(this.inspectPlugin(id));
      if (code !== "OK") { new RecoveryModal(this.app, this, id, code).open(); return { ok: false, id, code }; }
    }
    return { ok: true };
  }

  async repairPlugin(id) {
    const before = classifyPluginHealth(this.inspectPlugin(id));
    if (before === "PLUGIN_FILES_MISSING") return { ok: false, code: before, diagnostic: this.writeDiagnostic(id, before) };
    try {
      if (this.isLoaded(id)) await this.app.plugins.disablePlugin(id);
      await this.app.plugins.enablePlugin(id);
      if (this.isLoaded(id)) { new Notice(`${LABELS[id] || id} 已恢复加载。`); return { ok: true }; }
    } catch (error) { return { ok: false, code: "PLUGIN_LOAD_FAILED", diagnostic: this.writeDiagnostic(id, "PLUGIN_LOAD_FAILED", error) }; }
    return { ok: false, code: "PLUGIN_LOAD_FAILED", diagnostic: this.writeDiagnostic(id, "PLUGIN_LOAD_FAILED") };
  }

  writeDiagnostic(id, code, error) {
    const desktop = path.join(os.homedir(), "Desktop");
    const target = fs.existsSync(desktop) ? desktop : this.vaultPath();
    const file = path.join(target, `山竹插件加载故障-${Date.now()}.txt`);
    const health = id === "update" ? {} : this.inspectPlugin(id);
    fs.writeFileSync(file, [
      `时间：${new Date().toLocaleString("zh-CN", { hour12: false })}`,
      `插件：${LABELS[id] || id}`,
      `诊断码：${code}`,
      `状态：${JSON.stringify(health)}`,
      `错误：${String(error?.message || "未捕获到具体错误").replace(/sk-[A-Za-z0-9_-]+/g, "[已隐藏]")}`,
      "处理建议：把本文件发给售后老师。",
    ].join("\r\n"), "utf8");
    return file;
  }
};
