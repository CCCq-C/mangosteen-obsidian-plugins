const { Plugin, Modal, Notice, requestUrl } = require("obsidian");
const path = require("path");
const fs = require("fs");

const API_BASE = "https://apishanzhu.aihubkit.com";
const MATERIAL_UPLOAD_TIMEOUT_MS = 5 * 60 * 1000;
const DEFAULT_SETTINGS = {
  model: "",
  duration: 5,
  ratio: "16:9",
  resolution: "720p",
  resolutionsByModel: {},
  videoCapabilitiesByModel: {},
  videoTasks: [],
};
const resolvePluginFile = (plugin, fileName) => {
  const adapter = plugin.app?.vault?.adapter;
  const vaultBasePath = adapter?.getBasePath?.() || adapter?.basePath;
  const candidates = [];
  if (vaultBasePath && plugin.manifest?.dir) {
    candidates.push(path.join(vaultBasePath, ...String(plugin.manifest.dir).split(/[\\/]/).filter(Boolean), fileName));
  }
  if (vaultBasePath && plugin.manifest?.id) {
    candidates.push(path.join(vaultBasePath, ".obsidian", "plugins", String(plugin.manifest.id), fileName));
  }
  candidates.push(path.join(__dirname, fileName));
  return candidates.find((candidate) => fs.existsSync(candidate)) || candidates[0];
};

const addField = (root, label, tag, options = {}) => {
  const row = root.createDiv({ cls: "mangosteen-video-field" });
  row.createEl("label", { text: label });
  return row.createEl(tag, options);
};

const readImagePreview = (file) => new Promise((resolve, reject) => {
  if (typeof FileReader !== "function") return resolve(globalThis.URL?.createObjectURL?.(file) || "");
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result || ""));
  reader.onerror = () => reject(new Error("图片预览读取失败，请重新选择文件。"));
  reader.readAsDataURL(file);
});

const supportsImageToVideo = (model) => String(model || "").trim().toLowerCase() === "minimax-h3";

class VideoStudioModal extends Modal {
  constructor(plugin) {
    super(plugin.app);
    this.plugin = plugin;
    this.balance = null;
    this.status = plugin.videoSubmissionState?.message || "正在连接山竹账号中心～";
    this.accessLoaded = false;
    this.catalogRevision = 0;
  }

  onOpen() {
    this.modalEl?.addClass?.("mangosteen-video-modal");
    (this.plugin.videoTaskViews ||= new Set()).add(this);
    const bridge = this.plugin.app?.plugins?.getPlugin?.("mangosteen-media-core")?.getAccountBridge?.();
    this.unsubscribeCatalog = bridge?.subscribeCatalog?.((ready) => {
      this.catalogRevision += 1;
      this.accessLoaded = false;
      this.balance = null;
      this.status = "正在同步平台最新视频模型…";
      this.render();
      if (ready) void this.load();
    });
    this.render();
    void this.load();
  }

  onClose() { this.catalogRevision += 1; this.unsubscribeCatalog?.(); this.clearReferenceImages(); this.clearReferenceVideos(); this.clearFrameImages(); this.statusEl = null; this.plugin.videoTaskViews?.delete(this); }

  updateSubmissionStatus(message) {
    this.status = message;
    this.statusEl?.setText?.(message);
  }

  async load() {
    const revision = ++this.catalogRevision;
    try {
      await this.plugin.refreshAgentAccess();
      if (revision !== this.catalogRevision) return;
      this.accessLoaded = true;
      this.balance = await this.plugin.getQuota().catch(() => null);
      await this.plugin.refreshVideoTasks();
      await this.plugin.refreshTaskUsageRecords();
      this.status = this.plugin.videoSubmissionState?.message || "可以直接描述想生成什么视频哟～";
    } catch (error) {
      if (revision !== this.catalogRevision) return;
      this.accessLoaded = false;
      this.status = this.plugin.api.toChineseVideoError(error);
    }
    if (revision !== this.catalogRevision) return;
    this.render();
  }

  modelLabel(model) {
    const candidate = this.plugin.getVideoKeyCandidates(model)[0];
    const ratio = Number(this.plugin.videoAccess?.groupRatios?.[candidate?.group]?.ratio);
    return `${model}${Number.isFinite(ratio) ? ` · ${candidate.group} ×${ratio}` : ""}`;
  }

  renderFrameUpload(root, slot, label) {
    const fileKey = `${slot}ImageFile`;
    const previewKey = `${slot}ImagePreview`;
    const item = root.createDiv({ cls: "mangosteen-video-frame-item" });
    const upload = item.createEl("label", { cls: "mangosteen-video-frame-upload", attr: { "aria-label": `选择本地${label}图片` } });
    const input = upload.createEl("input", { attr: { type: "file", accept: "image/png,image/jpeg,image/webp" } });
    if (this[previewKey]) {
      upload.createEl("img", { cls: "mangosteen-video-frame-preview", attr: { src: this[previewKey], alt: `${label}图片预览` } });
      upload.createEl("span", { cls: "mangosteen-video-frame-caption", text: "点击更换" });
    } else {
      const placeholder = upload.createDiv({ cls: "mangosteen-video-frame-placeholder" });
      placeholder.createEl("strong", { text: `选择${label}图片` });
      placeholder.createEl("span", { text: "PNG、JPG、WebP" });
    }
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        this.plugin.api.assertLocalImageUploadSize(file);
        this.clearReferenceImages();
        this.clearReferenceVideos();
        this.clearFrameImage(slot);
        this[fileKey] = file;
        this[previewKey] = globalThis.URL?.createObjectURL?.(file) || "";
        this.advancedOpen = true;
        this.render();
      } catch (error) { this.status = error?.message || String(error); this.render(); }
    });
    if (this[fileKey]) {
      const clear = item.createEl("button", { cls: "mangosteen-video-frame-clear", text: "移除", attr: { type: "button", "aria-label": `移除${label}图片` } });
      clear.addEventListener("click", () => { this.clearFrameImage(slot); this.render(); });
    }
  }

  clearFrameImage(slot) {
    const preview = this[`${slot}ImagePreview`];
    if (preview) globalThis.URL?.revokeObjectURL?.(preview);
    this[`${slot}ImageFile`] = null;
    this[`${slot}ImagePreview`] = "";
  }

  clearFrameImages() {
    this.clearFrameImage("first");
    this.clearFrameImage("last");
  }

  clearReferenceImages() {
    for (const preview of this.referenceImagePreviews || []) if (preview) globalThis.URL?.revokeObjectURL?.(preview);
    this.referenceImageFiles = [];
    this.referenceImagePreviews = [];
  }

  renderReferenceImageUploads(root, maxImages) {
    const files = this.referenceImageFiles || [];
    const previews = this.referenceImagePreviews || [];
    const grid = root.createDiv({ cls: "mangosteen-video-frame-grid" });
    files.forEach((file, index) => {
      const item = grid.createDiv({ cls: "mangosteen-video-frame-item" });
      const card = item.createDiv({ cls: "mangosteen-video-frame-upload" });
      if (previews[index]) {
        card.createEl("img", { cls: "mangosteen-video-frame-preview", attr: { src: previews[index], alt: `${file.name} 预览` } });
        card.createEl("span", { cls: "mangosteen-video-frame-caption", text: file.name });
      } else {
        const placeholder = card.createDiv({ cls: "mangosteen-video-frame-placeholder" });
        placeholder.createEl("strong", { text: file.name });
        placeholder.createEl("span", { text: "参考图片" });
      }
      const clear = item.createEl("button", { cls: "mangosteen-video-frame-clear", text: "移除", attr: { type: "button", "aria-label": `移除参考图片 ${file.name}` } });
      clear.addEventListener("click", () => {
        if (previews[index]) globalThis.URL?.revokeObjectURL?.(previews[index]);
        this.referenceImageFiles = files.filter((_, itemIndex) => itemIndex !== index);
        this.referenceImagePreviews = previews.filter((_, itemIndex) => itemIndex !== index);
        this.render();
      });
    });
    if (files.length >= maxImages) return;
    const item = grid.createDiv({ cls: "mangosteen-video-frame-item" });
    const upload = item.createEl("label", { cls: "mangosteen-video-frame-upload", attr: { "aria-label": "选择参考图片" } });
    const input = upload.createEl("input", { attr: { type: "file", accept: "image/png,image/jpeg,image/webp", multiple: "multiple" } });
    const placeholder = upload.createDiv({ cls: "mangosteen-video-frame-placeholder" });
    placeholder.createEl("strong", { text: "选择参考图片" });
    placeholder.createEl("span", { text: `可多选，最多${maxImages}张` });
    input.addEventListener("change", async () => {
      const selected = Array.from(input.files || []);
      try {
        if (files.length + selected.length > maxImages) throw new Error(`参考图片最多选择 ${maxImages} 张。`);
        for (const file of selected) this.plugin.api.assertLocalImageUploadSize(file);
        const selectedPreviews = await Promise.all(selected.map(readImagePreview));
        this.clearFrameImages();
        this.referenceImageFiles = files.concat(selected);
        this.referenceImagePreviews = previews.concat(selectedPreviews);
        this.advancedOpen = true;
        this.render();
      } catch (error) { this.status = error?.message || String(error); this.render(); }
    });
  }

  renderReferenceVideoUploads(root, maxVideos, model) {
    const files = this.referenceVideoFiles || [];
    const previews = this.referenceVideoPreviews || [];
    const grid = root.createDiv({ cls: "mangosteen-video-frame-grid" });
    files.forEach((file, index) => {
      const item = grid.createDiv({ cls: "mangosteen-video-frame-item" });
      const card = item.createDiv({ cls: "mangosteen-video-frame-upload" });
      if (previews[index]) {
        card.createEl("video", { cls: "mangosteen-video-frame-preview", attr: { src: previews[index], controls: "controls", muted: "muted", playsinline: "playsinline", preload: "metadata" } });
        card.createEl("span", { cls: "mangosteen-video-frame-caption", text: file.name });
      } else {
        const placeholder = card.createDiv({ cls: "mangosteen-video-frame-placeholder" });
        placeholder.createEl("strong", { text: file.name });
        placeholder.createEl("span", { text: "参考视频" });
      }
      const clear = item.createEl("button", { cls: "mangosteen-video-frame-clear", text: "移除", attr: { type: "button", "aria-label": `移除参考视频 ${file.name}` } });
      clear.addEventListener("click", () => {
        if (previews[index]) globalThis.URL?.revokeObjectURL?.(previews[index]);
        this.referenceVideoFiles = files.filter((_, itemIndex) => itemIndex !== index);
        this.referenceVideoPreviews = previews.filter((_, itemIndex) => itemIndex !== index);
        this.render();
      });
    });
    if (files.length < maxVideos) {
      const item = grid.createDiv({ cls: "mangosteen-video-frame-item" });
      const upload = item.createEl("label", { cls: "mangosteen-video-frame-upload", attr: { "aria-label": "选择参考视频" } });
      const input = upload.createEl("input", { attr: { type: "file", accept: "video/mp4,video/quicktime,.mp4,.mov", multiple: "multiple" } });
      const placeholder = upload.createDiv({ cls: "mangosteen-video-frame-placeholder" });
      placeholder.createEl("strong", { text: "选择参考视频" });
      placeholder.createEl("span", { text: `MP4、MOV，建议单个≤10MB，最多${maxVideos}段` });
      input.addEventListener("change", () => {
        const selected = Array.from(input.files || []);
        try {
          if (files.length + selected.length > maxVideos) throw new Error(`参考视频最多选择 ${maxVideos} 段。`);
          for (const file of selected) this.plugin.api.assertLocalVideoUpload(file);
          this.clearFrameImages();
          this.referenceVideoFiles = files.concat(selected);
          this.referenceVideoPreviews = previews.concat(selected.map((file) => globalThis.URL?.createObjectURL?.(file) || ""));
          this.advancedOpen = true;
          this.render();
        } catch (error) { this.status = error?.message || String(error); this.render(); }
      });
    }
    if (/^minimax-h3(?:\b|-)/i.test(String(model || ""))) {
      root.createEl("p", { cls: "mangosteen-video-help", text: "MiniMax 参考视频：单段 2–15 秒，总时长不超过 15 秒。" });
    }
  }

  clearReferenceVideos() {
    for (const preview of this.referenceVideoPreviews || []) if (preview) globalThis.URL?.revokeObjectURL?.(preview);
    this.referenceVideoFiles = [];
    this.referenceVideoPreviews = [];
  }

  renderTasks(root) {
    const list = root.createDiv({ cls: "mangosteen-video-task-list" });
    const tasks = this.plugin.settings.videoTasks || [];
    if (!tasks.length) {
      list.createEl("p", { text: "还没有视频任务，第一支小片子就从这里开始吧～" });
      return;
    }
    for (const task of tasks) {
      const card = list.createDiv({ cls: "mangosteen-video-task-card" });
      card.createEl("strong", { text: task.prompt || task.id });
      const terminal = ["failed", "completed", "stopped"].includes(task.status);
      const progressValue = Number.isFinite(task.progress) ? task.progress : task.status === "completed" ? 100 : task.status === "failed" ? 0 : null;
      const progress = card.createDiv({ cls: `mangosteen-video-progress${progressValue === null && !terminal ? " is-indeterminate" : ""}` });
      const bar = progress.createEl("span");
      if (progressValue !== null) bar.setAttr?.("style", `--mangosteen-progress:${progressValue}%`);
      const status = task.lastError || this.plugin.api.videoProgressText(task.status);
      card.createEl("div", { text: `${status}${Number.isFinite(task.progress) ? ` ${task.progress}%` : ""}` });
      const cost = Number.isFinite(task.cost) ? `$${task.cost.toFixed(4)}` : task.status === "stopped" ? "已停止" : terminal ? "正在同步任务详情" : "生成中";
      card.createEl("div", { cls: "mangosteen-video-task-meta", text: `${task.model} · ${task.createdAt || ""} · ${cost}` });
      if (task.usageLogDetail) {
        card.createEl("div", { cls: "mangosteen-video-task-log-detail", text: task.usageLogDetail });
        card.createEl("div", { cls: "mangosteen-video-task-log-meta", text: `请求ID：${task.usageRequestId || "未知"} · 令牌：${task.usageTokenName || "未知"} · 分组：${task.usageGroup || task.group || "未知"}` });
      }
      if (!terminal && !task.saved) {
        const actions = card.createDiv({ cls: "mangosteen-video-actions" });
        const stop = actions.createEl("button", { text: "终止", attr: { type: "button", "aria-label": `终止任务 ${task.prompt || task.id}` } });
        stop.addEventListener("click", () => void this.plugin.stopVideoTask(task.id));
      }
      if (task.localPath) {
        const resource = this.plugin.app?.vault?.adapter?.getResourcePath?.(task.localPath);
        if (resource) {
          const video = card.createEl("video");
          video.setAttr?.("src", resource);
          video.setAttr?.("controls", "true");
        }
        const open = card.createEl("button", { text: "打开视频文件" });
        open.addEventListener("click", () => void this.plugin.app?.workspace?.openLinkText?.(task.localPath, "", true));
      }
    }
  }

  refreshTasks() {
    if (!this.taskSection) return;
    this.taskSection.empty();
    this.taskSection.createEl("h3", { text: "最近任务" });
    this.renderTasks(this.taskSection);
  }

  render() {
    const root = this.contentEl;
    root.empty();
    const shell = root.createDiv({ cls: "mangosteen-video-shell" });
    const hero = shell.createDiv({ cls: "mangosteen-video-hero" });
    const copy = hero.createDiv();
    copy.createEl("h2", { text: "山竹视频" });
    copy.createEl("p", { text: "把灵感交给山竹，慢慢长成一支小短片～" });
    const market = copy.createDiv({ cls: "mangosteen-model-market" });
    market.createEl("a", { text: "https://shanzhu.aihubkit.com/pricing", attr: { href: "https://shanzhu.aihubkit.com/pricing", target: "_blank", rel: "noopener noreferrer" } });
    market.createEl("small", { text: "想查看更详细的价格和模型应用场景，可点击此链接前往模型广场。" });
    hero.createEl("div", { cls: "mangosteen-video-balance", text: Number.isFinite(this.balance) ? `余额：约 $${this.balance.toFixed(2)}` : "余额：读取中" });

    const section = shell.createDiv({ cls: "mangosteen-video-section" });
    const heading = section.createDiv({ cls: "mangosteen-video-actions" });
    heading.createEl("h3", { text: "创作视频" });
    const history = heading.createEl("button", { text: "任务记录" });
    history.addEventListener("click", () => this.plugin.openHistory());

    const models = this.accessLoaded ? Object.keys(this.plugin.videoAccess?.videoModelKeys || {}) : [];
    const model = addField(section, "视频模型", "select");
    for (const id of models) {
      const option = model.createEl("option", { text: this.modelLabel(id) });
      option.value = id;
    }
    model.value = models.includes(this.plugin.settings.model) ? this.plugin.settings.model : models[0] || "";
    model.addEventListener("change", () => {
      this.plugin.settings.model = model.value;
      const nextCapabilities = this.plugin.getVideoCapabilities(model.value);
      if (!nextCapabilities.maxImages) this.clearReferenceImages();
      if (!nextCapabilities.maxVideos) this.clearReferenceVideos();
      if (!supportsImageToVideo(model.value)) this.clearFrameImages();
      this.render();
    });

    const prompt = addField(section, "视频描述", "textarea");
    prompt.value = this.plugin.draftPrompt || "";
    prompt.addEventListener("input", () => { this.plugin.draftPrompt = prompt.value; });

    const capabilities = this.plugin.getVideoCapabilities(model.value);
    const capabilityLabel = capabilities.verification === "verified" ? "平台已确认" : capabilities.verification === "learned" ? "已自动校准" : capabilities.verification === "partial" ? "部分已确认" : "待平台校准";
    if (capabilities.maxPrompt) prompt.maxLength = capabilities.maxPrompt;
    const grid = section.createDiv({ cls: "mangosteen-video-grid" });
    const duration = addField(grid, `时长（${capabilities.minDuration}–${capabilities.maxDuration}秒，${capabilityLabel}）`, capabilities.durations.length ? "select" : "input", capabilities.durations.length ? {} : { type: "number" });
    duration.min = String(capabilities.minDuration);
    duration.max = String(capabilities.maxDuration);
    if (this.plugin.settings.duration < capabilities.minDuration || this.plugin.settings.duration > capabilities.maxDuration) this.plugin.settings.duration = capabilities.minDuration;
    const draftDuration = Number(this.draftDuration ?? this.plugin.settings.duration);
    if (capabilities.durations.length) {
      for (const value of capabilities.durations) { const option = duration.createEl("option", { text: `${value} 秒` }); option.value = String(value); }
      duration.value = String(capabilities.durations.includes(draftDuration) ? draftDuration : capabilities.durations[0]);
    } else {
      duration.value = String(draftDuration >= capabilities.minDuration && draftDuration <= capabilities.maxDuration ? draftDuration : capabilities.minDuration);
    }
    const updateDuration = () => { this.draftDuration = duration.value; this.refreshPrice?.(); };
    duration.addEventListener(capabilities.durations.length ? "change" : "input", updateDuration);
    grid.createEl("p", { cls: "mangosteen-video-help", text: this.plugin.api.videoDurationHint(capabilities) });
    const ratio = addField(grid, `画面比例（${capabilityLabel}）`, "select");
    if (!capabilities.ratios.includes(this.plugin.settings.ratio)) this.plugin.settings.ratio = capabilities.ratios[0];
    for (const value of capabilities.ratios) { const option = ratio.createEl("option", { text: value }); option.value = value; }
    ratio.value = capabilities.ratios.includes(this.draftRatio) ? this.draftRatio : this.plugin.settings.ratio;
    ratio.addEventListener("change", () => { this.draftRatio = ratio.value; });
    const resolution = addField(grid, `分辨率（${capabilityLabel}）`, "select");
    const resolutionOptions = this.plugin.getResolutionOptions(model.value);
    if (!resolutionOptions.includes(this.plugin.settings.resolution)) this.plugin.settings.resolution = resolutionOptions[0];
    for (const value of resolutionOptions) { const option = resolution.createEl("option", { text: value }); option.value = value; }
    resolution.value = resolutionOptions.includes(this.draftResolution) ? this.draftResolution : this.plugin.settings.resolution;
    resolution.addEventListener("change", () => { this.draftResolution = resolution.value; this.refreshPrice?.(); });

    const advanced = section.createEl("details", { cls: "mangosteen-video-advanced" });
    advanced.open = Boolean(this.advancedOpen);
    advanced.addEventListener("toggle", () => { this.advancedOpen = advanced.open; });
    advanced.createEl("summary", { text: "高级参考材料" });
    if (capabilities.maxImages) this.renderReferenceImageUploads(advanced, capabilities.maxImages);
    if (capabilities.maxVideos) this.renderReferenceVideoUploads(advanced, capabilities.maxVideos, model.value);

    const price = section.createDiv({ cls: "mangosteen-video-price" });
    this.refreshPrice = () => {
      const selectedDuration = Number(duration.value) || 0;
      const quote = this.plugin.getVideoPrice(model.value, resolution.value, selectedDuration, Boolean(this.referenceVideoFiles?.length));
      if (!quote) return price.setText("预计费用：首次使用该模型配置，完成后自动生成价格参考。");
      if (quote.unit === "output") return price.setText(`预计费用：约 $${quote.total.toFixed(4)}/条（参考上次实际结算）`);
      price.setText(`预计费用：约 $${quote.total.toFixed(4)}（参考上次实际结算 $${quote.amount.toFixed(4)}/秒 × ${selectedDuration}秒）`);
    };
    this.refreshPrice();

    const actions = section.createDiv({ cls: "mangosteen-video-actions" });
    const submit = actions.createEl("button", { cls: "mangosteen-video-primary", text: "生成视频" });
    submit.disabled = !models.length;
    const status = section.createEl("div", { cls: "mangosteen-video-status", text: this.status });
    this.statusEl = status;
    submit.addEventListener("click", async () => {
      submit.disabled = true;
      const hasUploads = Boolean(this.referenceImageFiles?.length || this.referenceVideoFiles?.length);
      status.setText(hasUploads ? "正在准备上传参考图片和视频，请稍作等待…" : "正在提交视频任务…");
      try {
        this.plugin.settings.duration = Number(duration.value);
        this.plugin.settings.ratio = ratio.value;
        this.plugin.settings.resolution = resolution.value;
        await this.plugin.saveSettings();
        await this.plugin.submitVideo({
          model: model.value,
          prompt: prompt.value,
          duration: Number(duration.value),
          ratio: ratio.value,
          resolution: resolution.value,
          referenceImages: [],
          referenceImageFiles: this.referenceImageFiles || [],
          referenceVideos: [],
          referenceVideoFiles: this.referenceVideoFiles || [],
          referenceAudios: [],
          firstImageFile: this.firstImageFile || null,
          lastImageFile: this.lastImageFile || null,
          onUploadProgress: (message) => status.setText(message),
        });
        this.plugin.draftPrompt = "";
        this.clearFrameImages();
        this.clearReferenceImages();
        this.clearReferenceVideos();
        this.status = "任务已经收好啦，关闭窗口也会继续生成～";
        this.plugin.writeOperation("创建任务", model.value);
      } catch (error) {
        this.status = this.plugin.videoSubmissionState?.message || this.plugin.api.toChineseVideoError(error);
        this.plugin.writeOperation("创建失败", this.status);
      } finally {
        submit.disabled = false;
        this.render();
      }
    });

    this.taskSection = shell.createDiv({ cls: "mangosteen-video-section" });
    this.refreshTasks();
  }
}

class VideoHistoryModal extends Modal {
  constructor(plugin) { super(plugin.app); this.plugin = plugin; }
  onOpen() {
    this.modalEl?.addClass?.("mangosteen-video-modal");
    (this.plugin.videoTaskViews ||= new Set()).add(this);
    this.contentEl.empty();
    this.taskSection = this.contentEl.createDiv({ cls: "mangosteen-video-shell" });
    this.refreshTasks();
    void this.plugin.refreshVideoTasks(true).then(() => this.plugin.refreshTaskUsageRecords());
  }
  onClose() { this.plugin.videoTaskViews?.delete(this); }
  refreshTasks() {
    this.taskSection.empty();
    this.taskSection.createEl("h2", { text: "山竹视频任务记录" });
    new VideoStudioModal(this.plugin).renderTasks(this.taskSection);
  }
}

module.exports = class MangosteenVideoPlugin extends Plugin {
  async onload() {
    if (!this.api) {
      const apiPath = resolvePluginFile(this, "video-api.cjs");
      if (!fs.existsSync(apiPath)) {
        const error = new Error("山竹视频插件文件不完整：缺少 video-api.cjs");
        error.code = "MANGOSTEEN_HELPER_MISSING";
        new Notice("山竹视频插件文件不完整，请重新安装或更新插件。");
        throw error;
      }
      try {
        this.api = require(apiPath);
      } catch (cause) {
        const error = new Error("山竹视频插件加载失败，请重新安装或把错误截图发给售后老师。");
        error.code = "MANGOSTEEN_HELPER_LOAD_FAILED";
        error.cause = cause;
        new Notice(error.message);
        throw error;
      }
    }
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData?.());
    this.videoTaskViews = new Set();
    this.videoSubmissionInFlight = false;
    this.videoSubmissionState = null;
    if (!this.settings.resolutionsByModel || typeof this.settings.resolutionsByModel !== "object") this.settings.resolutionsByModel = {};
    if (!this.settings.videoCapabilitiesByModel || typeof this.settings.videoCapabilitiesByModel !== "object") this.settings.videoCapabilitiesByModel = {};
    this.addRibbonIcon?.("video", "打开山竹视频", () => this.openStudio());
    if (typeof this.registerInterval === "function") {
      const poll = window.setInterval(() => {
        if ((this.settings.videoTasks || []).some((task) => !task.saved && !["failed", "completed", "stopped"].includes(task.status))) void this.refreshVideoTasks();
        if ((this.settings.videoTasks || []).some((task) => ["completed", "failed"].includes(task.status) && !task.usageLogMatched)) void this.refreshTaskUsageRecords();
      }, 7000);
      const balance = window.setInterval(() => void this.updateBalance(), 30 * 60 * 1000);
      poll?.unref?.();
      balance?.unref?.();
      this.registerInterval(poll);
      this.registerInterval(balance);
    }
  }

  openStudio() { new VideoStudioModal(this).open(); }
  openHistory() { new VideoHistoryModal(this).open(); }

  async saveSettings() {
    if (typeof this.saveData === "function") await this.saveData(this.settings);
  }

  setVideoSubmissionState(state) {
    this.videoSubmissionState = state;
    if (!state?.message) return;
    for (const view of this.videoTaskViews || []) view.updateSubmissionStatus?.(state.message);
  }

  request(options, timeoutMs = 45000) { return this.api?.withTimeout ? this.api.withTimeout(requestUrl(options), timeoutMs, "视频服务请求") : requestUrl(options); }

  async refreshAgentAccess() {
    const mediaCore = this.app?.plugins?.getPlugin?.("mangosteen-media-core") || this.app?.plugins?.plugins?.["mangosteen-media-core"];
    const bridge = mediaCore?.getAccountBridge?.();
    const revision = bridge?.getCatalogRevision?.();
    const previousAccess = this.videoAccess;
    const access = await bridge?.resolveVideoAccess?.();
    if (revision !== undefined && revision !== bridge.getCatalogRevision()) {
      if (this.videoAccess === previousAccess) this.videoAccess = null;
      throw new Error("视频模型目录正在更新，请稍后重试。");
    }
    if (!access?.balanceKey || !Object.keys(access.videoModelKeys || {}).length) {
      this.videoAccess = null;
      throw new Error(mediaCore?.getAccountBridge?.()?.getAccountUserId?.()
        ? "视频模型暂未同步，请在山竹账号中心点击重新获取；若仍为空，请确认已开通视频分组。"
        : "请先打开“山竹账号中心”完成登录，并确认账号已开通视频分组。");
    }
    this.videoAccess = access;
    const models = Object.keys(access.videoModelKeys);
    if (!models.includes(this.settings.model)) this.settings.model = models[0];
    return access;
  }

  getVideoKeyCandidates(model = this.settings.model) {
    const listed = this.videoAccess?.videoModelKeyCandidates?.[model] || [];
    if (listed.length) return listed.filter((item) => item?.key);
    const key = this.videoAccess?.videoModelKeys?.[model];
    return key ? [{ group: "", key }] : [];
  }

  getResolutionOptions(model = this.settings.model) {
    return this.api.resolutionOptionsForModel(model, this.settings.videoCapabilitiesByModel?.[model] || this.settings.resolutionsByModel?.[model]);
  }

  getVideoCapabilities(model = this.settings.model) {
    return this.api.videoCapabilitiesForModel(model, this.settings.videoCapabilitiesByModel?.[model] || this.settings.resolutionsByModel?.[model]);
  }

  getVideoPrice(model, resolution, duration, hasReferenceVideo) {
    const accountUserId = String(this.videoAccess?.accountUserId || "");
    if (!accountUserId) return null;
    const task = (this.settings.videoTasks || []).find((item) => {
      const owner = String(item.accountUserId || item.usageAccountUserId || "");
      const payload = item.payload || {};
      const usedReferenceVideo = Number(item.referenceVideoCount) > 0 || (Array.isArray(payload.referenceVideos) && payload.referenceVideos.length > 0);
      return item.status === "completed" && item.usageLogMatched && item.cost != null && item.cost !== "" && Number.isFinite(Number(item.cost))
        && owner === accountUserId
        && item.model === model && String(payload.resolution || "") === String(resolution || "")
        && usedReferenceVideo === Boolean(hasReferenceVideo) && Number(payload.duration) > 0;
    });
    if (!task) return null;
    const billingUnit = this.api.videoPriceForSelection(model, resolution, 1, hasReferenceVideo)?.unit === "output" ? "output" : "second";
    if (billingUnit === "output") {
      const amount = Number(Number(task.cost).toFixed(4));
      return { amount, unit: "output", total: amount };
    }
    const rawAmount = Number(task.cost) / Number(task.payload.duration);
    const amount = Number(rawAmount.toFixed(4));
    return { amount, unit: "second", total: Number((rawAmount * (Number(duration) || 0)).toFixed(4)) };
  }

  extractApiError(json, status) {
    return String(json?.error?.message || json?.message || json?.error?.code || json?.error || json?.code || `请求失败（${status}）`);
  }

  async requestWithVideoKeyFallback(request, model = this.settings.model, preferredGroup = "") {
    await this.refreshAgentAccess();
    const candidates = this.getVideoKeyCandidates(model);
    if (preferredGroup) candidates.sort((a, b) => Number(b.group === preferredGroup) - Number(a.group === preferredGroup));
    if (!candidates.length) throw new Error("当前模型没有可用的视频 API Key");
    let response;
    for (const candidate of candidates) {
      response = await request(candidate.key);
      response.__mangosteenGroup = candidate.group;
      if (response.status < 400 || !this.api.shouldTryNextVideoKey(response)) return response;
    }
    return response;
  }

  async sendVideoPayload(payload) {
    return this.requestWithVideoKeyFallback((key) => this.request({
      url: `${API_BASE}/v1/videos`,
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      throw: false,
    }), payload.model);
  }

  async getRawQuota() {
    await this.refreshAgentAccess();
    const request = this.api.createBalanceRequest(this.videoAccess.balanceKey);
    const response = await this.request({ url: `${API_BASE}${request.path}`, method: "GET", headers: request.headers, throw: false });
    if (response.status >= 400) throw new Error(this.extractApiError(response.json, response.status));
    return Number(response.json?.data?.quota);
  }

  async getQuota() { return this.api.readQuota({ data: { quota: await this.getRawQuota() } }); }

  async updateBalance() {
    this.lastBalance = await this.getQuota().catch(() => null);
    return this.lastBalance;
  }

  async rememberVideoTask(task) {
    const payload = Object.assign({}, task.payload);
    const referenceVideoCount = Array.isArray(payload.referenceVideos) ? payload.referenceVideos.length : 0;
    delete payload.referenceImages;
    delete payload.referenceVideos;
    delete payload.referenceAudios;
    delete payload.first_image;
    delete payload.last_image;
    const saved = Object.assign({
      accountUserId: String(this.videoAccess?.accountUserId || ""),
      createdAt: new Date().toISOString(),
      status: "queued",
      progress: null,
      saved: false,
      lastError: "",
    }, task, { payload, referenceVideoCount });
    this.settings.videoTasks = [saved, ...(this.settings.videoTasks || []).filter((item) => item.id !== saved.id)].slice(0, 50);
    await this.saveSettings();
    return saved;
  }

  async refreshTaskUsageRecords() {
    const mediaCore = this.app?.plugins?.getPlugin?.("mangosteen-media-core") || this.app?.plugins?.plugins?.["mangosteen-media-core"];
    const bridge = mediaCore?.getAccountBridge?.();
    const accountUserId = String(bridge?.getAccountUserId?.() || "");
    const tasks = (this.settings.videoTasks || []).filter((task) => ["completed", "failed"].includes(task.status) && (!task.usageLogMatched || !task.accountUserId) && (!task.accountUserId || String(task.accountUserId) === accountUserId));
    if (!tasks.length) return;
    const result = await bridge?.matchMediaUsage?.(tasks.map((task) => Object.assign({ kind: "video" }, task)));
    if (!result?.ok) return;
    let changed = false;
    for (const task of tasks) {
      const match = result.matches?.[task.id];
      if (!match) continue;
      Object.assign(task, {
        accountUserId: match.accountUserId || task.accountUserId || accountUserId,
        cost: Number(match.costUsd),
        usageLogMatched: true,
        usageLogDetail: match.detail || "平台已记录本次任务",
        usageRequestId: match.requestId || "",
        usageTokenName: match.tokenName || "",
        usageGroup: match.group || task.group || "",
        usageAccountUserId: match.accountUserId || accountUserId,
      });
      changed = true;
    }
    if (!changed) return;
    await this.saveSettings();
    for (const view of this.videoTaskViews || []) { view.refreshTasks?.(); view.refreshPrice?.(); }
  }

  async submitVideo(options) {
    if (this.videoSubmissionInFlight) throw new Error("已有素材正在上传或任务正在提交，请稍候，不要重复点击生成。");
    this.videoSubmissionInFlight = true;
    this.setVideoSubmissionState({ phase: "preparing", message: "正在准备素材上传，暂未获取到任务编号。请稍作等待，不要重复点击生成。" });
    try {
      const task = await this.performVideoSubmission(options);
      this.setVideoSubmissionState({ phase: "submitted", message: "视频任务已提交，正在等待生成。可以关闭当前窗口。" });
      this.videoSubmissionState = null;
      return task;
    } catch (error) {
      const detail = this.api.redactLogText(error?.message || error || "未知错误");
      const message = error?.videoTaskId
        ? `视频任务 ${error.videoTaskId} 已创建，但本地记录失败。请不要重复提交，把诊断日志发给售后老师。`
        : `素材上传或任务提交失败，未获取到任务编号。可以重新点击生成。原因：${detail}`;
      this.setVideoSubmissionState({ phase: error?.videoTaskId ? "record_failed" : "failed", message });
      throw error;
    } finally {
      this.videoSubmissionInFlight = false;
    }
  }

  async performVideoSubmission(options) {
    if (!this.settings.videoCapabilitiesByModel || typeof this.settings.videoCapabilitiesByModel !== "object") this.settings.videoCapabilitiesByModel = {};
    if (!this.settings.resolutionsByModel || typeof this.settings.resolutionsByModel !== "object") this.settings.resolutionsByModel = {};
    const learnedCapabilities = this.settings.videoCapabilitiesByModel?.[options.model] || this.settings.resolutionsByModel?.[options.model];
    const payloadOptions = Object.assign({}, options, { learnedCapabilities });
    const externalReportUpload = typeof payloadOptions.onUploadProgress === "function" ? payloadOptions.onUploadProgress : () => undefined;
    delete payloadOptions.onUploadProgress;
    const referenceImageFiles = Array.from(payloadOptions.referenceImageFiles || []);
    const referenceVideoFiles = Array.from(payloadOptions.referenceVideoFiles || []);
    const uploadTotal = referenceImageFiles.length + referenceVideoFiles.length + Number(Boolean(payloadOptions.firstImageFile)) + Number(Boolean(payloadOptions.lastImageFile));
    let uploadIndex = 0;
    const reportUpload = (phase, message) => { this.setVideoSubmissionState({ phase, message }); externalReportUpload(message); };
    const reportFileUpload = (label) => reportUpload("uploading", `素材正在上传：${label}（${++uploadIndex}/${uploadTotal}），暂未获取到任务编号。可以关闭当前窗口，上传和提交会继续进行。`);
    const capabilities = this.api.videoCapabilitiesForModel(options.model, learnedCapabilities);
    const referenceImages = Array.isArray(payloadOptions.referenceImages) ? payloadOptions.referenceImages.slice() : [];
    const referenceVideos = Array.isArray(payloadOptions.referenceVideos) ? payloadOptions.referenceVideos.slice() : [];
    if (referenceImages.length + referenceImageFiles.length > capabilities.maxImages) throw new Error(`参考图片最多填写 ${capabilities.maxImages} 个`);
    if (referenceVideos.length + referenceVideoFiles.length > capabilities.maxVideos) throw new Error(`参考视频最多填写 ${capabilities.maxVideos} 个`);
    for (const file of referenceImageFiles) this.api.assertLocalImageUploadSize(file);
    for (const file of referenceVideoFiles) this.api.assertLocalVideoUpload(file);
    for (const [label, urlField, fileField] of [["首帧", "firstImage", "firstImageFile"], ["尾帧", "lastImage", "lastImageFile"]]) {
      if (String(payloadOptions[urlField] || "").trim() && payloadOptions[fileField]) throw new Error(label + "请只选图片 URL 或本地图片，不要同时填写。");
    }
    this.api.createVideoPayload(payloadOptions);
    const hasLocalFiles = referenceImageFiles.length || referenceVideoFiles.length || payloadOptions.firstImageFile || payloadOptions.lastImageFile;
    const bridge = hasLocalFiles ? this.app?.plugins?.getPlugin?.("mangosteen-media-core")?.getAccountBridge?.() : null;
    if (referenceImageFiles.length && !bridge?.uploadTemporaryImage) throw new Error("请先登录山竹账号中心，再上传参考图片。");
    for (const file of referenceImageFiles) {
      reportFileUpload("参考图片");
      let bytes;
      try { bytes = await this.api.withTimeout(file.arrayBuffer(), 30000, "参考图片读取"); } catch (_) { throw new Error("参考图片读取失败，视频任务尚未提交，请重新选择文件。"); }
      const uploaded = await this.api.withTimeout(bridge.uploadTemporaryImage({ name: file.name, type: this.api.localImageMimeType(file), bytes }), MATERIAL_UPLOAD_TIMEOUT_MS, "参考图片上传");
      if (!uploaded?.ok) throw new Error("参考图片上传失败，视频任务尚未提交。请检查网络、文件格式或重新登录后重试。");
      referenceImages.push(uploaded.url);
    }
    payloadOptions.referenceImages = referenceImages;
    delete payloadOptions.referenceImageFiles;
    if (referenceVideoFiles.length && !bridge?.uploadTemporaryVideo) throw new Error("请先登录山竹账号中心，再上传参考视频。");
    for (const file of referenceVideoFiles) {
      reportFileUpload("参考视频");
      let bytes;
      try { bytes = await this.api.withTimeout(file.arrayBuffer(), 30000, "参考视频读取"); } catch (_) { throw new Error("参考视频读取失败，视频任务尚未提交，请重新选择文件。"); }
      const uploaded = await this.api.withTimeout(bridge.uploadTemporaryVideo({ name: file.name, type: this.api.localVideoMimeType(file), bytes }), MATERIAL_UPLOAD_TIMEOUT_MS, "参考视频上传");
      if (!uploaded?.ok) throw new Error("参考视频上传失败，视频任务尚未提交。请检查网络、文件格式、文件大小或重新登录后重试。");
      referenceVideos.push(uploaded.url);
    }
    payloadOptions.referenceVideos = referenceVideos;
    delete payloadOptions.referenceVideoFiles;
    for (const [label, urlField, fileField] of [["首帧", "firstImage", "firstImageFile"], ["尾帧", "lastImage", "lastImageFile"]]) {
      const file = payloadOptions[fileField];
      if (!file) continue;
      reportFileUpload(label + "图片");
      this.api.assertLocalImageUploadSize(file);
      if (!bridge?.uploadTemporaryImage) throw new Error("请先登录山竹账号中心，再上传" + label + "图片。");
      let bytes;
      try { bytes = await this.api.withTimeout(file.arrayBuffer(), 30000, label + "图片读取"); } catch (_) { throw new Error(label + "图片读取失败，视频任务尚未提交，请重新选择文件。"); }
      const uploaded = await this.api.withTimeout(bridge.uploadTemporaryImage({ name: file.name, type: this.api.localImageMimeType(file), bytes }), MATERIAL_UPLOAD_TIMEOUT_MS, label + "图片上传");
      if (!uploaded?.ok) throw new Error(label + "图片上传失败，视频任务尚未提交。请检查网络、文件格式或重新登录后重试。");
      payloadOptions[urlField] = uploaded.url;
    }
    if (uploadTotal) reportUpload("submitting", "素材上传完成，正在提交视频任务…");
    let payload = this.api.createVideoPayload(payloadOptions);
    const beforeQuota = await this.getRawQuota().catch(() => null);
    let response = await this.sendVideoPayload(payload);
    const feedback = this.api.readVideoCapabilityFeedback(response);
    const canSafelyRetry = response.status >= 400 && response.status < 500
      && !this.api.extractVideoTaskId(response.json)
      && Object.keys(feedback).length > 0;
    if (canSafelyRetry) {
      const learned = this.api.mergeVideoCapabilityFeedback(this.settings.videoCapabilitiesByModel[payload.model], feedback);
      this.settings.videoCapabilitiesByModel[payload.model] = learned;
      if (feedback.resolutions?.length) {
        this.settings.resolutionsByModel[payload.model] = feedback.resolutions;
        this.settings.resolution = feedback.resolutions[0];
      }
      if (feedback.ratios?.length) this.settings.ratio = feedback.ratios[0];
      if (feedback.durations?.length) this.settings.duration = feedback.durations[0];
      await this.saveSettings();
      const corrected = this.api.applyVideoCapabilityFeedback(payload, feedback);
      if (corrected.resolution !== payload.resolution || corrected.ratio !== payload.ratio || corrected.duration !== payload.duration) {
        payload = this.api.createVideoPayload(Object.assign({}, payloadOptions, corrected, { learnedCapabilities: learned }));
        response = await this.sendVideoPayload(payload);
      }
    }
    if (response.status >= 400) throw new Error(this.extractApiError(response.json, response.status));
    const id = this.api.extractVideoTaskId(response.json);
    if (!id) throw new Error("平台已接收请求，但没有返回视频任务编号。");
    try {
      return await this.rememberVideoTask({
        id,
        model: payload.model,
        prompt: payload.prompt,
        payload,
        group: response.__mangosteenGroup,
        beforeQuota,
      });
    } catch (error) {
      error.videoTaskId = id;
      throw error;
    }
  }

  async fetchVideoTask(task) {
    const response = await this.requestWithVideoKeyFallback((key) => this.request({
      url: `${API_BASE}/v1/videos/${encodeURIComponent(task.id)}`,
      method: "GET",
      headers: { Authorization: `Bearer ${key}` },
      throw: false,
    }), task.model, task.group);
    if (response.status >= 400) {
      const error = new Error(this.extractApiError(response.json, response.status));
      error.status = response.status;
      throw error;
    }
    return response.json;
  }

  async ensureVaultFolder(folder) {
    if (!this.app?.vault?.getAbstractFileByPath?.(folder)) await this.app.vault.createFolder(folder);
  }

  async saveCompletedVideo(task, response) {
    const state = this.api.readVideoTask(response);
    const contentUrl = `${API_BASE}/v1/videos/${encodeURIComponent(task.id)}/content`;
    const key = this.getVideoKeyCandidates(task.model).find((item) => item.group === task.group)?.key || this.getVideoKeyCandidates(task.model)[0]?.key;
    let download;
    if (state.url) {
      download = await this.request({ url: state.url, method: "GET", throw: false }, 120000);
    }
    if (!download || download.status >= 400 || !download.arrayBuffer) {
      if (!key) throw new Error("无法找到该任务的视频 API Key");
      download = await this.request({ url: contentUrl, method: "GET", headers: { Authorization: `Bearer ${key}` }, throw: false }, 120000);
    }
    if (download.status >= 400 || !download.arrayBuffer) throw new Error("视频已经生成，但保存失败，请稍后重新保存。");
    this.api.assertVideoDownloadSize(download);
    const root = "山竹视频";
    const folder = `${root}/${this.api.safeVideoTaskSegment(task.id)}`;
    await this.ensureVaultFolder(root);
    await this.ensureVaultFolder(folder);
    const filePath = `${folder}/${this.api.safeVideoFilename(`${task.prompt || task.id}.mp4`)}`;
    const existing = this.app.vault.getAbstractFileByPath?.(filePath);
    if (existing && typeof this.app.vault.modifyBinary === "function") await this.app.vault.modifyBinary(existing, Buffer.from(download.arrayBuffer));
    else await this.app.vault.createBinary(filePath, Buffer.from(download.arrayBuffer));
    return filePath;
  }

  async refreshVideoTasks(recheckFailed = false) {
    if (this.videoTasksRefreshPromise) return this.videoTasksRefreshPromise;
    this.videoTasksRefreshPromise = this.refreshVideoTasksNow(recheckFailed);
    try { return await this.videoTasksRefreshPromise; } finally { this.videoTasksRefreshPromise = null; }
  }

  async stopVideoTask(taskId) {
    const task = (this.settings.videoTasks || []).find((item) => item.id === taskId);
    if (!task || task.saved || ["failed", "completed", "stopped"].includes(task.status)) return false;
    task.status = "stopped";
    task.stoppedAt = new Date().toISOString();
    task.lastError = "已终止自动查询，不会继续向服务器发送该任务请求。";
    await this.saveSettings();
    for (const view of this.videoTaskViews || []) view.refreshTasks?.();
    this.writeOperation("终止查询", task.id);
    return true;
  }

  async refreshVideoTasksNow(recheckFailed = false) {
    for (const task of this.settings.videoTasks || []) {
      if (task.saved || task.status === "stopped" || (task.status === "failed" && !recheckFailed)) continue;
      try {
        const response = await this.fetchVideoTask(task);
        if (task.status === "stopped") continue;
        const state = this.api.readVideoTask(response);
        task.lastCheckedAt = new Date().toISOString();
        task.lastError = "";
        task.progress = state.progress;
        if (state.status === "failed") {
          task.status = "failed";
          task.lastError = this.api.toChineseVideoError(state.error || "平台视频任务失败");
          continue;
        }
        if (state.status === "completed") {
          if (task.status === "failed") {
            task.usageLogMatched = false;
            task.usageLogDetail = "";
          }
          task.status = "saving";
          task.localPath = await this.saveCompletedVideo(task, response);
          task.afterQuota = await this.getRawQuota().catch(() => null);
          task.cost = this.api.calculateCost(task.beforeQuota, task.afterQuota);
          task.saved = true;
          task.status = "completed";
          continue;
        }
        if (state.status === "unknown") {
          task.status = "unknown";
          task.lastError = "暂未取得有效任务状态，稍后自动重试。";
          continue;
        }
        task.status = state.status === "queued" ? "queued" : "in_progress";
      } catch (error) {
        if (task.status === "stopped") continue;
        const saving = task.status === "saving";
        task.lastCheckedAt = new Date().toISOString();
        if (!saving && this.api.isTerminalVideoTaskQueryError(error)) {
          task.status = "stopped";
          task.stoppedAt = task.lastCheckedAt;
          task.lastError = "平台找不到这个视频任务，已停止自动查询，不会继续向服务器发送请求。";
        } else {
          task.status = "retrying";
          task.lastError = this.api.toChineseVideoError(error).replace(/^视频生成失败：/, saving ? "视频已生成，但保存失败：" : "视频状态查询失败：");
        }
      }
    }
    await this.saveSettings();
    for (const view of this.videoTaskViews || []) { view.refreshTasks?.(); view.refreshPrice?.(); }
    void this.refreshTaskUsageRecords();
  }

  writeOperation(step, detail) {
    try {
      const base = this.app?.vault?.adapter?.basePath;
      if (!base) return;
      const folder = path.join(base, ".mangosteen-video", "logs");
      fs.mkdirSync(folder, { recursive: true });
      const log = path.join(folder, "operations.log");
      if (fs.existsSync(log) && fs.statSync(log).size >= 2 * 1024 * 1024) fs.renameSync(log, path.join(folder, "operations.old.log"));
      fs.appendFileSync(log, `[${new Date().toISOString()}] ${this.api.redactLogText(step)} | ${this.api.redactLogText(detail)}\n`, "utf8");
    } catch (_) { /* logging cannot block generation */ }
  }
};
