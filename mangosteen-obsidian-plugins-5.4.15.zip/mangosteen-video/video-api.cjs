const QUOTA_PER_USD = 500000;
const DEFAULT_VIDEO_DOWNLOAD_LIMIT = 1024 * 1024 * 1024;
const MAX_LOCAL_IMAGE_UPLOAD_BYTES = 20 * 1024 * 1024;
const WINDOWS_RESERVED_NAME = /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i;
const VIDEO_PROGRESS_INTERVAL_MS = 5000;
const VIDEO_PROGRESS_ACTIONS = ["正在整理镜头顺序", "正在合成画面和节奏", "正在检查画面连贯性", "正在补齐最后的镜头细节", "正在把创意变成视频"];
const VIDEO_PROGRESS_COMPANIONS = ["可以先喝口咖啡～", "我会一直在这里守着～", "不妨翻两页笔记本～", "马上就能看到成片啦～", "先别关闭这个窗口呀～", "正在认真处理，请稍等～", "视频任务已经稳稳排队～", "好画面值得多等一小会儿～"];
const COMMON_VIDEO_RATIOS = ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"];
const KLING_RATIOS = ["16:9", "9:16", "1:1"];
const SEEDANCE_20_PROFILE = { resolutions: ["480p", "720p", "1080p"], ratios: COMMON_VIDEO_RATIOS, minDuration: 4, maxDuration: 15, maxPrompt: 10000, maxImages: 9, maxVideos: 3, maxAudios: 3, verification: "verified" };
const SEEDANCE_25_PROFILE = { resolutions: ["480p", "720p", "1080p"], ratios: COMMON_VIDEO_RATIOS, minDuration: 4, maxDuration: 30, maxPrompt: 15000, maxImages: 30, maxVideos: 10, maxAudios: 10, verification: "verified" };
const KLING_PROFILE = { resolutions: ["720p", "1080p"], ratios: KLING_RATIOS, minDuration: 4, maxDuration: 15, maxPrompt: 2500, maxImages: 3, maxVideos: 3, maxAudios: 0, verification: "verified" };
const KLING_40_PROFILE = { resolutions: ["720p", "1080p"], ratios: KLING_RATIOS, minDuration: 5, maxDuration: 30, maxPrompt: 2500, maxImages: 10, maxVideos: 5, maxAudios: 5, verification: "verified" };
const MINIMAX_PROFILE = { resolutions: ["768p", "2k"], ratios: COMMON_VIDEO_RATIOS, minDuration: 4, maxDuration: 15, maxPrompt: null, maxImages: 9, maxVideos: 3, maxAudios: 3, verification: "verified" };
const MINIMAX_30_PROFILE = { ...MINIMAX_PROFILE, minDuration: 4, maxDuration: 30, maxVideos: 3 };
const WAN3_PROFILE = { resolutions: ["480p", "720p", "1080p"], ratios: ["16:9", "9:16", "1:1"], minDuration: 2, maxDuration: 30, maxPrompt: null, maxImages: 10, maxVideos: 5, maxAudios: 5, verification: "partial" };

const MODEL_PROFILES = {
  "klingo3": { ...KLING_PROFILE, prices: { output: 2 } },
  "kling-4.0": KLING_40_PROFILE,
  "minimax-h3": { ...MINIMAX_PROFILE, prices: { "768p": 0.18, "2k": 0.28 } },
  "minimax-h3-30s": MINIMAX_30_PROFILE,
  "sd-2.0-fast": { ...SEEDANCE_20_PROFILE, resolutions: ["480p", "720p"], prices: { "480p": 0.2, "720p": 0.42 }, referenceVideoPrices: { "480p": 0.24, "720p": 0.5 } },
  "sd-2.0-mini": { ...SEEDANCE_20_PROFILE, resolutions: ["480p", "720p"], prices: { "480p": 0.14, "720p": 0.27 }, referenceVideoPrices: { "480p": 0.19, "720p": 0.27 } },
  "sd-2.0-stable": { ...SEEDANCE_20_PROFILE, prices: { "480p": 0.42, "720p": 0.62, "1080p": 1.42 } },
  "sd-2.0-v2": { ...SEEDANCE_20_PROFILE, maxVideos: 0 },
  "sd-2.0-720p": { ...SEEDANCE_20_PROFILE, maxVideos: 0 },
  "sd-2.5-chaofen": { ...SEEDANCE_25_PROFILE, maxVideos: 0 },
  "muse-video": { maxVideos: 0, verification: "verified" },
  "seedance-2.5": { ...SEEDANCE_25_PROFILE, prices: { "480p": 0.5, "720p": 1.07, "1080p": 1.63 } },
  "seedance-2.5_k1": { ...SEEDANCE_25_PROFILE, prices: { "480p": 0.36, "720p": 0.65 }, referenceVideoPrices: { "480p": 0.43, "720p": 0.75 } },
  "seedance-2.5_y2": { ...SEEDANCE_25_PROFILE, prices: { "480p": 0.43, "720p": 0.65, "1080p": 1.43 } },
  "wan3.0-r2v-k1": { ...WAN3_PROFILE, prices: { "480p": 0.26, "720p": 0.35, "1080p": 0.53 } },
  "wan3.0-r2v-m1": { ...WAN3_PROFILE, resolutions: ["720p", "1080p"], verification: "verified" },
  "wan3.0-video-prime": { ...WAN3_PROFILE, resolutions: ["720p", "1080p"], verification: "verified", prices: { "480p": 0.27, "720p": 0.54, "1080p": 1.08 } },
  "digitalhuman": { maxImages: 0, verification: "verified" },
};

const clean = (value) => String(value || "").trim();
const isPublicUrl = (value) => /^https?:\/\/[^\s]+$/i.test(clean(value));

function localImageMimeType(file) {
  return clean(file?.type).toLowerCase()
    || (/\.webp$/i.test(file?.name) ? "image/webp" : /\.jpe?g$/i.test(file?.name) ? "image/jpeg" : "image/png");
}

function assertLocalImageUploadSize(file, maxBytes = MAX_LOCAL_IMAGE_UPLOAD_BYTES) {
  const size = Number(file?.size ?? file?.byteLength);
  if (Number.isFinite(size) && size > maxBytes) throw new Error("所选图片超过 20 MB，请压缩后重试。");
}

function localVideoMimeType(file) {
  const declared = clean(file?.type).toLowerCase();
  if (["video/mp4", "video/quicktime"].includes(declared)) return declared;
  return /\.mp4$/i.test(file?.name) ? "video/mp4" : /\.mov$/i.test(file?.name) ? "video/quicktime" : "";
}

function assertLocalVideoUpload(file) {
  if (!localVideoMimeType(file)) throw new Error("参考视频仅支持 MP4、MOV 格式。");
}

function validateUrls(values, label, limit) {
  const urls = (values || []).map(clean).filter(Boolean);
  if (urls.length > limit) throw new Error(`${label}最多填写 ${limit} 个`);
  if (urls.some((url) => !isPublicUrl(url))) throw new Error("参考材料仅支持公开 HTTP/HTTPS 地址");
  return urls;
}

function createVideoPayload(options = {}) {
  const model = clean(options.model);
  const prompt = clean(options.prompt);
  const duration = Number(options.duration);
  const ratio = clean(options.ratio) || "16:9";
  const resolution = clean(options.resolution) || "720p";
  if (!model) throw new Error("请选择视频模型");
  const capabilities = videoCapabilitiesForModel(model, options.learnedCapabilities || options.allowedResolutions);
  if (!prompt) throw new Error("请先描述想生成的视频");
  if (capabilities.maxPrompt && prompt.length > capabilities.maxPrompt) throw new Error(`${model} 的视频描述不能超过 ${capabilities.maxPrompt} 个字符`);
  if (!Number.isInteger(duration) || duration < capabilities.minDuration || duration > capabilities.maxDuration) throw new Error(`视频时长必须是 ${capabilities.minDuration} 到 ${capabilities.maxDuration} 秒`);
  if (capabilities.durations.length && !capabilities.durations.includes(duration)) throw new Error(`${model} 的视频时长仅支持 ${capabilities.durations.join("、")} 秒`);
  if (!capabilities.ratios.includes(ratio)) throw new Error(`${model} 的视频比例仅支持 ${capabilities.ratios.join("、")}`);
  if (!capabilities.resolutions.includes(resolution)) throw new Error(`${model} 的分辨率仅支持 ${capabilities.resolutions.join("、")}`);
  const payload = { model, prompt, duration, ratio, resolution };
  const hasFirstOrLastFrame = clean(options.firstImage) || clean(options.lastImage) || options.firstImageFile || options.lastImageFile;
  const hasGeneralReferences = [options.referenceImages, options.referenceVideos, options.referenceAudios]
    .some((values) => Array.isArray(values) && values.some((value) => clean(value)))
    || Boolean(options.referenceImageFiles?.length) || Boolean(options.referenceVideoFiles?.length);
  if (hasFirstOrLastFrame && hasGeneralReferences) throw new Error("首尾帧和高级参考材料不能同时使用，请保留其中一种。");
  const referenceImages = validateUrls(options.referenceImages, "参考图片", capabilities.maxImages);
  const referenceVideos = validateUrls(options.referenceVideos, "参考视频", capabilities.maxVideos);
  const referenceAudios = validateUrls(options.referenceAudios, "参考音频", capabilities.maxAudios);
  if (referenceImages.length) payload.referenceImages = referenceImages;
  if (referenceVideos.length) payload.referenceVideos = referenceVideos;
  if (referenceAudios.length) payload.referenceAudios = referenceAudios;
  if (options.generateAudio) payload.generate_audio = true;
  for (const [option, field] of [["firstImage", "first_image"], ["lastImage", "last_image"]]) {
    const url = clean(options[option]);
    if (url && !isPublicUrl(url)) throw new Error("首尾帧仅支持公开 HTTP/HTTPS 图片地址");
    if (url) payload[field] = url;
  }
  if (payload.first_image || payload.last_image) delete payload.ratio;
  return payload;
}

function extractVideoTaskId(response) {
  return clean(response?.task_id || response?.id || response?.data?.task_id || response?.data?.id);
}

function readVideoTask(response = {}) {
  const data = response?.data && !Array.isArray(response.data) ? response.data : response;
  return {
    id: extractVideoTaskId(response),
    status: clean(response.status || data.status || response.state || data.state || "unknown").toLowerCase(),
    progress: Number.isFinite(Number(response.progress ?? data.progress)) ? Math.max(0, Math.min(100, Number(response.progress ?? data.progress))) : null,
    url: clean(response.url || data.url),
    error: clean(response?.error?.message || response?.message || data?.error?.message || data?.message),
  };
}

function readAllowedResolutions(response = {}) {
  return readVideoCapabilityFeedback(response).resolutions || [];
}

function resolutionOptionsForModel(model, learned = []) {
  return videoCapabilitiesForModel(model, learned).resolutions;
}

function modelProfile(model) {
  const id = clean(model).toLowerCase();
  if (MODEL_PROFILES[id]) return MODEL_PROFILES[id];
  if (/^klingo3(?:\b|-)/i.test(id)) return KLING_PROFILE;
  if (/^minimax-h3(?:\b|-)/i.test(id)) return MINIMAX_PROFILE;
  if (/^(?:seedance-2\.5|sd-2\.5)(?:\b|[_-])/i.test(id)) return SEEDANCE_25_PROFILE;
  if (/^sd-2\.0(?:\b|[_-])/i.test(id)) return /(?:fast|mini)/i.test(id) ? { ...SEEDANCE_20_PROFILE, resolutions: ["480p", "720p"] } : SEEDANCE_20_PROFILE;
  if (/^sd-fast-chaofen$/i.test(id)) return { ...SEEDANCE_20_PROFILE, resolutions: ["480p", "720p"], verification: "partial" };
  if (/^wan3(?:\.|-)/i.test(id)) return WAN3_PROFILE;
  return {};
}

function unique(values, filter = () => true) {
  return [...new Set((Array.isArray(values) ? values : []).map((value) => typeof value === "number" ? value : clean(value)).filter((value) => value !== "" && filter(value)))];
}

function videoCapabilitiesForModel(model, learned = {}) {
  const saved = Array.isArray(learned) ? { resolutions: learned } : (learned && typeof learned === "object" ? learned : {});
  const id = clean(model).toLowerCase();
  const profile = modelProfile(id);
  let resolutions = unique(saved.resolutions, (value) => /^(?:\d+p|\d+k)$/i.test(value));
  if (!resolutions.length) resolutions = profile.resolutions;
  if (!resolutions && /sd-fast-480p/i.test(id)) resolutions = ["480p"];
  if (!resolutions && /sd-fast-720p/i.test(id)) resolutions = ["720p"];
  const ratios = unique(saved.ratios, (value) => /^(?:\d+:\d+|adaptive)$/i.test(value));
  const durations = unique(saved.durations, (value) => Number.isInteger(Number(value)) && Number(value) > 0).map(Number).sort((a, b) => a - b);
  const minDuration = Number(saved.minDuration ?? (durations.length ? durations[0] : profile.minDuration));
  const maxDuration = Number(saved.maxDuration ?? (durations.length ? durations[durations.length - 1] : profile.maxDuration));
  return {
    resolutions: resolutions || ["480p", "720p", "768p", "1080p", "2k"],
    ratios: ratios.length ? ratios : (profile.ratios || ["16:9", "9:16", "1:1"]),
    durations,
    minDuration: Number.isFinite(minDuration) ? minDuration : 4,
    maxDuration: Number.isFinite(maxDuration) ? maxDuration : 15,
    maxPrompt: profile.maxPrompt || null,
    maxImages: Number.isInteger(profile.maxImages) ? profile.maxImages : 9,
    maxVideos: Number.isInteger(profile.maxVideos) ? profile.maxVideos : 3,
    maxAudios: Number.isInteger(profile.maxAudios) ? profile.maxAudios : 3,
    verification: Object.keys(saved).length ? "learned" : (profile.verification || "unknown"),
  };
}

function readVideoCapabilityFeedback(response = {}) {
  const body = response?.json && typeof response.json === "object" ? response.json : response;
  const data = body?.data && typeof body.data === "object" ? body.data : {};
  const message = [body?.code, body?.message, body?.error?.code, body?.error?.message, data?.code, data?.message].map(clean).join(" ").toLowerCase();
  const generic = data.allowed_values || data.allowedValues || body.allowed_values || body.allowedValues || [];
  const directResolutions = data.allowed_resolutions || data.supported_resolutions || body.allowed_resolutions || [];
  const directRatios = data.allowed_ratios || data.supported_ratios || data.allowed_aspect_ratios || body.allowed_ratios || [];
  const directDurations = data.allowed_durations || data.supported_durations || body.allowed_durations || [];
  const values = Array.isArray(generic) ? generic : [];
  const result = {};
  const inferredResolution = values.length && values.every((value) => /^(?:\d+p|\d+k)$/i.test(clean(value)));
  const inferredRatio = values.length && values.every((value) => /^(?:\d+:\d+|adaptive)$/i.test(clean(value)));
  const inferredDuration = values.length && values.every((value) => Number.isInteger(Number(value)) && Number(value) > 0);
  const resolutions = unique([...(Array.isArray(directResolutions) ? directResolutions : []), ...(/resolution|清晰度|分辨率/.test(message) || inferredResolution ? values : [])], (value) => /^(?:\d+p|\d+k)$/i.test(value));
  const ratios = unique([...(Array.isArray(directRatios) ? directRatios : []), ...(/ratio|aspect|比例/.test(message) || inferredRatio ? values : [])], (value) => /^(?:\d+:\d+|adaptive)$/i.test(value));
  const durations = unique([...(Array.isArray(directDurations) ? directDurations : []), ...(/duration|seconds?|时长|秒/.test(message) || inferredDuration ? values : [])], (value) => Number.isInteger(Number(value)) && Number(value) > 0).map(Number).sort((a, b) => a - b);
  if (resolutions.length) result.resolutions = resolutions;
  if (ratios.length) result.ratios = ratios;
  if (durations.length) result.durations = durations;
  return result;
}

function mergeVideoCapabilityFeedback(current = {}, feedback = {}) {
  const merged = Object.assign({}, current || {});
  for (const key of ["resolutions", "ratios", "durations"]) if (Array.isArray(feedback[key]) && feedback[key].length) merged[key] = feedback[key];
  if (merged.durations?.length) {
    merged.minDuration = Math.min(...merged.durations);
    merged.maxDuration = Math.max(...merged.durations);
  }
  return merged;
}

function applyVideoCapabilityFeedback(payload, feedback = {}) {
  const next = Object.assign({}, payload);
  if (feedback.resolutions?.length && !feedback.resolutions.includes(next.resolution)) next.resolution = feedback.resolutions[0];
  if (feedback.ratios?.length && !feedback.ratios.includes(next.ratio)) next.ratio = feedback.ratios[0];
  if (feedback.durations?.length && !feedback.durations.includes(Number(next.duration))) next.duration = feedback.durations[0];
  return next;
}

function videoDurationHint(capabilities = {}) {
  const maxDuration = Math.max(0, Number(capabilities.maxDuration) || 0);
  const source = capabilities.verification === "verified" ? "平台文档已确认" : capabilities.verification === "learned" ? "已按平台反馈校准" : capabilities.verification === "partial" ? "部分参数已确认，其余会按平台反馈校准" : "平台参数待校准";
  if (maxDuration >= 30) return `当前模型最长 ${maxDuration} 秒。${source}。`;
  return `当前模型最多 ${maxDuration || 15} 秒；需要更长视频时，请切换到支持 30 秒的 Seedance 2.5 或 Wan 3.0 模型。${source}。`;
}

function videoPriceForSelection(model, resolution, duration, hasReferenceVideo = false) {
  const profile = MODEL_PROFILES[clean(model).toLowerCase()];
  if (!profile?.prices) return null;
  if (Number.isFinite(profile.prices.output)) return { amount: profile.prices.output, unit: "output", total: profile.prices.output };
  const prices = hasReferenceVideo && profile.referenceVideoPrices ? profile.referenceVideoPrices : profile.prices;
  const amount = Number(prices[clean(resolution).toLowerCase()]);
  if (!Number.isFinite(amount)) return null;
  const seconds = Number(duration);
  return { amount, unit: "second", total: Number((amount * (Number.isFinite(seconds) ? seconds : 0)).toFixed(4)) };
}

function shouldTryNextVideoKey(response = {}) {
  const status = Number(response.status);
  const message = clean(response?.json?.error?.message || response?.json?.message || response?.json?.error || response?.json?.code);
  return status === 401 || status === 403 || /auth|token|api.?key|no available channel|group.*not|permission|forbidden/i.test(message);
}

function selectVideoGroups(groups) {
  return Object.keys(groups || {}).map(clean).filter((group) => /video|seedance|视频/i.test(group));
}

function createVideoKeyPayload(group) {
  group = clean(group);
  if (!group) throw new Error("视频分组名称无效");
  return { name: `山竹智能体-${group}`, group, unlimited_quota: true };
}

function createBalanceRequest(apiKey) {
  apiKey = clean(apiKey);
  if (!apiKey) throw new Error("请先在山竹账号中心登录");
  return { path: "/api/user/self_v2", headers: { Authorization: `Bearer ${apiKey}` } };
}

function readQuota(response) {
  const quota = Number(response?.data?.quota);
  return Number.isFinite(quota) && quota >= 0 ? Number((quota / QUOTA_PER_USD).toFixed(4)) : null;
}

function calculateCost(before, after) {
  before = Number(before);
  after = Number(after);
  return Number.isFinite(before) && Number.isFinite(after) && after <= before
    ? Number(((before - after) / QUOTA_PER_USD).toFixed(4))
    : null;
}

function safeVideoFilename(value) {
  const sanitized = clean(value).replace(/[<>:"/\\|?*\x00-\x1f]/g, "").replace(/[. ]+$/g, "");
  const extension = sanitized.toLowerCase().endsWith(".mp4") ? sanitized.slice(-4) : "";
  let name = `${extension ? sanitized.slice(0, -4) : sanitized}`.slice(0, 120 - extension.length) + extension;
  if (WINDOWS_RESERVED_NAME.test(name)) name = `视频-${name}`;
  return name || `山竹视频-${Date.now()}.mp4`;
}

function safeVideoTaskSegment(value) {
  const segment = clean(value).replace(/[<>:"/\\|?*\x00-\x1f]/g, "-").replace(/\.{2,}/g, "-").replace(/[. ]+$/g, "").slice(0, 80);
  return segment && !WINDOWS_RESERVED_NAME.test(segment) ? segment : `任务-${Date.now()}`;
}

function withTimeout(promise, timeoutMs = 45000, label = "视频服务请求") {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label}超时，请检查网络后重试。`)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function assertVideoDownloadSize(response, maxBytes = DEFAULT_VIDEO_DOWNLOAD_LIMIT) {
  const length = Number(response?.headers?.["content-length"] ?? response?.headers?.["Content-Length"] ?? response?.arrayBuffer?.byteLength);
  if (Number.isFinite(length) && length > maxBytes) throw new Error("生成视频文件过大，已停止下载以保护电脑空间。");
}

function isRetryableVideoError(error) {
  const message = clean(error?.message || error);
  if (/\b(?:400|401|403|404)\b|unauthori|forbidden|authentication|invalid|content|moderation|审核|敏感/i.test(message)) return false;
  return /\b(?:408|429|50[0-4])\b|timeout|network|failed to fetch|enotfound|econn|socket|temporar|overload/i.test(message);
}

function isTerminalVideoTaskQueryError(error) {
  const message = clean(error?.message || error);
  return Number(error?.status) === 404
    || /task[_\s-]*(?:not[_\s-]*)?(?:exist|found)|任务[^，。]*不存在/i.test(message);
}

function redactLogText(value) {
  return clean(value)
    .replace(/Bearer\s+\S+/gi, "Bearer [已隐藏]")
    .replace(/sk-[A-Za-z0-9_-]+/g, "[已隐藏]")
    .replace(/(https?:\/\/[^\s?]+)\?\S+/gi, "$1");
}

function toChineseVideoError(error) {
  const message = redactLogText(error?.message || error || "未知错误");
  if (/first_image/i.test(message)) return "当前模型或线路暂不支持首帧图片，请取消首帧后重试。";
  if (/last_image/i.test(message)) return "当前模型或线路暂不支持尾帧图片，请取消尾帧后重试。";
  if (/insufficient|quota|balance|credit|余额/i.test(message)) return "账户余额不足，请充值后重试。";
  if (/401|unauthori|authentication|api.?key|token|登录会话/i.test(message)) return `视频模型线路鉴权失败，请打开“山竹账号中心”刷新视频分组后重试。平台原始提示：${message}`;
  if (/no available channel|group.*not|model.*not/i.test(message)) return "当前视频模型暂时没有可用线路，请在“山竹账号中心”检查视频分组权限后重试。";
  if (/rate.?limit|429|too many/i.test(message)) return "平台当前请求较多，请稍等一分钟后重试。";
  if (/content|moderation|safety|审核|敏感/i.test(message)) return "视频描述或参考材料未通过平台审核，请调整内容后重试。";
  if (/timeout|failed to fetch|network|enotfound|econn|socket/i.test(message)) return "网络连接中断，任务已经保留，稍后会自动重新查询。";
  if (/resolution|duration|ratio|parameter|invalid/i.test(message)) return `视频参数不被当前模型支持：${message}`;
  return `视频生成失败：${message}`;
}

function videoProgressText(status, previous = "", random = Math.random) {
  if (status === "queued") return "任务已排队，正在等画面开拍～";
  if (status === "saving") return "成片出炉啦，正在保存到知识库～";
  if (status === "completed") return "视频已经生成并保存好啦～";
  if (status === "stopped") return "已终止自动查询，不会继续向服务器发送请求。";
  let index = Math.floor(Math.max(0, Math.min(0.999999, Number(random()) || 0)) * VIDEO_PROGRESS_ACTIONS.length * VIDEO_PROGRESS_COMPANIONS.length);
  let message = `${VIDEO_PROGRESS_ACTIONS[Math.floor(index / VIDEO_PROGRESS_COMPANIONS.length)]}，${VIDEO_PROGRESS_COMPANIONS[index % VIDEO_PROGRESS_COMPANIONS.length]}`;
  if (message === previous) {
    index = (index + 1) % (VIDEO_PROGRESS_ACTIONS.length * VIDEO_PROGRESS_COMPANIONS.length);
    message = `${VIDEO_PROGRESS_ACTIONS[Math.floor(index / VIDEO_PROGRESS_COMPANIONS.length)]}，${VIDEO_PROGRESS_COMPANIONS[index % VIDEO_PROGRESS_COMPANIONS.length]}`;
  }
  return message;
}

module.exports = {
  VIDEO_PROGRESS_INTERVAL_MS,
  applyVideoCapabilityFeedback,
  assertVideoDownloadSize,
  assertLocalImageUploadSize,
  assertLocalVideoUpload,
  calculateCost,
  createBalanceRequest,
  createVideoKeyPayload,
  createVideoPayload,
  extractVideoTaskId,
  isRetryableVideoError,
  isTerminalVideoTaskQueryError,
  localImageMimeType,
  localVideoMimeType,
  readQuota,
  readAllowedResolutions,
  readVideoCapabilityFeedback,
  readVideoTask,
  redactLogText,
  resolutionOptionsForModel,
  mergeVideoCapabilityFeedback,
  safeVideoFilename,
  safeVideoTaskSegment,
  selectVideoGroups,
  shouldTryNextVideoKey,
  toChineseVideoError,
  videoCapabilitiesForModel,
  videoDurationHint,
  videoPriceForSelection,
  videoProgressText,
  withTimeout,
};
