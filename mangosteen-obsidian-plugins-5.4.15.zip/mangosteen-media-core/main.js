"use strict";

const path = require("path");
const { Plugin, requestUrl } = require("obsidian");

module.exports = class MangosteenMediaCorePlugin extends Plugin {
  async onload() {
    const basePath = this.app.vault?.adapter?.getBasePath?.()
      || this.app.vault?.adapter?.basePath
      || process.cwd();
    const root = path.join(basePath, ...String(this.manifest.dir || `.obsidian/plugins/${this.manifest.id}`).split(/[\\/]/).filter(Boolean));
    const { createMediaCore } = require(path.join(root, "media-core.cjs"));
    this.mediaCore = createMediaCore({
      app: this.app,
      obsidian: require("obsidian"),
      requestUrl,
      root,
    });
    await this.mediaCore.initialize(this);
  }

  getAccountBridge() {
    return this.mediaCore?.getBridge?.() || null;
  }

  onunload() {
    this.mediaCore?.dispose?.();
    this.mediaCore = null;
  }
};
