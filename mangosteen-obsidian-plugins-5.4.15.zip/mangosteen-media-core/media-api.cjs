"use strict";

const API_BASE = "https://apishanzhu.aihubkit.com";

function cleanCookie(value) {
  for (const source of (Array.isArray(value) ? value : [value])) {
    const match = String(source || "").match(/(?:^|,\s*)session=([^;,\s]+)/i);
    if (match) return "session=" + match[1];
  }
  return "";
}

function headerValue(headers, name) {
  if (typeof headers?.get === "function") return headers.get(name) || "";
  const entry = Object.entries(headers || {}).find(([key]) => key.toLowerCase() === String(name).toLowerCase());
  return entry?.[1] || "";
}

function failure(code) {
  return { ok: false, code };
}

function failureFor(response) {
  const status = Number(response?.status || 0);
  const message = String(response?.json?.message || response?.json?.error?.message || "");
  if (status === 401 || status === 403) return failure("AUTH_REQUIRED");
  if (/quota|balance|credit|余额|额度/i.test(message)) return failure("INSUFFICIENT_QUOTA");
  return failure(status >= 400 ? "REMOTE_REJECTED" : "INVALID_RESPONSE");
}

function normalizeGroups(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(Object.entries(value).map(([group, detail]) => {
    const ratio = Number(detail?.ratio);
    return [String(group), { label: String(detail?.desc || group), ratio: Number.isFinite(ratio) ? ratio : 1 }];
  }));
}

function normalizeModels(value) {
  const seen = new Set();
  return (Array.isArray(value) ? value : [])
    .map((item) => String(item?.id || "").trim())
    .filter((id) => id && !seen.has(id) && seen.add(id));
}

function safeLogDetail(value) {
  return String(value || "")
    .replace(/(bearer\s+|authorization\s*[:=]\s*|api[_ -]?key\s*[:=]\s*|password\s*[:=]\s*|cookie\s*[:=]\s*)[^\s,;]+/gi, "$1[已隐藏]")
    .replace(/\bsk-[A-Za-z0-9_-]{8,}\b/gi, "[已隐藏]")
    .replace(/\b[A-Za-z0-9_-]{24,}\b/g, "[已隐藏]")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 400);
}

function safeTaskId(value) {
  const id = String(value || "").trim();
  return /^task_[A-Za-z0-9_-]{4,160}$/.test(id) ? id : "";
}

function safeErrorDetail(value) {
  let detail = {};
  try { detail = typeof value === "string" ? JSON.parse(value || "{}") : (value || {}); } catch (_) { detail = {}; }
  if (!detail || typeof detail !== "object") detail = {};
  return {
    errorCode: safeLogDetail(detail.error_code),
    errorType: safeLogDetail(detail.error_type),
    statusCode: Math.max(0, Number(detail.status_code) || 0),
    requestPath: safeLogDetail(detail.request_path),
  };
}

function safeUsageMetadata(value) {
  let detail = {};
  try { detail = typeof value === "string" ? JSON.parse(value || "{}") : (value || {}); } catch (_) { detail = {}; }
  if (!detail || typeof detail !== "object") detail = {};
  return {
    mediaTaskId: safeTaskId(detail.task_id || detail.billing_event_id),
    billingEventId: safeTaskId(detail.billing_event_id),
    estimatedQuota: Math.max(0, Number(detail.estimated_quota) || 0),
    requestPath: safeLogDetail(detail.request_path),
  };
}

function normalizeUsageLogs(value) {
  const data = value && typeof value === "object" ? value : {};
  const items = Array.isArray(data.items) ? data.items : [];
  return {
    page: Math.max(1, Number(data.page) || 1),
    pageSize: Math.max(1, Number(data.page_size) || 10),
    total: Math.max(0, Number(data.total) || 0),
    items: items.map((item) => {
      const type = Number(item?.type) || 0;
      const metadata = safeUsageMetadata(item?.other);
      const requestId = String(item?.request_id || "");
      const mediaTaskId = metadata.mediaTaskId || (/^task_[A-Za-z0-9_-]+$/.test(requestId) ? requestId : "");
      const detail = type === 1 || type === 5 || mediaTaskId || /^\/v1\/(?:images|videos)\//.test(metadata.requestPath)
        ? safeLogDetail(item?.content)
        : "";
      return {
        id: item?.id,
        createdAt: Number(item?.created_at) || 0,
        model: String(item?.model_name || ""),
        group: String(item?.group || ""),
        quota: Number(item?.quota) || 0,
        promptTokens: Number(item?.prompt_tokens) || 0,
        completionTokens: Number(item?.completion_tokens) || 0,
        durationSeconds: Number(item?.use_time) || 0,
        requestId,
        type,
        tokenName: String(item?.token_name || ""),
        isStream: Boolean(item?.is_stream),
        ...(mediaTaskId ? { mediaTaskId } : {}),
        ...(metadata.billingEventId ? { billingEventId: metadata.billingEventId } : {}),
        ...(metadata.estimatedQuota ? { estimatedQuota: metadata.estimatedQuota } : {}),
        ...(metadata.requestPath ? { requestPath: metadata.requestPath } : {}),
        ...(detail ? { detail } : {}),
        ...(type === 5 ? { errorDetail: safeErrorDetail(item?.other) } : {}),
      };
    }),
  };
}

function createAihubkitApi(request, options = {}) {
  const fetchImpl = options.fetchImpl;

  async function call(options) {
    try {
      const response = await request(options);
      if (Number(response?.status || 0) >= 400 || response?.json?.success === false) return failureFor(response);
      return { ok: true, response };
    } catch (_) {
      return failure("NETWORK_UNAVAILABLE");
    }
  }

  return {
    async requestVerification(email) {
      const result = await call({
        url: API_BASE + "/api/verification?email=" + encodeURIComponent(String(email || "").trim()),
        method: "GET",
        headers: {},
      });
      return result.ok ? { ok: true } : result;
    },
    async register(details) {
      const result = await call({
        url: API_BASE + "/api/user/register",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: String(details?.username || "").trim(),
          password: String(details?.password || ""),
          email: String(details?.email || "").trim(),
          verification_code: String(details?.verificationCode || "").trim(),
          aff_code: "DlQa",
        }),
      });
      return result.ok ? { ok: true } : result;
    },
    async login(username, password) {
      const requestData = {
        url: API_BASE + "/api/user/login",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: String(username || "").trim(), password: String(password || "") }),
      };
      const result = await call(requestData);
      if (!result.ok) return result;
      const user = result.response.json?.data;
      const sessionCookie = cleanCookie(headerValue(result.response.headers, "set-cookie"));
      if (!user?.id || !sessionCookie) return failure("INVALID_RESPONSE");
      return {
        ok: true,
        account: { userId: String(user.id), label: String(user.username || user.display_name || "用户"), sessionCookie },
        request: { json: { username: String(username || "").trim() } },
      };
    },
    async getAccessToken(account) {
      const result = await call({
        url: API_BASE + "/api/user/token", method: "GET",
        headers: { Cookie: cleanCookie(account?.sessionCookie), "New-Api-User": String(account?.userId || "") },
      });
      const token = result.response?.json?.data;
      return result.ok && token ? { ok: true, accessToken: String(token) } : (result.ok ? failure("INVALID_RESPONSE") : result);
    },
    async getBalance(apiKey) {
      const result = await call({
        url: API_BASE + "/api/user/self_v2", method: "GET",
        headers: { Authorization: "Bearer " + String(apiKey || "") },
      });
      const quota = Number(result.response?.json?.data?.quota);
      return result.ok && Number.isFinite(quota)
        ? { ok: true, quotaUsd: quota / 500000, rawQuota: quota }
        : (result.ok ? failure("INVALID_RESPONSE") : result);
    },
    async redeemTopup(account, code) {
      code = String(code || "").trim();
      if (!code) return failure("INVALID_INPUT");
      const access = await this.getAccessToken(account);
      if (!access.ok) return access;
      const result = await call({
        url: API_BASE + "/api/user/topup", method: "POST",
        headers: { Authorization: "Bearer " + access.accessToken, "New-Api-User": String(account?.userId || ""), "Content-Type": "application/json" },
        body: JSON.stringify({ key: code }),
      });
      const creditedQuota = Number(result.response?.json?.data);
      return result.ok && Number.isFinite(creditedQuota)
        ? { ok: true, creditedQuota }
        : (result.ok ? failure("INVALID_RESPONSE") : result);
    },
    async getGroups(apiKey, userId) {
      const result = await call({
        url: API_BASE + "/api/user/self/groups", method: "GET",
        headers: { Authorization: "Bearer " + String(apiKey || ""), "New-Api-User": String(userId || "") },
      });
      return result.ok ? { ok: true, groups: normalizeGroups(result.response.json?.data) } : result;
    },
    async createGroupKey(account, group) {
      const access = await this.getAccessToken(account);
      if (!access.ok) return access;
      const result = await call({
        url: API_BASE + "/api/token/", method: "POST",
        headers: { Authorization: "Bearer " + access.accessToken, "New-Api-User": String(account?.userId || ""), "Content-Type": "application/json" },
        body: JSON.stringify({ name: "山竹智能体-" + String(group), group: String(group), unlimited_quota: true }),
      });
      const key = result.response?.json?.data?.key;
      return result.ok && key ? { ok: true, key: String(key) } : (result.ok ? failure("INVALID_RESPONSE") : result);
    },
    async getModels(apiKey) {
      const result = await call({
        url: API_BASE + "/v1/models", method: "GET",
        headers: { Authorization: "Bearer " + String(apiKey || "") },
      });
      if (!result.ok) return result;
      const models = normalizeModels(result.response.json?.data);
      return models.length ? { ok: true, models } : failure("MODELS_UNAVAILABLE");
    },
    async uploadTemporaryFile(account, file) {
      const name = String(file?.name || "").split(/[\\/]/).pop();
      const type = String(file?.type || "").toLowerCase();
      const bytes = file?.bytes instanceof ArrayBuffer ? new Uint8Array(file.bytes)
        : ArrayBuffer.isView(file?.bytes) ? new Uint8Array(file.bytes.buffer, file.bytes.byteOffset, file.bytes.byteLength) : null;
      if (!name || !/^[a-z0-9.+-]+\/[a-z0-9.+-]+$/i.test(type) || !bytes?.byteLength) return failure("INVALID_INPUT");
      const access = await this.getAccessToken(account);
      if (!access.ok) return access;
      const created = await call({
        url: API_BASE + "/v1/temporary-files", method: "POST",
        headers: { Authorization: "Bearer " + access.accessToken, "Content-Type": "application/json" },
        body: JSON.stringify({ filename: name, content_type: type, size: bytes.byteLength }),
        throw: false,
      });
      if (!created.ok) return created;
      const data = created.response.json?.data || {};
      const headers = data.headers;
      let uploadUrl;
      let fileUrl;
      try { uploadUrl = new URL(data.upload_url); fileUrl = new URL(data.url); } catch (_) { return failure("INVALID_RESPONSE"); }
      if (uploadUrl.protocol !== "https:" || fileUrl.protocol !== "https:" || uploadUrl.username || fileUrl.username
        || !headers || typeof headers !== "object" || Array.isArray(headers) || String(headerValue(headers, "Content-Type")).toLowerCase() !== type) {
        return failure("INVALID_RESPONSE");
      }
      try {
        const uploaded = await request({ url: uploadUrl.href, method: "PUT", headers, body: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), throw: false });
        if (Number(uploaded?.status) < 200 || Number(uploaded?.status) >= 300) return failure("REMOTE_REJECTED");
      } catch (_) { return failure("NETWORK_UNAVAILABLE"); }
      return { ok: true, url: fileUrl.href, expiresIn: Math.max(0, Number(data.expires_in) || 0) };
    },
    async uploadTemporaryImage(account, image) {
      const name = String(image?.name || "").split(/[\\/]/).pop();
      const type = String(image?.type || (/\.webp$/i.test(name) ? "image/webp" : /\.jpe?g$/i.test(name) ? "image/jpeg" : /\.png$/i.test(name) ? "image/png" : "")).toLowerCase();
      if (!/^image\/(?:png|jpeg|webp)$/.test(type)) return failure("INVALID_INPUT");
      return this.uploadTemporaryFile(account, { ...image, name, type });
    },
    async uploadTemporaryVideo(account, video) {
      const name = String(video?.name || "").split(/[\\/]/).pop();
      const declared = String(video?.type || "").toLowerCase();
      const type = ["video/mp4", "video/quicktime"].includes(declared)
        ? declared : (/\.mp4$/i.test(name) ? "video/mp4" : /\.mov$/i.test(name) ? "video/quicktime" : "");
      const size = Number(video?.bytes?.byteLength || 0);
      if (!type || !size) return failure("INVALID_INPUT");
      return this.uploadTemporaryFile(account, { ...video, name, type });
    },
    async getUsageLogs(account, options = {}) {
      const page = Math.max(1, Math.floor(Number(options.page) || 1));
      const pageSize = Math.min(50, Math.max(1, Math.floor(Number(options.pageSize) || 10)));
      if (!account?.userId) return failure("AUTH_REQUIRED");
      const access = await this.getAccessToken(account);
      if (!access.ok) return access;
      const endTimestamp = Math.max(1, Math.floor(Number(options.endTimestamp) || Date.now() / 1000));
      const startTimestamp = Math.min(endTimestamp, Math.max(0, Math.floor(Number(options.startTimestamp) || endTimestamp - 30 * 86400)));
      const result = await call({
        url: API_BASE + "/api/log/self?p=" + page + "&page_size=" + pageSize
          + "&start_timestamp=" + startTimestamp + "&end_timestamp=" + endTimestamp,
        method: "GET",
        headers: { Authorization: "Bearer " + access.accessToken, "New-Api-User": String(account.userId) },
      });
      if (!result.ok) return result;
      const logs = normalizeUsageLogs(result.response.json?.data);
      return { ok: true, ...logs };
    },
    readGroups: (response) => normalizeGroups(response?.data),
    readModels: (response) => normalizeModels(response?.data),
  };
}

module.exports = { API_BASE, createAihubkitApi, failureFor, normalizeGroups, normalizeModels };
