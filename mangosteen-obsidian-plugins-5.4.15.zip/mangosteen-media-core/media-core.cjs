"use strict";

const fs = require("fs");
const path = require("path");
const { createAihubkitApi } = require("./media-api.cjs");

const STATE_FOLDER = ".mangosteen-media";
const STATE_FILE = "account.json";
const LEGACY_STATE = path.join(".mangosteen-agent", "aihubkit-language.json");
const QUOTA_PER_USD = 500000;
const LOG_MAX_BYTES = 2 * 1024 * 1024;
const LANGUAGE_CONFIGURATION_SCHEMA = "apishanzhu-v1";

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch (_) { return {}; }
}

function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), "utf8");
}

function redact(value) {
  return String(value || "")
    .replace(/(bearer\s+|authorization\s*[:=]\s*|api[_ -]?key\s*[:=]\s*|password\s*[:=]\s*|cookie\s*[:=]\s*)[^\s,;]+/gi, "$1[已隐藏]")
    .replace(/\bsk-[A-Za-z0-9_-]{8,}\b/gi, "[已隐藏]")
    .replace(/\s+/g, " ").trim().slice(0, 800);
}

function accountErrorMessage(code) {
  if (code === "AUTH_REQUIRED") return "账号或密码不正确，或登录状态已失效，请重新登录。";
  if (code === "NETWORK_UNAVAILABLE") return "当前网络无法连接山竹账号服务，请检查网络后重试。";
  if (code === "INSUFFICIENT_QUOTA") return "账号额度不足，请充值后重试。";
  if (code === "INVALID_INPUT") return "请把必填信息填写完整后再继续。";
  if (code === "MODELS_UNAVAILABLE") return "暂时没有读取到媒体模型，请点击刷新模型目录。";
  return "账号服务暂时没有完成请求，请稍后重试。";
}

function groupKind(group) {
  const name = String(group || "");
  if (/video|seedance|视频/i.test(name)) return "video";
  if (/image|seedream|绘图|生图|图片|图像/i.test(name)) return "image";
  return "language";
}

function createMediaCore(options = {}) {
  let app = options.app || {};
  const obsidian = options.obsidian || {};
  const api = options.api || createAihubkitApi(options.requestUrl || obsidian.requestUrl);
  let plugin = null;
  let statePath = "";
  let logPath = "";
  let state = {
    account: {}, groupKeys: {}, groupRatios: {}, modelsByGroup: {}, lastBalance: null,
    languageGroup: "", languageModel: "", languageRevision: 0,
  };
  let catalogReady = false;
  let catalogRevision = 0;
  let refreshPromise = null;
  let recentUsageLogs = { page: 1, pageSize: 10, total: 0, items: [] };
  let usageLogsStatus = "idle";
  let usageLogsError = "";
  let usageLogsPromise = null;
  const catalogListeners = new Set();
  const languageListeners = new Set();

  function vaultBase() {
    return app?.vault?.adapter?.getBasePath?.() || app?.vault?.adapter?.basePath || process.cwd();
  }

  function refreshPaths() {
    statePath = path.join(vaultBase(), STATE_FOLDER, STATE_FILE);
    logPath = path.join(vaultBase(), STATE_FOLDER, "logs", "operations.log");
  }

  function saveState() { writeJson(statePath, state); }

  function writeOperation(step, detail) {
    fs.mkdirSync(path.dirname(logPath), { recursive: true });
    if (fs.existsSync(logPath) && fs.statSync(logPath).size > LOG_MAX_BYTES) {
      fs.rmSync(logPath + ".1", { force: true });
      fs.renameSync(logPath, logPath + ".1");
    }
    fs.appendFileSync(logPath, `[${new Date().toISOString()}] ${redact(step)}：${redact(detail)}\n`, "utf8");
  }

  function migrateLegacyState() {
    if (fs.existsSync(statePath)) return false;
    const legacy = readJson(path.join(vaultBase(), LEGACY_STATE));
    if (!legacy?.account?.userId) return false;
    state = {
      account: { ...legacy.account },
      groupKeys: { ...(legacy.groupKeys || {}) },
      groupRatios: { ...(legacy.groupRatios || {}) },
      modelsByGroup: { ...(legacy.modelsByGroup || {}) },
      lastBalance: legacy.lastBalance || null,
    };
    saveState();
    writeOperation("账号迁移", "已迁移媒体账号，不迁移旧语言模型配置");
    return true;
  }

  function announceCatalog() {
    for (const listener of catalogListeners) {
      try { listener(catalogReady); } catch (_) {}
    }
  }

  function languageSnapshot() {
    const accountUserId = String(state.account?.userId || "");
    const group = String(state.languageGroup || "");
    const model = String(state.languageModel || "");
    const groupKey = String(state.groupKeys?.[group] || "");
    const models = group ? [...(state.modelsByGroup?.[group] || [])] : [];
    const configured = Boolean(accountUserId && group && model && groupKey);
    return {
      sourceId: `${LANGUAGE_CONFIGURATION_SCHEMA}:${accountUserId}:${Math.max(0, Number(state.languageRevision) || 0)}`,
      accountUserId,
      group: configured ? group : null,
      model: configured ? model : null,
      models: configured ? models : [],
      providerId: configured ? (/claude/i.test(`${group} ${model}`) ? "claude" : "codex") : null,
      groupKey: configured ? groupKey : null,
    };
  }

  function announceLanguage() {
    const snapshot = languageSnapshot();
    for (const listener of languageListeners) {
      try { listener(snapshot); } catch (_) {}
    }
  }

  function bumpLanguageRevision() {
    state.languageRevision = Math.max(0, Number(state.languageRevision) || 0) + 1;
    saveState();
    announceLanguage();
  }

  function mediaLogKey(item) {
    return String(item?.id ?? "") || [item?.requestId, item?.createdAt, item?.type, item?.quota].join("|");
  }

  function uniqueLogs(items) {
    const seen = new Set();
    return (items || []).filter((item) => {
      const key = mediaLogKey(item);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function usageMatch(task, items, matchedBy, accountUserId) {
    const logs = uniqueLogs(items);
    if (!logs.length) return null;
    const detailLog = logs.find((item) => Number(item.type) === (task.status === "failed" ? 5 : 2)) || logs[0];
    const quota = Math.max(...logs.map((item) => Math.max(0, Number(item.quota) || Number(item.estimatedQuota) || 0)));
    const error = task.status === "failed" ? detailLog.errorDetail || {} : {};
    return {
      costUsd: quota / QUOTA_PER_USD,
      detail: [
        detailLog.detail ? `平台日志：${detailLog.detail}` : "",
        error.errorCode ? `错误码 ${error.errorCode}` : "",
        error.errorType ? `错误类型 ${error.errorType}` : "",
        error.statusCode ? `状态码 ${error.statusCode}` : "",
      ].filter(Boolean).join(" · "),
      requestId: String(detailLog.requestId || ""),
      tokenName: String(detailLog.tokenName || ""),
      group: String(detailLog.group || task.group || ""),
      model: String(detailLog.model || task.model || ""),
      durationSeconds: Math.max(0, Number(detailLog.durationSeconds) || 0),
      statusCode: Math.max(0, Number(error.statusCode) || 0),
      accountUserId,
      matchedBy,
      logId: mediaLogKey(detailLog),
    };
  }

  async function matchMediaUsage(tasks) {
    if (!state.account?.userId) return { ok: false, code: "AUTH_REQUIRED" };
    const accountUserId = String(state.account.userId);
    const pending = (tasks || []).filter((task) => task?.id && (!task.accountUserId || String(task.accountUserId) === accountUserId));
    if (!pending.length) return { ok: true, matches: {} };
    const oldest = Math.min(...pending.map((task) => Date.parse(task.createdAt || "") / 1000).filter(Number.isFinite));
    const logs = [];
    for (let page = 1; page <= 20; page += 1) {
      const result = await api.getUsageLogs(state.account, { page, pageSize: 50 });
      if (!result.ok) return result;
      logs.push(...(result.items || []));
      if (page * result.pageSize >= result.total) break;
      const times = (result.items || []).map((item) => Number(item.createdAt) || 0).filter(Boolean);
      if (Number.isFinite(oldest) && times.length && Math.min(...times) < oldest - 180) break;
    }
    const normalized = uniqueLogs(logs);
    const used = new Set();
    const matches = {};
    for (const task of pending) {
      const id = String(task.id);
      const exact = normalized.filter((item) => id === String(item.requestId || "") || id === String(item.mediaTaskId || "") || id === String(item.billingEventId || ""));
      const match = usageMatch(task, exact, "exact", accountUserId);
      if (match) { matches[id] = match; exact.forEach((item) => used.add(mediaLogKey(item))); }
    }
    for (const task of pending) {
      const id = String(task.id);
      if (matches[id]) continue;
      const createdAt = Date.parse(task.createdAt || "") / 1000;
      const pattern = task.kind === "video" ? /\/videos(?:\/|$)/i : /\/images(?:\/|$)/i;
      const candidates = normalized.filter((item) => {
        if (used.has(mediaLogKey(item)) || !pattern.test(String(item.requestPath || item.errorDetail?.requestPath || ""))) return false;
        if (task.model && String(item.model || "").toLowerCase() !== String(task.model).toLowerCase()) return false;
        if (task.group && String(item.group || "").toLowerCase() !== String(task.group).toLowerCase()) return false;
        return Number.isFinite(createdAt) && Math.abs((Number(item.createdAt) || 0) - createdAt) <= 180;
      });
      if (candidates.length === 1) matches[id] = usageMatch(task, candidates, "unique-fallback", accountUserId);
    }
    return { ok: true, matches };
  }

  async function ensureGroupKey(group, groups, revision) {
    if (!Object.prototype.hasOwnProperty.call(groups, group)) return { ok: false, code: "REMOTE_REJECTED" };
    if (state.groupKeys[group]) return { ok: true, key: state.groupKeys[group], reused: true };
    const result = await api.createGroupKey(state.account, group);
    if (!result.ok || revision !== catalogRevision) return result.ok ? { ok: false, code: "CATALOG_SUPERSEDED" } : result;
    state.groupKeys[group] = result.key;
    saveState();
    return { ok: true, key: result.key, reused: false };
  }

  async function modelsFor(group, groups, revision) {
    let keyResult = await ensureGroupKey(group, groups, revision);
    if (!keyResult.ok) return keyResult;
    let result = await api.getModels(keyResult.key);
    if (!result.ok && keyResult.reused && ["AUTH_REQUIRED", "REMOTE_REJECTED"].includes(result.code)) {
      delete state.groupKeys[group];
      keyResult = await ensureGroupKey(group, groups, revision);
      if (!keyResult.ok) return keyResult;
      result = await api.getModels(keyResult.key);
    }
    return result.ok ? { ok: true, key: keyResult.key, models: result.models } : result;
  }

  async function refreshCatalog() {
    if (!state.account?.userId) return { ok: false, code: "AUTH_REQUIRED" };
    if (refreshPromise) return refreshPromise;
    catalogReady = false;
    const revision = ++catalogRevision;
    announceCatalog();
    const pending = (async () => {
      const access = await api.getAccessToken(state.account);
      if (!access.ok || revision !== catalogRevision) return access.ok ? { ok: false, code: "CATALOG_SUPERSEDED" } : access;
      const groups = await api.getGroups(access.accessToken, state.account.userId);
      if (!groups.ok || revision !== catalogRevision) return groups.ok ? { ok: false, code: "CATALOG_SUPERSEDED" } : groups;
      const availableGroups = { ...(groups.groups || {}) };
      const freshRatios = { ...availableGroups };
      const freshModels = {};
      for (const group of Object.keys(availableGroups).filter((name) => groupKind(name) !== "language")) {
        const result = await modelsFor(group, availableGroups, revision);
        if (revision !== catalogRevision) return { ok: false, code: "CATALOG_SUPERSEDED" };
        if (!result.ok) continue;
        freshModels[group] = result.models;
      }
      const selectedLanguageGroup = String(state.languageGroup || "");
      if (groupKind(selectedLanguageGroup) === "language" && availableGroups[selectedLanguageGroup]) {
        freshModels[selectedLanguageGroup] = [...(state.modelsByGroup?.[selectedLanguageGroup] || [])];
      } else if (selectedLanguageGroup) {
        state.languageGroup = "";
        state.languageModel = "";
        state.languageRevision = Math.max(0, Number(state.languageRevision) || 0) + 1;
      }
      if (!Object.keys(freshRatios).length) return { ok: false, code: "MODELS_UNAVAILABLE" };
      state.groupRatios = freshRatios;
      state.modelsByGroup = freshModels;
      catalogReady = true;
      saveState();
      announceCatalog();
      announceLanguage();
      writeOperation("模型目录", "语言、图片和视频分组刷新成功");
      return { ok: true };
    })();
    refreshPromise = pending;
    try { return await pending; } finally { if (refreshPromise === pending) refreshPromise = null; }
  }

  function accessFor(kind) {
    if (!catalogReady) return null;
    const prefix = kind === "image" ? "image" : "video";
    const access = { accountUserId: String(state.account?.userId || ""), groupRatios: {} };
    access[`${prefix}Keys`] = {};
    access[`${prefix}ModelKeys`] = {};
    access[`${prefix}ModelKeyCandidates`] = {};
    for (const [group, models] of Object.entries(state.modelsByGroup || {})) {
      if (groupKind(group) !== kind) continue;
      const key = String(state.groupKeys[group] || "");
      if (!key) continue;
      access[`${prefix}Keys`][group] = key;
      access.groupRatios[group] = state.groupRatios[group];
      for (const model of models || []) {
        const id = String(model || "").trim();
        if (!id) continue;
        access[`${prefix}ModelKeys`][id] ||= key;
        (access[`${prefix}ModelKeyCandidates`][id] ||= []).push({ group, key });
      }
    }
    const keys = Object.values(access[`${prefix}Keys`]);
    if (!keys.length) return null;
    access.balanceKey = keys[0];
    access.defaultGroup = Object.keys(access[`${prefix}Keys`])[0];
    return access;
  }

  async function refreshBalance() {
    const key = Object.values(state.groupKeys || {})[0];
    if (!key) return { ok: false, code: "AUTH_REQUIRED" };
    const result = await api.getBalance(key);
    if (result.ok) {
      state.lastBalance = { quotaUsd: result.quotaUsd, rawQuota: result.rawQuota, checkedAt: new Date().toISOString() };
      saveState();
    }
    return result;
  }

  async function loadRecentUsageLogs(force = false) {
    if (!state.account?.userId) return { ok: false, code: "AUTH_REQUIRED" };
    if (!force && usageLogsStatus === "ready") {
      return { ok: true, ...recentUsageLogs, items: [...recentUsageLogs.items], cached: true };
    }
    if (usageLogsPromise) return usageLogsPromise;
    if (typeof api.getUsageLogs !== "function") return { ok: false, code: "REMOTE_REJECTED" };
    usageLogsStatus = "loading";
    usageLogsError = "";
    const pending = (async () => {
      const result = await api.getUsageLogs(state.account, { page: 1, pageSize: 10 });
      if (!result.ok) {
        usageLogsStatus = "error";
        usageLogsError = String(result.code || "REMOTE_REJECTED");
        return result;
      }
      recentUsageLogs = {
        page: 1,
        pageSize: 10,
        total: Math.max(0, Number(result.total) || 0),
        items: (result.items || []).slice(0, 10),
      };
      usageLogsStatus = "ready";
      usageLogsError = "";
      return { ok: true, ...recentUsageLogs, items: [...recentUsageLogs.items], cached: false };
    })();
    usageLogsPromise = pending;
    try { return await pending; } finally { if (usageLogsPromise === pending) usageLogsPromise = null; }
  }

  async function bind(username, password) {
    const result = await api.login(username, password);
    if (!result.ok) return result;
    const changed = String(state.account?.userId || "") !== String(result.account.userId);
    state.account = result.account;
    if (changed) {
      state.groupKeys = {};
      state.groupRatios = {};
      state.modelsByGroup = {};
      state.languageGroup = "";
      state.languageModel = "";
      state.languageRevision = Math.max(0, Number(state.languageRevision) || 0) + 1;
      catalogReady = false;
      catalogRevision += 1;
      recentUsageLogs = { page: 1, pageSize: 10, total: 0, items: [] };
      usageLogsStatus = "idle";
      usageLogsError = "";
      announceLanguage();
    }
    saveState();
    const catalog = await refreshCatalog();
    const [balance, logs] = await Promise.all([refreshBalance(), loadRecentUsageLogs(true)]);
    writeOperation("账号登录", catalog.ok ? "成功" : `成功，模型目录待刷新：${catalog.code}`);
    return {
      ok: true,
      account: state.account,
      modelsPending: !catalog.ok,
      balancePending: !balance.ok,
      logsPending: !logs.ok,
    };
  }

  function languageGroups() {
    return Object.keys(state.groupRatios || {}).filter((group) => groupKind(group) === "language");
  }

  async function selectLanguageGroup(group) {
    group = String(group || "").trim();
    if (!catalogReady || !languageGroups().includes(group)) return { ok: false, code: "REMOTE_REJECTED" };
    const result = await modelsFor(group, state.groupRatios, catalogRevision);
    if (!result.ok) return result;
    const models = (result.models || []).map(String).filter(Boolean);
    if (!models.length) return { ok: false, code: "MODELS_UNAVAILABLE" };
    state.modelsByGroup[group] = models;
    state.languageGroup = group;
    if (!models.includes(String(state.languageModel || ""))) state.languageModel = models[0];
    bumpLanguageRevision();
    writeOperation("语言模型分组", `已选择 ${group}`);
    return { ok: true, group, models, model: state.languageModel };
  }

  async function selectLanguageModel(model) {
    model = String(model || "").trim();
    const models = state.modelsByGroup?.[state.languageGroup] || [];
    if (!catalogReady || !model || !models.includes(model)) return { ok: false, code: "REMOTE_REJECTED" };
    state.languageModel = model;
    bumpLanguageRevision();
    writeOperation("语言模型", `已选择 ${model}`);
    return { ok: true, model };
  }

  async function reapplyLanguageConfiguration() {
    const snapshot = languageSnapshot();
    if (!snapshot.group || !snapshot.model || !snapshot.groupKey) return { ok: false, code: "MODELS_UNAVAILABLE" };
    bumpLanguageRevision();
    writeOperation("语言模型配置", "已请求重新应用");
    return { ok: true };
  }

  async function registerAccount(details) {
    const input = {
      username: String(details?.username || "").trim(),
      password: String(details?.password || ""),
      email: String(details?.email || "").trim(),
      verificationCode: String(details?.verificationCode || "").trim(),
    };
    if (!input.username || input.password.length < 8 || !/^\S+@\S+\.\S+$/.test(input.email) || !input.verificationCode) return { ok: false, code: "INVALID_INPUT" };
    const registered = await api.register(input);
    return registered.ok ? bind(input.username, input.password) : registered;
  }

  function notice(message) {
    if (typeof obsidian.Notice === "function") new obsidian.Notice(message);
  }

  function openLogin() {
    if (typeof obsidian.Modal !== "function") { notice("请在“设置 → 山竹账号中心”中登录。"); return; }
    new class extends obsidian.Modal {
      onOpen() {
        const root = this.contentEl;
        root.empty();
        root.addClass?.("mangosteen-auth-modal");
        root.classList?.add?.("mangosteen-auth-modal");
        const header = root.createDiv({ cls: "mangosteen-auth-header" });
        header.createEl("span", { text: "山竹服务", cls: "mangosteen-account-eyebrow" });
        header.createEl("h2", { text: "欢迎使用山竹" });
        header.createEl("p", { text: "登录后自动同步语言、图片、视频分组及账户余额。" });
        const tabs = root.createDiv({ cls: "mangosteen-auth-tabs" });
        const loginTab = tabs.createEl("button", { text: "登录账号", attr: { type: "button" }, cls: "is-active" });
        const registerTab = tabs.createEl("button", { text: "注册新账号", attr: { type: "button" } });
        const panel = root.createDiv({ cls: "mangosteen-auth-panel" });
        const createField = (form, label, attributes) => {
          const field = form.createDiv({ cls: "mangosteen-auth-field" });
          field.createEl("label", { text: label, attr: { for: attributes.id } });
          return field.createEl("input", { attr: attributes });
        };
        const render = (mode) => {
          panel.empty();
          loginTab.classList?.toggle("is-active", mode === "login");
          registerTab.classList?.toggle("is-active", mode === "register");
          const form = panel.createEl("form", { cls: "mangosteen-auth-form" });
          const status = form.createEl("p", { text: "", cls: "mangosteen-auth-status", attr: { role: "status" } });
          const setStatus = (message, isError = false) => {
            status.setText(message);
            status.classList?.toggle("is-error", isError);
          };
          if (mode === "login") {
            const username = createField(form, "账号", { id: "mangosteen-login-username", name: "username", type: "text", placeholder: "邮箱或用户名", autocomplete: "username" });
            const password = createField(form, "密码", { id: "mangosteen-login-password", name: "password", type: "password", placeholder: "请输入密码", autocomplete: "current-password" });
            form.createEl("p", { text: "使用您在山竹平台注册的账号登录。", cls: "mangosteen-auth-help" });
            const submit = form.createEl("button", { text: "登录并同步账号数据", cls: "mod-cta mangosteen-auth-submit", attr: { type: "submit" } });
            let busy = false;
            form.addEventListener("submit", async (event) => {
              event?.preventDefault?.();
              if (busy) return;
              if (!String(username.value || "").trim() || !String(password.value || "")) {
                setStatus("请输入账号和密码。", true);
                return;
              }
              busy = true;
              submit.disabled = true;
              submit.setText("正在登录…");
              setStatus("正在同步账号分组、余额和消费日志…");
              try {
                const result = await bind(username.value, password.value);
                if (!result.ok) { setStatus(accountErrorMessage(result.code), true); return; }
                const pending = result.modelsPending || result.balancePending || result.logsPending;
                notice(pending ? "登录成功，部分账号数据待刷新。" : "登录成功，账号数据已同步。");
                this.close();
              } catch (_) {
                setStatus(accountErrorMessage("NETWORK_UNAVAILABLE"), true);
              } finally {
                busy = false;
                submit.disabled = false;
                submit.setText("登录并同步账号数据");
              }
            });
            return;
          }
          const username = createField(form, "用户名", { id: "mangosteen-register-username", name: "username", type: "text", placeholder: "设置用户名", autocomplete: "username" });
          const email = createField(form, "邮箱", { id: "mangosteen-register-email", name: "email", type: "email", placeholder: "用于登录和接收验证码", autocomplete: "email" });
          const verification = form.createDiv({ cls: "mangosteen-auth-verification" });
          const code = createField(verification, "邮箱验证码", { id: "mangosteen-register-code", name: "verificationCode", type: "text", inputmode: "numeric", placeholder: "请输入验证码", autocomplete: "one-time-code" });
          const send = verification.createEl("button", { text: "发送验证码", attr: { type: "button" } });
          const password = createField(form, "密码", { id: "mangosteen-register-password", name: "password", type: "password", placeholder: "至少 8 位", autocomplete: "new-password" });
          const confirmPassword = createField(form, "确认密码", { id: "mangosteen-register-confirm", name: "confirmPassword", type: "password", placeholder: "再次输入密码", autocomplete: "new-password" });
          const submit = form.createEl("button", { text: "注册并自动登录", cls: "mod-cta mangosteen-auth-submit", attr: { type: "submit" } });
          let verificationBusy = false;
          send.onclick = async () => {
            if (verificationBusy) return;
            if (!/^\S+@\S+\.\S+$/.test(String(email.value || "").trim())) {
              setStatus("请输入正确的邮箱地址。", true);
              return;
            }
            verificationBusy = true;
            send.disabled = true;
            send.setText("发送中…");
            try {
              const result = await api.requestVerification(email.value);
              setStatus(result.ok ? "验证码已发送，请查看邮箱。" : accountErrorMessage(result.code), !result.ok);
            } finally {
              verificationBusy = false;
              send.disabled = false;
              send.setText("发送验证码");
            }
          };
          let busy = false;
          form.addEventListener("submit", async (event) => {
            event?.preventDefault?.();
            if (busy) return;
            if (String(username.value || "").trim().length < 2) { setStatus("用户名至少需要 2 个字符。", true); return; }
            if (!/^\S+@\S+\.\S+$/.test(String(email.value || "").trim())) { setStatus("请输入正确的邮箱地址。", true); return; }
            if (!String(code.value || "").trim()) { setStatus("请输入邮箱验证码。", true); return; }
            if (String(password.value || "").length < 8) { setStatus("密码至少需要 8 位。", true); return; }
            if (password.value !== confirmPassword.value) { setStatus("两次输入的密码不一致。", true); return; }
            busy = true;
            submit.disabled = true;
            submit.setText("正在注册…");
            setStatus("正在创建账号并同步账号数据…");
            try {
              const result = await registerAccount({ username: username.value, email: email.value, verificationCode: code.value, password: password.value });
              if (!result.ok) { setStatus(accountErrorMessage(result.code), true); return; }
              notice(result.modelsPending || result.balancePending || result.logsPending ? "注册成功，部分账号数据待刷新。" : "注册成功，账号数据已同步。");
              this.close();
            } catch (_) {
              setStatus(accountErrorMessage("NETWORK_UNAVAILABLE"), true);
            } finally {
              busy = false;
              submit.disabled = false;
              submit.setText("注册并自动登录");
            }
          });
        };
        loginTab.onclick = () => render("login");
        registerTab.onclick = () => render("register");
        render("login");
      }
    }(app).open();
  }

  function openRecharge() {
    if (!state.account?.userId) { openLogin(); return; }
    if (typeof obsidian.Modal !== "function") return;
    new class extends obsidian.Modal {
      onOpen() {
        const root = this.contentEl;
        root.empty();
        root.createEl("h2", { text: "账号充值" });
        root.createEl("p", { text: `账号编号：${state.account.userId}` });
        const image = root.createEl("img", { attr: { alt: "客服充值二维码" } });
        const pluginDir = String(plugin?.manifest?.dir || ".obsidian/plugins/mangosteen-media-core").replace(/\\/g, "/");
        image.src = app?.vault?.adapter?.getResourcePath?.(`${pluginDir}/assets/recharge-qr.jpg`) || "";
        const input = root.createEl("input", { attr: { type: "text", placeholder: "请输入兑换码" } });
        const status = root.createEl("p", { text: "" });
        const submit = root.createEl("button", { text: "立即兑换", cls: "mod-cta" });
        submit.onclick = async () => {
          submit.disabled = true;
          const result = await api.redeemTopup(state.account, input.value);
          if (!result.ok) { status.setText(accountErrorMessage(result.code)); submit.disabled = false; return; }
          await refreshBalance();
          status.setText("兑换成功，余额已更新。");
        };
      }
    }(app).open();
  }

  function usageStatusText(type) {
    if (Number(type) === 5) return "失败";
    if (Number(type) === 2) return "成功";
    return "已记录";
  }

  function usageTimeText(createdAt) {
    const timestamp = Number(createdAt) || 0;
    if (!timestamp) return "时间未知";
    try { return new Date(timestamp * 1000).toLocaleString("zh-CN", { hour12: false }); } catch (_) { return "时间未知"; }
  }

  function renderUsageLogs(root, rerender) {
    const header = root.createDiv({ cls: "mangosteen-account-card-header" });
    const heading = header.createDiv();
    heading.createEl("h3", { text: "消费日志" });
    heading.createEl("p", { text: "最近 10 条 API 使用记录" });
    const refresh = header.createEl("button", { text: "刷新消费日志" });
    refresh.disabled = usageLogsStatus === "loading" || !state.account?.userId;
    refresh.onclick = async () => {
      refresh.disabled = true;
      await loadRecentUsageLogs(true);
      rerender();
    };
    const body = root.createDiv({ cls: "mangosteen-usage-log-list" });
    if (!state.account?.userId) {
      body.createEl("p", { text: "登录后可查看 API 消费记录。", cls: "mangosteen-account-empty" });
      return;
    }
    if (usageLogsStatus === "idle") {
      body.createEl("p", { text: "正在读取最近消费记录…", cls: "mangosteen-account-empty" });
      void loadRecentUsageLogs().then(rerender).catch(rerender);
      return;
    }
    if (usageLogsStatus === "loading") {
      body.createEl("p", { text: "正在刷新消费日志…", cls: "mangosteen-account-empty" });
      return;
    }
    if (usageLogsStatus === "error") {
      body.createEl("p", { text: "消费日志加载失败，请点击刷新重试。", cls: "mangosteen-account-empty is-error" });
      return;
    }
    if (!recentUsageLogs.items.length) {
      body.createEl("p", { text: "近 30 天暂无消费记录。", cls: "mangosteen-account-empty" });
      return;
    }
    for (const item of recentUsageLogs.items) {
      const row = body.createDiv({ cls: "mangosteen-usage-log-row" });
      const main = row.createDiv({ cls: "mangosteen-usage-log-main" });
      const model = main.createDiv();
      model.createEl("strong", { text: String(item.model || "未知模型") });
      model.createEl("span", { text: String(item.group || "默认分组") });
      main.createEl("span", { text: usageTimeText(item.createdAt), cls: "mangosteen-usage-log-time" });
      const meta = row.createDiv({ cls: "mangosteen-usage-log-meta" });
      meta.createEl("span", { text: `${Math.max(0, Number(item.durationSeconds) || 0)} 秒` });
      meta.createEl("span", { text: `$${(Math.max(0, Number(item.quota) || 0) / QUOTA_PER_USD).toFixed(4)}` });
      const status = usageStatusText(item.type);
      meta.createEl("span", { text: status, cls: `mangosteen-usage-status ${status === "失败" ? "is-error" : "is-success"}` });
    }
  }

  function installSettingsTab() {
    if (typeof plugin?.addSettingTab !== "function" || typeof obsidian.PluginSettingTab !== "function") return;
    class MediaSettingsTab extends obsidian.PluginSettingTab {
      constructor(currentApp, currentPlugin) { super(currentApp, currentPlugin); this.id = "mangosteen-media-core"; this.name = "山竹账号中心"; }
      display() {
        const root = this.containerEl;
        root.empty();
        root.addClass?.("mangosteen-account-center");
        root.classList?.add?.("mangosteen-account-center");
        const hero = root.createDiv({ cls: "mangosteen-account-card mangosteen-account-hero" });
        const heroCopy = hero.createDiv();
        heroCopy.createEl("span", { text: "山竹服务", cls: "mangosteen-account-eyebrow" });
        heroCopy.createEl("h2", { text: "山竹账号中心" });
        heroCopy.createEl("p", { text: "统一管理账号、余额、模型分组和 API 消费记录。" });
        hero.createEl("span", {
          text: state.account?.userId ? "已登录" : "未登录",
          cls: `mangosteen-account-status ${state.account?.userId ? "is-online" : ""}`,
        });
        const overview = root.createDiv({ cls: "mangosteen-account-overview" });
        const accountCard = overview.createDiv({ cls: "mangosteen-account-card mangosteen-account-stat" });
        accountCard.createEl("span", { text: "当前账号" });
        accountCard.createEl("strong", { text: state.account?.label || "尚未登录" });
        accountCard.createEl("small", { text: state.account?.userId ? `账号编号 ${state.account.userId}` : "登录后自动同步模型分组" });
        const balanceCard = overview.createDiv({ cls: "mangosteen-account-card mangosteen-account-stat" });
        balanceCard.createEl("span", { text: "账户余额" });
        balanceCard.createEl("strong", { text: Number.isFinite(Number(state.lastBalance?.quotaUsd)) ? `￥${Number(state.lastBalance.quotaUsd).toFixed(2)}` : "尚未读取" });
        balanceCard.createEl("small", { text: state.lastBalance?.checkedAt ? `最近同步 ${new Date(state.lastBalance.checkedAt).toLocaleString("zh-CN", { hour12: false })}` : "登录后自动读取" });
        const actions = root.createDiv({ cls: "mangosteen-account-actions" });
        const login = actions.createEl("button", { text: state.account?.userId ? "切换账号" : "登录 / 注册", cls: "mod-cta" });
        const recharge = actions.createEl("button", { text: "充值" });
        const refresh = actions.createEl("button", { text: "刷新账号数据" });
        const status = root.createEl("p", { text: "", cls: "mangosteen-account-feedback" });
        login.onclick = () => openLogin();
        recharge.onclick = () => openRecharge();
        refresh.onclick = async () => {
          refresh.disabled = true;
          status.setText("正在刷新语言、图片、视频分组、余额和消费日志…");
          const catalog = await refreshCatalog();
          const [balance, logs] = await Promise.all([refreshBalance(), loadRecentUsageLogs(true)]);
          const failure = !catalog.ok ? catalog : !balance.ok ? balance : !logs.ok ? logs : null;
          status.setText(failure ? accountErrorMessage(failure.code) : "账号数据已刷新。");
          refresh.disabled = false;
          this.display();
        };
        const modelsCard = root.createDiv({ cls: "mangosteen-account-card mangosteen-account-section" });
        modelsCard.createEl("h3", { text: "语言模型配置" });
        modelsCard.createEl("p", { text: "选择后会自动同步到山竹，新对话立即使用新模型。" });
        if (typeof obsidian.Setting === "function") {
          new obsidian.Setting(modelsCard).setName("语言模型分组").setDesc("选择后才会创建该分组的 API Key，并同步到山竹。").addDropdown((dropdown) => {
            dropdown.addOption("", "请选择分组");
            for (const group of languageGroups()) {
              const info = state.groupRatios[group] || {};
              dropdown.addOption(group, String(info.label || group));
            }
            dropdown.setValue(String(state.languageGroup || "")).onChange(async (value) => {
              if (!value) return;
              const result = await selectLanguageGroup(value);
              notice(result.ok ? "语言模型分组已应用到山竹。" : accountErrorMessage(result.code));
              this.display();
            });
          });
          new obsidian.Setting(modelsCard).setName("当前模型").setDesc("只影响新对话；已经打开的对话不会强制切换。").addDropdown((dropdown) => {
            dropdown.addOption("", "请选择模型");
            for (const model of state.modelsByGroup?.[state.languageGroup] || []) dropdown.addOption(model, model);
            dropdown.setValue(String(state.languageModel || "")).onChange(async (value) => {
              if (!value) return;
              const result = await selectLanguageModel(value);
              notice(result.ok ? "默认模型已更新，新对话将使用该模型。" : accountErrorMessage(result.code));
              this.display();
            });
          });
        }
        const reapply = modelsCard.createEl("button", { text: "重新应用配置" });
        reapply.onclick = async () => {
          const result = await reapplyLanguageConfiguration();
          notice(result.ok ? "已重新应用语言模型配置。" : "请先选择语言模型分组和当前模型。");
        };
        const mediaCard = root.createDiv({ cls: "mangosteen-account-card mangosteen-account-section" });
        mediaCard.createEl("h3", { text: "媒体模型目录" });
        for (const [group, models] of Object.entries(state.modelsByGroup || {})) {
          mediaCard.createEl("p", { text: `${group}：${(models || []).join("、")}` });
        }
        const logsCard = root.createDiv({ cls: "mangosteen-account-card mangosteen-account-section mangosteen-usage-card" });
        renderUsageLogs(logsCard, () => this.display());
        root.createEl("p", { text: "账号和媒体密钥仅保存在当前知识库，不会写入安装包或更新包。", cls: "mangosteen-account-privacy" });
      }
    }
    plugin.addSettingTab(new MediaSettingsTab(app, plugin));
  }

  function getBridge() {
    return {
      getAccountUserId: () => String(state.account?.userId || ""),
      getCatalogRevision: () => catalogRevision,
      subscribeCatalog(listener) { catalogListeners.add(listener); return () => catalogListeners.delete(listener); },
      resolveImageAccess: async () => accessFor("image"),
      resolveVideoAccess: async () => accessFor("video"),
      uploadTemporaryImage: (image) => state.account?.userId ? api.uploadTemporaryImage(state.account, image) : Promise.resolve({ ok: false, code: "AUTH_REQUIRED" }),
      uploadTemporaryVideo: (video) => state.account?.userId ? api.uploadTemporaryVideo(state.account, video) : Promise.resolve({ ok: false, code: "AUTH_REQUIRED" }),
      matchMediaUsage,
      refreshCatalog,
      getLanguageConfiguration: async () => languageSnapshot(),
      subscribeLanguageConfiguration(listener) {
        languageListeners.add(listener);
        return () => languageListeners.delete(listener);
      },
    };
  }

  async function initialize(currentPlugin) {
    plugin = currentPlugin;
    app = currentPlugin?.app || app;
    refreshPaths();
    migrateLegacyState();
    state = { ...state, ...readJson(statePath), account: { ...state.account, ...readJson(statePath).account } };
    plugin.getAccountBridge = getBridge;
    const languagePlugin = app?.plugins?.getPlugin?.("mangosteen-claudian")
      || app?.plugins?.plugins?.["mangosteen-claudian"];
    try {
      await languagePlugin?.mangosteenLanguage?.connect?.(app);
    } catch (error) {
      console.warn("Mangosteen media core: language configuration handoff failed", error);
    }
    installSettingsTab();
    plugin.addRibbonIcon?.("circle-user-round", "打开山竹账号中心", () => {
      app?.setting?.open?.();
      app?.setting?.openTabById?.("mangosteen-media-core");
    });
    if (typeof plugin.registerInterval === "function") {
      const timer = setInterval(() => { void refreshCatalog(); void refreshBalance(); }, 30 * 60 * 1000);
      if (typeof timer.unref === "function") timer.unref();
      plugin.registerInterval(timer);
    }
    if (state.account?.userId) void refreshCatalog().then(() => refreshBalance()).catch(() => {});
    writeOperation("媒体核心启动", "已准备");
  }

  return {
    initialize,
    getBridge,
    bind,
    registerAccount,
    refreshCatalog,
    refreshBalance,
    loadRecentUsageLogs,
    selectLanguageGroup,
    selectLanguageModel,
    reapplyLanguageConfiguration,
    dispose() {
      catalogListeners.clear();
      languageListeners.clear();
      refreshPromise = null;
      usageLogsPromise = null;
      plugin = null;
    },
  };
}

module.exports = { STATE_FOLDER, STATE_FILE, accountErrorMessage, createMediaCore, groupKind };
