# Mangosteen Agent bundled RAG backend

This directory is shipped with the Obsidian plugin and is selected automatically
when no custom RAG project path is configured.

The Markdown parser, index, retrieval, and semantic modules are derived from
`vitali87/code-graph-rag` and retain its MIT license in `LICENSE`. Mangosteen-specific
changes provide a standalone four-tool MCP server and remove code-analysis-only
dependencies from the plugin bundle.

Runtime data is written to the active Vault under `.mangosteen-rag/`; it is not
stored in this plugin directory.

## Runtime

The Mac installer creates the virtual environment at `~/.mangosteen-agent/rag-venv`
and places the bundled local BGE model at
`~/.mangosteen/models/Xenova/bge-small-zh-v1.5`. The delivery package also contains
Apple Silicon / Python 3.14 wheels under `installers/rag-wheels`, so the first setup
can install the RAG dependencies without reaching PyPI on that platform. Intel Macs
or other Python versions use the locked `uv sync` fallback to obtain compatible wheels.

The Obsidian plugin starts this installed environment with `uv run --no-sync`; it does
not silently re-download or rebuild the RAG environment while the plugin is running.

