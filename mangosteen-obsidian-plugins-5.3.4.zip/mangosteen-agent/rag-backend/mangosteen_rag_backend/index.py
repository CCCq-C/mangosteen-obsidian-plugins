from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from .models import IndexStatus, KnowledgeSource, SearchResult
from .parser import parse_markdown
from .progress import IndexProgressStore
from .retrieval_text import expand_query_tokens
from .semantic import MarkdownSemanticIndex, semantic_from_environment, vector_id

_TOKEN_RE = re.compile(r"[A-Za-z0-9_+-]+|[\u3400-\u9fff]+")
_IGNORED_DIRECTORY_NAMES = {
    "node_modules",
    "dist",
    "build",
    "__pycache__",
    ".venv",
    "venv",
}


def _is_indexable_markdown(path: Path, vault_path: Path) -> bool:
    if path.suffix.lower() != ".md":
        return False
    try:
        directories = path.relative_to(vault_path).parts[:-1]
    except ValueError:
        return False
    return not any(
        part.startswith(".") or part in _IGNORED_DIRECTORY_NAMES
        for part in directories
    )


def _tokens(text: str) -> list[str]:
    tokens: set[str] = {match.lower() for match in _TOKEN_RE.findall(text)}
    for token in list(tokens):
        if all("\u3400" <= char <= "\u9fff" for char in token):
            tokens.update(token)
            tokens.update(token[index : index + 2] for index in range(len(token) - 1))
    return [token for token in tokens if token]


def _in_scope(path: str, scopes: list[str] | None) -> bool:
    if not scopes:
        return True
    return any(
        path == scope or path.startswith(scope.rstrip("/") + "/") for scope in scopes
    )


def _reference_key(value: str) -> str:
    normalized = value.strip().replace("\\", "/")
    return normalized[:-3].casefold() if normalized.lower().endswith(".md") else normalized.casefold()


def _path_reference_keys(path: str) -> set[str]:
    without_suffix = path[:-3] if path.lower().endswith(".md") else path
    return {without_suffix.casefold(), Path(without_suffix).name.casefold()}


class MarkdownVaultIndex:
    def __init__(
        self,
        vault_path: Path,
        database_path: Path,
        semantic: MarkdownSemanticIndex | None = None,
    ) -> None:
        self.vault_path = vault_path.resolve()
        self.database_path = database_path.resolve()
        self.semantic = semantic if semantic is not None else semantic_from_environment(
            self.vault_path
        )
        self.semantic_error: str | None = None
        self.progress = IndexProgressStore(
            self.vault_path / ".mangosteen-rag" / "progress.json"
        )
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @contextmanager
    def _connect(self):
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS documents (
                    path TEXT PRIMARY KEY,
                    content_hash TEXT NOT NULL,
                    modified_at INTEGER NOT NULL,
                    tags TEXT NOT NULL,
                    links TEXT NOT NULL,
                    chunk_count INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS chunks (
                    id TEXT PRIMARY KEY,
                    path TEXT NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    heading TEXT NOT NULL,
                    line_start INTEGER NOT NULL,
                    line_end INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    tags TEXT NOT NULL,
                    links TEXT NOT NULL,
                    vector_id INTEGER
                );
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts_trigram USING fts5(
                    id UNINDEXED, path, heading, content, tags, links,
                    tokenize='trigram'
                );
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            columns = {
                str(row["name"])
                for row in connection.execute("PRAGMA table_info(chunks)")
            }
            if "vector_id" not in columns:
                connection.execute("ALTER TABLE chunks ADD COLUMN vector_id INTEGER")
            chunk_count = connection.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
            fts_count = connection.execute("SELECT COUNT(*) FROM chunks_fts_trigram").fetchone()[0]
            if fts_count != chunk_count:
                connection.execute("DELETE FROM chunks_fts_trigram")
                connection.execute(
                    "INSERT INTO chunks_fts_trigram SELECT id, path, heading, content, tags, links FROM chunks"
                )

    def _relative_path(self, file_path: Path) -> str:
        return file_path.resolve().relative_to(self.vault_path).as_posix()

    def update_note(self, relative_path: str, on_vector_progress=None) -> IndexStatus:
        file_path = (self.vault_path / relative_path).resolve()
        if not file_path.is_relative_to(self.vault_path):
            raise ValueError("Note path must stay inside the vault")
        semantic_chunks: list[tuple[int, str, str]] = []
        with self._connect() as connection:
            old_rows = [
                row
                for row in connection.execute(
                    "SELECT id, vector_id FROM chunks WHERE path = ?", (relative_path,)
                )
            ]
            old_ids = [str(row["id"]) for row in old_rows]
            old_vector_ids = [int(row["vector_id"]) for row in old_rows if row["vector_id"] is not None]
            connection.execute("DELETE FROM chunks WHERE path = ?", (relative_path,))
            for chunk_id in old_ids:
                connection.execute("DELETE FROM chunks_fts_trigram WHERE id = ?", (chunk_id,))
            connection.execute("DELETE FROM documents WHERE path = ?", (relative_path,))
            if file_path.exists() and _is_indexable_markdown(
                file_path, self.vault_path
            ):
                text = file_path.read_text(encoding="utf-8")
                stat = file_path.stat()
                document = parse_markdown(
                    path=relative_path,
                    text=text,
                    modified_at=stat.st_mtime_ns,
                )
                tags = json.dumps(sorted(document.tags), ensure_ascii=False)
                links = json.dumps(sorted(document.links), ensure_ascii=False)
                digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
                connection.execute(
                    "INSERT INTO documents VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        relative_path,
                        digest,
                        document.modified_at,
                        tags,
                        links,
                        len(document.chunks),
                    ),
                )
                for chunk in document.chunks:
                    chunk_id = f"{relative_path}:{chunk.index}"
                    numeric_vector_id = vector_id(chunk_id) if self.semantic is not None else None
                    values = (
                        chunk_id,
                        relative_path,
                        chunk.index,
                        chunk.heading,
                        chunk.line_start,
                        chunk.line_end,
                        chunk.content,
                        tags,
                        links,
                        numeric_vector_id,
                    )
                    connection.execute(
                        "INSERT INTO chunks VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        values,
                    )
                    connection.execute(
                        "INSERT INTO chunks_fts_trigram VALUES (?, ?, ?, ?, ?, ?)",
                        (
                            chunk_id,
                            relative_path,
                            chunk.heading,
                            chunk.content,
                            tags,
                            links,
                        ),
                    )
                    if numeric_vector_id is not None:
                        semantic_chunks.append((numeric_vector_id, chunk_id, chunk.content))
            self._write_last_updated(connection)
        if self.semantic is not None and old_vector_ids:
            self.semantic.delete_chunks(old_vector_ids)
        if self.semantic is not None and semantic_chunks:
            try:
                self.semantic.index_chunks(
                    semantic_chunks, on_progress=on_vector_progress
                )
            except Exception as error:
                self.semantic_error = str(error)
                with self._connect() as connection:
                    connection.executemany(
                        "UPDATE chunks SET vector_id = NULL WHERE id = ?",
                        ((chunk_id,) for _, chunk_id, _ in semantic_chunks),
                    )
                self.semantic = None
        return self.get_status()

    def index_vault(self) -> IndexStatus:
        if self.semantic is None:
            self.semantic = semantic_from_environment(self.vault_path)
        self.semantic_error = None
        files = [
            file_path
            for file_path in self.vault_path.rglob("*.md")
            if _is_indexable_markdown(file_path, self.vault_path)
        ]
        failed_files: list[str] = []
        with self._connect() as connection:
            existing_rows = connection.execute(
                """
                SELECT documents.path, documents.modified_at,
                       SUM(CASE WHEN chunks.vector_id IS NULL THEN 1 ELSE 0 END) AS missing_vectors,
                       documents.chunk_count
                FROM documents
                LEFT JOIN chunks ON chunks.path = documents.path
                GROUP BY documents.path, documents.modified_at, documents.chunk_count
                """
            ).fetchall()
        existing = {
            str(row["path"]): (
                int(row["modified_at"]),
                int(row["missing_vectors"]),
                int(row["chunk_count"]),
            )
            for row in existing_rows
        }
        semantic_namespace = (
            self.semantic.namespace if self.semantic is not None else ""
        )
        with self._connect() as connection:
            stored_namespace_row = connection.execute(
                "SELECT value FROM metadata WHERE key = 'semantic_namespace'"
            ).fetchone()
        stored_namespace = str(stored_namespace_row[0]) if stored_namespace_row else ""
        force_semantic_reindex = bool(
            self.semantic is not None and semantic_namespace != stored_namespace
        )
        total_files = len(files)
        total_chunks = sum(value[2] for value in existing.values())
        processed_files = 0
        processed_chunks = 0
        phase = "loading-model" if self.semantic is not None else "scanning"
        self.progress.start(
            total_files=total_files,
            total_chunks=total_chunks,
            phase=phase,
        )
        if self.semantic is not None:
            try:
                self.semantic.prepare()
                phase = "vectorizing"
            except Exception as error:
                self.semantic_error = str(error)
                self.semantic = None
                phase = "scanning"
        current: set[str] = set()
        for file_path in files:
            relative_path = self._relative_path(file_path)
            current.add(relative_path)
            self.progress.update(
                processed_files=processed_files,
                total_files=total_files,
                processed_chunks=processed_chunks,
                total_chunks=total_chunks,
                current_file=relative_path,
                phase=phase,
            )
            try:
                cached = existing.get(relative_path)
                if (
                    cached is not None
                    and cached[0] == file_path.stat().st_mtime_ns
                    and (
                        self.semantic is None
                        or (
                            not force_semantic_reindex
                            and self.semantic.ready
                            and cached[1] == 0
                        )
                    )
                ):
                    file_chunk_count = cached[2]
                else:
                    self.update_note(
                        relative_path,
                        on_vector_progress=lambda completed, total: self.progress.update(
                            processed_files=processed_files,
                            total_files=total_files,
                            processed_chunks=processed_chunks + completed,
                            total_chunks=max(total_chunks, processed_chunks + total),
                            current_file=relative_path,
                            phase="vectorizing",
                        ),
                    )
                    with self._connect() as connection:
                        row = connection.execute(
                            "SELECT chunk_count FROM documents WHERE path = ?",
                            (relative_path,),
                        ).fetchone()
                    file_chunk_count = int(row[0]) if row else 0
            except (OSError, UnicodeError, sqlite3.Error):
                failed_files.append(relative_path)
                file_chunk_count = 0
            processed_files += 1
            processed_chunks += file_chunk_count
            total_chunks = max(total_chunks, processed_chunks)
            phase = "vectorizing" if self.semantic is not None else "scanning"
            self.progress.update(
                processed_files=processed_files,
                total_files=total_files,
                processed_chunks=processed_chunks,
                total_chunks=total_chunks,
                current_file=relative_path,
                phase=phase,
            )
        for removed in set(existing) - current:
            self.update_note(removed)
        failed_files.extend(self._find_ambiguous_link_files())
        failed_files = sorted(set(failed_files))
        with self._connect() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO metadata VALUES ('failed_files', ?)",
                (json.dumps(failed_files, ensure_ascii=False),),
            )
            if self.semantic is not None and not self.semantic_error:
                connection.execute(
                    "INSERT OR REPLACE INTO metadata VALUES ('semantic_namespace', ?)",
                    (self.semantic.namespace,),
                )
            self._write_last_updated(connection)
        status = self.get_status()
        if self.semantic_error:
            self.progress.fail(self.semantic_error)
        else:
            self.progress.complete(
                total_files=status.file_count,
                total_chunks=status.chunk_count,
            )
        return status

    def _find_ambiguous_link_files(self) -> list[str]:
        with self._connect() as connection:
            rows = connection.execute("SELECT path, links FROM documents").fetchall()
        by_basename: dict[str, set[str]] = {}
        for row in rows:
            path = str(row["path"])
            basename = Path(path).stem.casefold()
            by_basename.setdefault(basename, set()).add(path)

        failures: list[str] = []
        for row in rows:
            path = str(row["path"])
            links = json.loads(str(row["links"]))
            for link in links:
                key = _reference_key(str(link))
                if "/" not in key and len(by_basename.get(key, set())) > 1:
                    failures.append(path)
                    break
        return failures

    @staticmethod
    def _write_last_updated(connection: sqlite3.Connection) -> None:
        now = datetime.now(UTC).isoformat()
        connection.execute(
            "INSERT OR REPLACE INTO metadata VALUES ('last_updated_at', ?)", (now,)
        )

    def get_status(self) -> IndexStatus:
        with self._connect() as connection:
            file_count = connection.execute(
                "SELECT COUNT(*) FROM documents"
            ).fetchone()[0]
            chunk_count = connection.execute(
                "SELECT COUNT(*) FROM chunks"
            ).fetchone()[0]
            metadata = dict(connection.execute("SELECT key, value FROM metadata"))
        return IndexStatus(
            file_count=file_count,
            chunk_count=chunk_count,
            failed_files=json.loads(metadata.get("failed_files", "[]")),
            last_updated_at=metadata.get("last_updated_at"),
            mode=(
                "hybrid"
                if self.semantic is not None and self.semantic.ready
                else "keyword-graph"
            ),
        )

    def search(
        self,
        query: str,
        *,
        scope_paths: list[str] | None = None,
        top_k: int = 6,
    ) -> SearchResult:
        query_tokens = expand_query_tokens(_tokens(query), query)
        chunk_columns = "path, heading, line_start, line_end, content, tags, links, vector_id"
        with self._connect() as connection:
            fts_terms = [token for token in query_tokens if len(token) >= 3]
            if fts_terms:
                expression = " OR ".join(f'"{token.replace(chr(34), chr(34) * 2)}"' for token in fts_terms)
                chunk_ids = [
                    str(row[0])
                    for row in connection.execute(
                        "SELECT id FROM chunks_fts_trigram WHERE chunks_fts_trigram MATCH ? LIMIT 500",
                        (expression,),
                    )
                ]
                placeholders = ",".join("?" for _ in chunk_ids)
                rows = connection.execute(
                    f"SELECT {chunk_columns} FROM chunks WHERE id IN ({placeholders})",
                    chunk_ids,
                ).fetchall() if chunk_ids else []
            else:
                rows = connection.execute(f"SELECT {chunk_columns} FROM chunks").fetchall()
            document_rows = connection.execute(
                "SELECT path, tags, links FROM documents"
            ).fetchall()
        scored: list[KnowledgeSource] = []
        for row in rows:
            path = str(row["path"])
            if not _in_scope(path, scope_paths):
                continue
            heading = str(row["heading"]).lower()
            content = str(row["content"]).lower()
            tags = str(row["tags"]).lower()
            links = str(row["links"]).lower()
            lower_path = path.lower()
            match_types: list[str] = []
            if any(token in heading for token in query_tokens):
                match_types.append("title")
            if any(token in tags for token in query_tokens):
                match_types.append("tag")
            if any(token in links for token in query_tokens):
                match_types.append("link")
            if any(token in lower_path for token in query_tokens):
                match_types.append("path")
            if any(token in content for token in query_tokens):
                match_types.append("content")
            score = sum(
                (8 if token in heading else 0)
                + (6 if token in tags else 0)
                + (5 if token in links else 0)
                + (4 if token in lower_path else 0)
                + (1 if token in content else 0)
                for token in query_tokens
            )
            if score:
                scored.append(
                    KnowledgeSource(
                        path=path,
                        heading=str(row["heading"]),
                        line_start=int(row["line_start"]),
                        line_end=int(row["line_end"]),
                        content=str(row["content"]),
                        score=float(score),
                        match_types=match_types,
                    )
                )
        scored.sort(key=lambda source: (-source.score, source.path, source.line_start))
        keyword_candidate_count = len(scored)
        semantic_candidate_count = 0
        semantic_active = self.semantic is not None and self.semantic.ready
        if self.semantic is not None:
            try:
                semantic_scores = dict(self.semantic.search(query, 10))
                semantic_candidate_count = len(semantic_scores)
                semantic_active = self.semantic.ready
                self.semantic_error = None
                vector_ids = [int(item) for item in semantic_scores]
                if vector_ids:
                    placeholders = ",".join("?" for _ in vector_ids)
                    with self._connect() as connection:
                        semantic_rows = connection.execute(
                            f"SELECT {chunk_columns} FROM chunks WHERE vector_id IN ({placeholders})",
                            vector_ids,
                        ).fetchall()
                else:
                    semantic_rows = []
                by_vector_id = {
                    int(row["vector_id"]): row
                    for row in semantic_rows
                    if row["vector_id"] is not None
                }
                for numeric_id, vector_score in semantic_scores.items():
                    row = by_vector_id.get(numeric_id)
                    if row is None or not _in_scope(str(row["path"]), scope_paths):
                        continue
                    scored.append(
                        KnowledgeSource(
                            path=str(row["path"]),
                            heading=str(row["heading"]),
                            line_start=int(row["line_start"]),
                            line_end=int(row["line_end"]),
                            content=str(row["content"]),
                            score=float(vector_score) * 10,
                            match_types=["vector"],
                        )
                    )
            except Exception as error:
                # A cloud timeout or temporary vector-store error must only
                # affect this request. Keep the backend so the next search can
                # recover automatically instead of staying keyword-only until
                # Obsidian restarts.
                self.semantic_error = str(error)
                semantic_active = False
                semantic_candidate_count = 0
        deduplicated: dict[tuple[str, int], KnowledgeSource] = {}
        for source in scored:
            key = (source.path, source.line_start)
            current = deduplicated.get(key)
            if current is None or source.score > current.score:
                if current is not None:
                    source.match_types = list(
                        dict.fromkeys(current.match_types + source.match_types)
                    )
                deduplicated[key] = source
            elif current is not None:
                current.match_types = list(
                    dict.fromkeys(current.match_types + source.match_types)
                )
        ranked = sorted(
            deduplicated.values(),
            key=lambda source: (-source.score, source.path, source.line_start),
        )
        lexical = ranked[:10]
        seed_paths = {source.path for source in lexical}
        if not seed_paths:
            return SearchResult(
                mode="hybrid" if semantic_active else "keyword-graph",
                sources=[],
                diagnostics={
                    "keyword_candidates": keyword_candidate_count,
                    "vector_candidates": semantic_candidate_count,
                    "graph_expanded": 0,
                    "final_sources": 0,
                },
            )

        metadata = {
            str(row["path"]): (
                set(json.loads(str(row["tags"]))),
                {_reference_key(str(link)) for link in json.loads(str(row["links"]))},
            )
            for row in document_rows
        }
        tag_counts: dict[str, int] = {}
        for tags, _links in metadata.values():
            for tag in tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        max_graph_tag_frequency = max(2, len(metadata) // 5)
        seed_tags: set[str] = set()
        seed_links: set[str] = set()
        seed_reference_keys: set[str] = set()
        for path in seed_paths:
            tags, links = metadata.get(path, (set(), set()))
            seed_tags.update(
                tag for tag in tags if tag_counts.get(tag, 0) <= max_graph_tag_frequency
            )
            seed_links.update(links)
            seed_reference_keys.update(_path_reference_keys(path))

        related_paths: set[str] = set()
        for path, (tags, links) in metadata.items():
            if path in seed_paths or not _in_scope(path, scope_paths):
                continue
            path_keys = _path_reference_keys(path)
            if (
                seed_tags.intersection(tags)
                or seed_links.intersection(path_keys)
                or links.intersection(seed_reference_keys)
            ):
                related_paths.add(path)

        if related_paths:
            placeholders = ",".join("?" for _ in related_paths)
            with self._connect() as connection:
                graph_rows = connection.execute(
                    f"SELECT {chunk_columns} FROM chunks WHERE path IN ({placeholders})",
                    list(related_paths),
                ).fetchall()
        else:
            graph_rows = []

        result_by_key = {
            (source.path, source.line_start): source for source in lexical
        }
        for row in graph_rows:
            path = str(row["path"])
            if path not in related_paths:
                continue
            key = (path, int(row["line_start"]))
            result_by_key.setdefault(
                key,
                KnowledgeSource(
                    path=path,
                    heading=str(row["heading"]),
                    line_start=int(row["line_start"]),
                    line_end=int(row["line_end"]),
                    content=str(row["content"]),
                    score=0.5,
                    match_types=["graph"],
                ),
            )

        expanded = sorted(
            result_by_key.values(),
            key=lambda source: (-source.score, source.path, source.line_start),
        )
        final_sources = expanded[:top_k]
        return SearchResult(
            mode="hybrid" if semantic_active else "keyword-graph",
            sources=final_sources,
            diagnostics={
                "keyword_candidates": keyword_candidate_count,
                "vector_candidates": semantic_candidate_count,
                "graph_expanded": len(related_paths),
                "final_sources": len(final_sources),
            },
        )
