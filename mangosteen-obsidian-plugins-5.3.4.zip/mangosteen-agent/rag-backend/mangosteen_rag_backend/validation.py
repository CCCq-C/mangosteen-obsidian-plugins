from __future__ import annotations

from pathlib import PurePosixPath, PureWindowsPath


def validate_vault_relative_path(value: object, label: str = "知识库路径") -> str:
    path = str(value or "").strip().replace("\\", "/")
    if not path:
        raise ValueError(f"请输入{label}。")
    if PurePosixPath(path).is_absolute() or PureWindowsPath(path).is_absolute():
        raise ValueError(f"{label}必须是知识库内的相对路径。")
    parts = PurePosixPath(path).parts
    if any(part in {"", ".", ".."} for part in parts) or "\x00" in path:
        raise ValueError(f"{label}包含不安全的路径片段。")
    return "/".join(parts)


def validate_search_input(
    query: object,
    top_k: object = 6,
    scope_paths: object = None,
) -> tuple[str, int, list[str] | None]:
    normalized_query = str(query or "").strip()
    if not normalized_query:
        raise ValueError("请输入要检索的内容。")
    if len(normalized_query) > 4000:
        raise ValueError("检索内容过长，请缩短后重试。")
    try:
        requested_top_k = int(top_k)
    except (TypeError, ValueError) as error:
        raise ValueError("返回数量必须是 1 到 20 的整数。") from error
    if requested_top_k < 1:
        raise ValueError("返回数量必须是 1 到 20 的整数。")
    bounded_top_k = min(20, requested_top_k)
    if scope_paths is None:
        return normalized_query, bounded_top_k, None
    if not isinstance(scope_paths, list):
        raise ValueError("检索范围必须是路径列表。")
    normalized_scopes = list(
        dict.fromkeys(validate_vault_relative_path(item, "检索范围路径") for item in scope_paths)
    )
    return normalized_query, bounded_top_k, normalized_scopes or None
