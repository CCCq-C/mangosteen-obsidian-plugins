from __future__ import annotations

import re
import unicodedata

_HAN_RUN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]+")
_ASCII_TERM = re.compile(r"[a-z0-9][a-z0-9._+-]*")


def expand_query_tokens(base_tokens: list[str], query: str) -> list[str]:
    """Build stable search terms while avoiding noisy single Chinese characters."""
    normalized = unicodedata.normalize("NFKC", query).casefold()
    terms = {
        unicodedata.normalize("NFKC", token).casefold().strip()
        for token in base_tokens
        if token.strip()
    }
    terms.update(_ASCII_TERM.findall(normalized))
    for run in _HAN_RUN.findall(normalized):
        if len(run) <= 8:
            terms.add(run)
        for size in range(2, min(4, len(run)) + 1):
            terms.update(run[start : start + size] for start in range(len(run) - size + 1))
    return sorted(terms, key=lambda term: (-len(term), term))

