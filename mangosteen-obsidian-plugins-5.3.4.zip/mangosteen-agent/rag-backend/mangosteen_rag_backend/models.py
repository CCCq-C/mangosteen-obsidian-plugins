from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class MarkdownChunk:
    path: str
    index: int
    heading: str
    line_start: int
    line_end: int
    content: str


@dataclass(slots=True)
class MarkdownDocument:
    path: str
    modified_at: int
    frontmatter: dict[str, Any]
    tags: set[str]
    links: set[str]
    chunks: list[MarkdownChunk]


@dataclass(slots=True)
class KnowledgeSource:
    path: str
    heading: str
    line_start: int
    line_end: int
    content: str
    score: float
    match_types: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class SearchResult:
    mode: str
    sources: list[KnowledgeSource]
    diagnostics: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "sources": [source.to_dict() for source in self.sources],
            "diagnostics": self.diagnostics,
        }


@dataclass(slots=True)
class IndexStatus:
    file_count: int = 0
    chunk_count: int = 0
    failed_files: list[str] = field(default_factory=list)
    last_updated_at: str | None = None
    mode: str = "keyword-graph"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

