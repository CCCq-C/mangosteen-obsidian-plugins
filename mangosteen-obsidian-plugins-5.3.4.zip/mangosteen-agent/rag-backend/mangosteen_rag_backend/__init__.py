"""Bundled Markdown RAG backend for Mangosteen Agent."""

from .index import MarkdownVaultIndex

__all__ = ["MarkdownVaultIndex"]

