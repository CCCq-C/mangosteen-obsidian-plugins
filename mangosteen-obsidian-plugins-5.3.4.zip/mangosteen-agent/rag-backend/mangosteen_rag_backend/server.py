from __future__ import annotations

import asyncio
import json
import logging
import os
import numpy as _windows_numpy_preload  # Load native extension before asyncio starts on Windows.
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .index import MarkdownVaultIndex
from .validation import validate_search_input, validate_vault_relative_path

SERVER_NAME = "mangosteen-rag"
ToolHandler = Callable[..., Awaitable[dict[str, Any]]]


def get_vault_root() -> Path:
    configured = os.environ.get("MANGOSTEEN_VAULT_PATH")
    root = Path(configured or Path.cwd()).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError(f"Obsidian 知识库不存在或无法访问：{root}")
    return root


def get_database_path(vault_root: Path) -> Path:
    configured = os.environ.get("MANGOSTEEN_INDEX_PATH")
    if configured:
        return Path(configured).expanduser().resolve()
    return vault_root / ".mangosteen-rag" / "index.sqlite3"


def _tool_definitions() -> list[Tool]:
    return [
        Tool(
            name="index_vault",
            description="Index all Markdown notes in the Obsidian vault.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="update_note",
            description="Incrementally update or remove one Markdown note.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Vault-relative Markdown path."}
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="search_vault",
            description="Search indexed Obsidian knowledge with traceable sources.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "top_k": {"type": "integer"},
                    "scope_paths": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="get_index_status",
            description="Return Markdown index counts and failures.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
    ]


def create_server() -> Server:
    vault_root = get_vault_root()
    index = MarkdownVaultIndex(vault_root, get_database_path(vault_root))
    server = Server(SERVER_NAME)

    async def index_vault(**_arguments: Any) -> dict[str, Any]:
        return index.index_vault().to_dict()

    async def update_note(path: str, **_arguments: Any) -> dict[str, Any]:
        return index.update_note(validate_vault_relative_path(path, "笔记路径")).to_dict()

    async def search_vault(
        query: str,
        top_k: int = 6,
        scope_paths: list[str] | None = None,
        **_arguments: Any,
    ) -> dict[str, Any]:
        query, top_k, scope_paths = validate_search_input(query, top_k, scope_paths)
        return index.search(query, scope_paths=scope_paths, top_k=top_k).to_dict()

    async def get_index_status(**_arguments: Any) -> dict[str, Any]:
        return index.get_status().to_dict()

    handlers: dict[str, ToolHandler] = {
        "index_vault": index_vault,
        "update_note": update_note,
        "search_vault": search_vault,
        "get_index_status": get_index_status,
    }

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return _tool_definitions()

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        handler = handlers.get(name)
        if handler is None:
            return [TextContent(type="text", text=f"山竹本地知识库不支持这个操作：{name}")]
        try:
            result = await handler(**arguments)
            return [
                TextContent(
                    type="text",
                    text=json.dumps(result, ensure_ascii=False),
                )
            ]
        except Exception as error:
            logging.exception("Mangosteen RAG tool failed: %s", name)
            message = str(error) if isinstance(error, (ValueError, FileNotFoundError)) else "本地知识库处理失败，请重启 Obsidian 后重试；仍然失败时请运行安装程序修复。"
            return [TextContent(type="text", text=message)]

    return server


async def serve_stdio() -> None:
    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    asyncio.run(serve_stdio())


if __name__ == "__main__":
    main()
