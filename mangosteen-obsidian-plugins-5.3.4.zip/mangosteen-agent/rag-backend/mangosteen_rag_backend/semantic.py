from __future__ import annotations

import hashlib
import os
from collections.abc import Callable
from pathlib import Path
from typing import Protocol


class MarkdownSemanticIndex(Protocol):
    ready: bool
    namespace: str

    def prepare(self) -> None: ...

    def index_chunks(
        self,
        chunks: list[tuple[int, str, str]],
        on_progress: Callable[[int, int], None] | None = None,
    ) -> None: ...

    def delete_chunks(self, chunk_ids: list[int]) -> None: ...

    def search(self, query: str, top_k: int) -> list[tuple[int, float]]: ...


def vector_id(chunk_id: str) -> int:
    digest = hashlib.sha256(chunk_id.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") & ((1 << 63) - 1)


class LocalBgeQdrantSemanticIndex:
    namespace = "local-bge-small-zh-v1.5-q8-512-v1"
    collection_name = "mangosteen_markdown_local_bge_512"

    def __init__(self, *, model_path: Path, qdrant_path: Path) -> None:
        self._model_path = model_path
        self._qdrant_path = qdrant_path
        self._embedder = None
        self._client = None
        self.ready = False

    def prepare(self) -> None:
        if self._embedder is None:
            from .local_embedding import LocalBgeEmbedder

            self._embedder = LocalBgeEmbedder(self._model_path)
        if self._client is None:
            from qdrant_client import QdrantClient
            from qdrant_client.models import Distance, VectorParams

            self._qdrant_path.mkdir(parents=True, exist_ok=True)
            self._client = QdrantClient(path=str(self._qdrant_path))
            collections = {
                item.name for item in self._client.get_collections().collections
            }
            if self.collection_name not in collections:
                self._client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(size=512, distance=Distance.COSINE),
                )
        self.ready = True

    def index_chunks(
        self,
        chunks: list[tuple[int, str, str]],
        on_progress: Callable[[int, int], None] | None = None,
    ) -> None:
        if not chunks:
            return
        from qdrant_client.models import PointStruct

        self.prepare()
        embeddings = self._embedder.embed_documents(
            [content for _, _, content in chunks], on_progress=on_progress
        )
        self._client.upsert(
            collection_name=self.collection_name,
            points=[
                PointStruct(
                    id=chunk_id,
                    vector=embedding,
                    payload={"source_id": source_id},
                )
                for (chunk_id, source_id, _), embedding in zip(chunks, embeddings)
            ],
            wait=True,
        )
        self.ready = True

    def delete_chunks(self, chunk_ids: list[int]) -> None:
        if not chunk_ids:
            return
        self.prepare()
        self._client.delete(
            collection_name=self.collection_name,
            points_selector=chunk_ids,
            wait=True,
        )

    def search(self, query: str, top_k: int) -> list[tuple[int, float]]:
        self.prepare()
        embedding = self._embedder.embed_query(query)
        result = self._client.query_points(
            collection_name=self.collection_name,
            query=embedding,
            limit=top_k,
            with_payload=False,
        )
        return [
            (int(point.id), float(point.score))
            for point in result.points
            if isinstance(point.id, int)
        ]


def semantic_from_environment(vault_path: Path) -> MarkdownSemanticIndex | None:
    mode = os.environ.get("MANGOSTEEN_EMBEDDING_MODE", "").strip().lower()
    if mode != "local":
        return None
    model_path = Path(
        os.environ.get(
            "MANGOSTEEN_LOCAL_EMBEDDING_PATH",
            str(
                Path.home()
                / ".mangosteen"
                / "models"
                / "Xenova"
                / "bge-small-zh-v1.5"
            ),
        )
    ).expanduser()
    if not (model_path / "onnx" / "model_quantized.onnx").is_file():
        return None
    try:
        return LocalBgeQdrantSemanticIndex(
            model_path=model_path,
            qdrant_path=vault_path / ".mangosteen-rag" / "qdrant",
        )
    except (ImportError, TypeError, ValueError):
        return None

