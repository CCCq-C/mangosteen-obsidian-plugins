from __future__ import annotations

import re
from typing import Any

try:
    import yaml
except ImportError:  # The installer normally provides PyYAML; keep basic notes usable if it is missing.
    yaml = None

from .models import MarkdownChunk, MarkdownDocument

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")
_TAG_RE = re.compile(r"(?:^|\s)#([\w\-/\u3400-\u9fff]+)")
_LINK_RE = re.compile(r"\[\[([^\]|#]+)(?:[|#][^\]]*)?\]\]")


def _scalar(value: str) -> Any:
    normalized = value.strip()
    if normalized.startswith("[") and normalized.endswith("]"):
        return [
            part.strip().strip("'\"")
            for part in normalized[1:-1].split(",")
            if part.strip()
        ]
    if normalized.lower() in {"true", "false"}:
        return normalized.lower() == "true"
    return normalized.strip("'\"")


def _frontmatter(lines: list[str]) -> tuple[dict[str, Any], int]:
    if not lines or lines[0].strip() != "---":
        return {}, 0
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            source = "\n".join(lines[1:index])
            if yaml is not None:
                try:
                    parsed = yaml.safe_load(source) or {}
                    return (parsed if isinstance(parsed, dict) else {}), index + 1
                except yaml.YAMLError:
                    pass
            result: dict[str, Any] = {}
            for line in lines[1:index]:
                if ":" in line:
                    key, value = line.split(":", 1)
                    result[key.strip()] = _scalar(value)
            return result, index + 1
    return {}, 0


def _split_text(content: str, max_chars: int, overlap_chars: int) -> list[str]:
    if len(content) <= max_chars:
        return [content]
    result: list[str] = []
    start = 0
    while start < len(content):
        end = min(len(content), start + max_chars)
        result.append(content[start:end])
        if end == len(content):
            break
        start = max(start + 1, end - overlap_chars)
    return result


def parse_markdown(
    *,
    path: str,
    text: str,
    modified_at: int,
    max_chars: int = 1000,
    overlap_chars: int = 120,
) -> MarkdownDocument:
    lines = text.splitlines()
    frontmatter, body_start = _frontmatter(lines)
    tags = set(_TAG_RE.findall(text))
    frontmatter_tags = frontmatter.get("tags", [])
    if isinstance(frontmatter_tags, str):
        tags.add(frontmatter_tags)
    elif isinstance(frontmatter_tags, list):
        tags.update(str(tag) for tag in frontmatter_tags)
    links = {match.strip() for match in _LINK_RE.findall(text) if match.strip()}

    chunks: list[MarkdownChunk] = []
    heading_stack: list[str] = []
    current_heading = ""
    current_start = body_start + 1
    current_lines: list[str] = []

    def flush(end_line: int) -> None:
        content = "\n".join(current_lines).strip()
        if not content and not current_heading:
            return
        for part in _split_text(content or current_heading, max_chars, overlap_chars):
            chunks.append(
                MarkdownChunk(
                    path=path,
                    index=len(chunks),
                    heading=current_heading,
                    line_start=current_start,
                    line_end=max(current_start, end_line),
                    content=part,
                )
            )

    for line_index in range(body_start, len(lines)):
        line = lines[line_index]
        match = _HEADING_RE.match(line)
        if not match:
            current_lines.append(line)
            continue
        flush(line_index)
        level = len(match.group(1))
        heading_stack[level - 1 :] = [match.group(2).strip()]
        current_heading = " > ".join(item for item in heading_stack if item)
        current_start = line_index + 2
        current_lines = []
    flush(len(lines))

    return MarkdownDocument(
        path=path,
        modified_at=modified_at,
        frontmatter=frontmatter,
        tags=tags,
        links=links,
        chunks=chunks,
    )
