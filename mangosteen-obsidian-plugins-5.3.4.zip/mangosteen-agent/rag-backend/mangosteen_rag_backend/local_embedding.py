from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any, Protocol

import numpy as np

BGE_QUERY_INSTRUCTION = "为这个句子生成表示以用于检索相关文章："


class _Encoding(Protocol):
    ids: list[int]
    attention_mask: list[int]
    type_ids: list[int]


class _Tokenizer(Protocol):
    def enable_truncation(self, *, max_length: int) -> None: ...

    def enable_padding(self, *, pad_id: int, pad_token: str) -> None: ...

    def encode_batch(self, texts: list[str]) -> list[_Encoding]: ...


class _SessionInput(Protocol):
    name: str


class _Session(Protocol):
    def get_inputs(self) -> list[_SessionInput]: ...

    def run(
        self, outputs: object, feeds: dict[str, np.ndarray]
    ) -> list[np.ndarray]: ...


class LocalBgeEmbedder:
    def __init__(
        self,
        model_path: Path | None = None,
        *,
        tokenizer: _Tokenizer | None = None,
        session: _Session | None = None,
        dimensions: int = 512,
        batch_size: int = 8,
    ) -> None:
        if tokenizer is None or session is None:
            if model_path is None:
                raise ValueError("A local BGE model path is required")
            tokenizer_path = model_path / "tokenizer.json"
            onnx_path = model_path / "onnx" / "model_quantized.onnx"
            if not tokenizer_path.is_file() or not onnx_path.is_file():
                raise FileNotFoundError("The local BGE model is incomplete")
            from onnxruntime import InferenceSession, SessionOptions
            from tokenizers import Tokenizer

            options = SessionOptions()
            options.intra_op_num_threads = 2
            tokenizer = Tokenizer.from_file(str(tokenizer_path))
            session = InferenceSession(
                str(onnx_path),
                sess_options=options,
                providers=["CPUExecutionProvider"],
            )
        self._tokenizer = tokenizer
        self._session = session
        self._dimensions = dimensions
        self._batch_size = batch_size
        self._tokenizer.enable_truncation(max_length=512)
        self._tokenizer.enable_padding(pad_id=0, pad_token="[PAD]")

    def embed_query(self, query: str) -> list[float]:
        return self._embed([BGE_QUERY_INSTRUCTION + query])[0]

    def embed_documents(
        self,
        documents: list[str],
        on_progress: Callable[[int, int], None] | None = None,
    ) -> list[list[float]]:
        vectors: list[list[float]] = []
        total = len(documents)
        for start in range(0, len(documents), self._batch_size):
            vectors.extend(self._embed(documents[start : start + self._batch_size]))
            if on_progress is not None:
                on_progress(min(start + self._batch_size, total), total)
        return vectors

    def _embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        encoded = self._tokenizer.encode_batch(texts)
        values: dict[str, np.ndarray] = {
            "input_ids": np.asarray([item.ids for item in encoded], dtype=np.int64),
            "attention_mask": np.asarray(
                [item.attention_mask for item in encoded], dtype=np.int64
            ),
            "token_type_ids": np.asarray(
                [item.type_ids for item in encoded], dtype=np.int64
            ),
        }
        input_names = {item.name for item in self._session.get_inputs()}
        feeds = {name: value for name, value in values.items() if name in input_names}
        output = np.asarray(self._session.run(None, feeds)[0], dtype=np.float32)
        if output.ndim != 3 or output.shape[2] != self._dimensions:
            raise RuntimeError(
                f"Local BGE returned {output.shape}; expected (*, *, {self._dimensions})"
            )
        cls_vectors = output[:, 0, :]
        norms = np.linalg.norm(cls_vectors, axis=1, keepdims=True)
        if np.any(norms == 0):
            raise RuntimeError("Local BGE returned an empty vector")
        normalized = cls_vectors / norms
        return [row.tolist() for row in normalized]

