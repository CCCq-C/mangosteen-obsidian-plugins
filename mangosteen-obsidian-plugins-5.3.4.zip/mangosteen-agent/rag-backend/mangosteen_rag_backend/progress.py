from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path


def _now() -> str:
    return datetime.now(UTC).isoformat()


@dataclass(slots=True)
class IndexProgress:
    state: str = "idle"
    phase: str = "idle"
    processed_files: int = 0
    total_files: int = 0
    processed_chunks: int = 0
    total_chunks: int = 0
    current_file: str = ""
    started_at: str | None = None
    updated_at: str | None = None
    completed_at: str | None = None
    error: str | None = None


class IndexProgressStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.current = IndexProgress()

    def start(self, *, total_files: int, total_chunks: int, phase: str) -> None:
        now = _now()
        self.current = IndexProgress(
            state="running",
            phase=phase,
            total_files=total_files,
            total_chunks=total_chunks,
            started_at=now,
            updated_at=now,
        )
        self._write()

    def update(
        self,
        *,
        processed_files: int,
        total_files: int,
        processed_chunks: int,
        total_chunks: int,
        current_file: str,
        phase: str,
    ) -> None:
        self.current.processed_files = processed_files
        self.current.total_files = total_files
        self.current.processed_chunks = processed_chunks
        self.current.total_chunks = total_chunks
        self.current.current_file = current_file
        self.current.phase = phase
        self.current.updated_at = _now()
        self._write()

    def complete(self, *, total_files: int, total_chunks: int) -> None:
        now = _now()
        self.current.state = "completed"
        self.current.phase = "completed"
        self.current.processed_files = total_files
        self.current.total_files = total_files
        self.current.processed_chunks = total_chunks
        self.current.total_chunks = total_chunks
        self.current.current_file = ""
        self.current.updated_at = now
        self.current.completed_at = now
        self.current.error = None
        self._write()

    def fail(self, error: str) -> None:
        self.current.state = "failed"
        self.current.phase = "failed"
        self.current.current_file = ""
        self.current.updated_at = _now()
        self.current.error = error
        self._write()

    def _write(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(self.path.suffix + ".tmp")
            temporary.write_text(
                json.dumps(asdict(self.current), ensure_ascii=False),
                encoding="utf-8",
            )
            temporary.replace(self.path)
        except OSError:
            # Progress reporting must never interrupt indexing.
            return

