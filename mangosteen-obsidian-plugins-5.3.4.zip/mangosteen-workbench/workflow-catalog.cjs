const {
  getEnabledBusinessModules,
  normalizeWorkflowInput,
  buildWorkflowTask
} = require("./workflow-model.cjs");

class WorkflowCatalog {
  constructor(queries = {}) {
    this.findLatestWorkflowSourcePath = queries.findLatestWorkflowSourcePath || (() => "");
    this.collectNovelProjectProgress = queries.collectNovelProjectProgress || (() => ({}));
    this.collectProductHistoryOptions = queries.collectProductHistoryOptions || (() => []);
  }

  getWorkflowPageConfig(page, context = {}) {
    const novelProjectName = context.project_name || context.project || "";
    const novelProjectPath = context.project_path || (novelProjectName ? `山竹智能体知识库/写小说/作品项目/${novelProjectName}` : "");
    const novelProjectTitle = novelProjectName || (novelProjectPath ? novelProjectPath.split("/").filter(Boolean).at(-1) : "当前小说项目");
    const novelProjectProgress = this.collectNovelProjectProgress(novelProjectPath, novelProjectTitle);
    const codingProjectName = context.project_name || context.project || "";
    const codingProjectPath = context.project_path || (codingProjectName ? `山竹智能体知识库/AI编程/项目库/${codingProjectName}` : "");
    const codingProjectTitle = codingProjectName || (codingProjectPath ? codingProjectPath.split("/").filter(Boolean).at(-1) : "");
    const sourceOptions = ["读取上一环节归档结果", "自定义输入", "上一环节 + 自定义补充", "指定笔记路径"];
    const officeSourceOptions = ["导入新的文件", "指定笔记/目录", "从办公资料库选择", "最近办公结果", "直接粘贴材料"];
    const latestPlatformData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/短视频带货/平台找品/"]);
    const latestProductRecordData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/短视频带货/AI选品评分/", "山竹智能体知识库/短视频带货/选品记录/", "山竹智能体知识库/短视频带货/平台找品/"]);
    const latestSelectionData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/短视频带货/选品记录/", "山竹智能体知识库/短视频带货/AI选品评分/", "山竹智能体知识库/短视频带货/平台找品/"]);
    const latestContentData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/短视频带货/内容形式判断/", "山竹智能体知识库/短视频带货/选品记录/", "山竹智能体知识库/短视频带货/AI选品评分/", "山竹智能体知识库/短视频带货/平台找品/"]);
    const latestScriptData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/短视频带货/产品脚本/", "山竹智能体知识库/短视频带货/AI选品评分/", "山竹智能体知识库/短视频带货/素材库/商品主图/", "山竹智能体知识库/短视频带货/选品记录/", "山竹智能体知识库/短视频带货/内容形式判断/"]);
    const latestVideoData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/短视频带货/制作视频/", "山竹智能体知识库/短视频带货/产品脚本/", "山竹智能体知识库/短视频带货/AI选品评分/", "山竹智能体知识库/短视频带货/素材库/商品主图/", "山竹智能体知识库/短视频带货/选品记录/"]);
    const latestImagegenData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/AI出图/提示词记录/"]);
    const latestImageResultData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/AI出图/出图记录/"]);
    const latestSelfMediaData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/IP内容生产/06-我的脚本工坊/", "山竹智能体知识库/IP内容生产/05-发布后数据复盘/", "山竹智能体知识库/IP内容生产/03-脚本模板与写作/"]);
    const latestCodingData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/AI编程/项目库/", "山竹智能体知识库/AI编程/"]);
    const latestNovelBestsellerData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/写小说/找爆款/"]);
    const latestNovelImitationData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/写小说/仿写爆款/", "山竹智能体知识库/写小说/找爆款/"]);
    const latestNovelProjectData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/写小说/作品项目/", "山竹智能体知识库/写小说/仿写爆款/", "山竹智能体知识库/写小说/找爆款/"]);
    const latestNovelSettingsData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/写小说/人物设定/", "山竹智能体知识库/写小说/世界观设定/", "山竹智能体知识库/写小说/作品项目/"]);
    const latestNovelOutlineData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/写小说/章节大纲/", "山竹智能体知识库/写小说/作品项目/"]);
    const latestNovelDraftData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/写小说/章节正文/", "山竹智能体知识库/写小说/作品项目/"]);
    const latestOfficeData = this.findLatestWorkflowSourcePath(["山竹智能体知识库/日常办公/项目库/", "山竹智能体知识库/日常办公/输出记录/", "山竹智能体知识库/日常办公/资料库/", "山竹智能体知识库/日常办公/工作流/", "山竹智能体知识库/日常办公/项目情况/", "山竹智能体知识库/日常办公/", "山竹智能体知识库/日常办公/Resources/"]);
    const novelNext = (sourcePath, actions) => ({ statusSourcePath: sourcePath || "", actions });
    const sourceFields = (defaultPath) => [
      { label: "资料来源", param: "资料来源", type: "select", options: sourceOptions, sourceSelect: true, sourceDefaultPath: defaultPath },
      { label: "上一环节 / 指定笔记路径", param: "上一环节或指定笔记路径", placeholder: defaultPath || "例：山竹智能体知识库/短视频带货/平台找品/最新结果.md", value: defaultPath || "", sourcePathField: true }
    ];
    const novelSourceFields = (defaultPath) => [
      { label: "沉淀内容来源", param: "沉淀内容来源", type: "select", options: sourceOptions, sourceSelect: true, sourceDefaultPath: defaultPath },
      { label: "上一环节 / 指定沉淀笔记路径", param: "上一环节或指定沉淀笔记路径", placeholder: defaultPath || "例：山竹智能体知识库/写小说/找爆款/最新报告.md", value: defaultPath || "", sourcePathField: true }
    ];
    const officeSourceFields = (defaultPath) => [
      { label: "资料来源", param: "资料来源", type: "select", options: officeSourceOptions, value: defaultPath ? "最近办公结果" : "导入新的文件", sourceSelect: true, sourceDefaultPath: defaultPath },
      { label: "材料路径 / 指定笔记", param: "材料路径或指定笔记", placeholder: defaultPath || "点右侧按钮选择文件/文件夹，或搜索笔记/目录", value: defaultPath || "", sourcePathField: true, filePicker: true, allowFolder: true, notePicker: true, requiredGroup: "office-source", pathKind: "local" }
    ];
    const codingSourceFields = (defaultPath) => [
      { label: "资料来源", param: "资料来源", type: "select", options: sourceOptions, sourceSelect: true, sourceDefaultPath: defaultPath },
      { label: "项目资料 / 指定笔记", param: "项目资料或指定笔记", placeholder: defaultPath || "例：山竹智能体知识库/AI编程/项目库/项目名/00-项目总控.md，或直接在下方粘贴需求/报错/方案", value: defaultPath || "", sourcePathField: true }
    ];
    const codingProjectFields = (defaultPath) => [
      ...(codingProjectTitle ? [{ label: "当前项目", param: "项目名", value: codingProjectTitle }] : []),
      ...(codingProjectPath ? [{ label: "项目路径", param: "项目路径", value: codingProjectPath }] : []),
      ...codingSourceFields(defaultPath)
    ];
    const latestImagegenPromptPath = latestImagegenData && !latestImagegenData.endsWith("/") ? latestImagegenData : "";
    const imagegenLatestTip = latestImagegenPromptPath
      ? `刚才 / 最近提示词位置：${latestImagegenPromptPath}`
      : "先点上面的生成按钮；生成后会保存到 AI出图/提示词记录，再点这里出图。";
    const imagegenDrawActions = (extra = []) => [
      { text: "一键出图（读取最新提示词）", openPath: "山竹智能体知识库/AI出图/70-一键出图.md", accent: true },
      { text: "图生图 / 改图", openPath: "山竹智能体知识库/AI出图/80-图生图.md", accent: true },
      ...(latestImagegenPromptPath ? [{ text: "查看最近提示词", openPath: latestImagegenPromptPath, secondary: true }] : []),
      ...extra,
      { text: "进入出图归档", openPath: "山竹智能体知识库/AI出图/60-出图归档与复盘.md", secondary: true }
    ];
    const functionPages = {
      "usage-qa": {
        compact: true,
        kicker: "使用帮助",
        title: "使用问题解答",
        desc: "把你现在卡住的问题写清楚，AI 会直接判断原因、给操作步骤；能直接处理的就直接处理。",
        sideTitle: "怎么用",
        sideText: "填写问题明细后点提交，会自动发给 AI 解决。",
        sections: [
        { title: "输入问题", note: "越具体越好，不懂怎么写就只填问题明细", runner: { name: "workbench-usage-qa", fields: [
            { label: "问题类型", param: "问题类型", type: "select", options: ["不知道怎么用", "功能找不到", "页面看不懂", "操作报错", "结果不对", "想完成一个任务", "安装/部署问题", "其他"] },
            { label: "所在功能 / 页面", param: "所在功能或页面", placeholder: "例：首页、短视频带货、AI出图、AI编程、写小说、日常办公" }
          ], wideFields: [
            { label: "问题明细", param: "问题明细", type: "textarea", placeholder: "用大白话写：你想做什么？点到哪里卡住了？页面显示了什么？希望 AI 帮你解决到什么程度？" },
            { label: "补充信息 / 截图说明 / 文件路径", param: "补充信息", type: "textarea", placeholder: "可选：截图里看到的文字、报错内容、相关笔记路径、电脑文件路径，或你已经尝试过的操作。" }
          ], actions: [{ text: "提交问题，让AI解决", workflow: "workbench-usage-qa", autosend: true, runButton: true }], tip: "会自动发送到山竹智能体处理；能直接修的会直接修。" } },
          { title: "下一步", actions: [
            { text: "返回首页", openPath: "00-山竹智能体.md", secondary: true },
            { text: "查看知识库边界", openPath: "山竹智能体知识库/00-边界说明.md", secondary: true }
          ]}
        ]
      },
      "ai-imagegen-home": {
        compact: true,
        kicker: "AI出图",
        title: "选用途 → 生成方案 → 出图 / 改图 → 归档复盘",
        desc: "入口只保留不重复的核心功能；每个具体功能页里先生成方案，再在第二步出图或图生图。",
        sideTitle: "模型提醒",
        sideText: "真实出图需要 GPT 图像模型 / 即梦 / 可灵 / 其他可用出图平台；未接入模型时，先输出提示词、参数和风格方案。",
        sections: [
          { title: "功能入口", note: "功能不重复：具体用途页负责生成方案，出图动作在页面第二步完成。", cards: [
            { step: "01", title: "人物图", desc: "固定人物长相、服装、动作习惯和系列图统一规则。", prep: "准备人物设定、参考图说明、必须保留和禁止变化。", button: "进入人物图", openPath: "山竹智能体知识库/AI出图/20-人物一致性.md", primary: true },
            { step: "02", title: "商品图", desc: "生成电商主图、卖点场景图、详情页 KV 和带货素材方案。", prep: "准备商品卖点、外观、目标人群和使用场景。", button: "进入商品图", openPath: "山竹智能体知识库/AI出图/30-商品图.md" },
            { step: "04", title: "封面图", desc: "小说、短剧、课程、直播和短视频封面视觉方案。", prep: "准备标题、题材情绪、主视觉、平台尺寸和留白要求。", button: "进入封面图", openPath: "山竹智能体知识库/AI出图/40-封面图.md", accent: true },
            { step: "05", title: "风格图", desc: "整理电商、写实、国风、短视频等可复用画面风格方案。", prep: "准备想要的风格、参考方向和禁用元素；也可以自定义。", button: "进入风格图", openPath: "山竹智能体知识库/AI出图/50-风格参考.md" },
            { step: "06", title: "出图归档", desc: "记录模型、提示词、成图、修改意见和可复用经验。", prep: "每次出图后把过程和结果沉淀回来。", button: "进入归档", openPath: "山竹智能体知识库/AI出图/60-出图归档与复盘.md" },
            { step: "", title: "图生图 / 改图", desc: "选择桌面图片，基于原图改信息、换场景、换风格，或参考原图出新图。", prep: "准备一张桌面图片，说明要保留什么、修改什么。", button: "进入图生图", openPath: "山竹智能体知识库/AI出图/80-图生图.md", accent: true }
          ]},
          { title: "2. 快速打开", actions: [
            { text: "提示词模板", openPath: "山竹智能体知识库/AI出图/01-出图提示词模板.md", secondary: true },
            { text: "归档索引", openPath: "山竹智能体知识库/AI出图/02-出图归档索引.md", secondary: true }
          ]}
        ]
      },      "ai-imagegen-prompt": {
        compact: true,
        kicker: "AI出图",
        title: "提示词生成",
        desc: "把图片需求拆成可复制到 GPT 图像模型、即梦、可灵或其他平台的提示词。",
        sideTitle: "输出重点",
        sideText: "正向提示词、负面词、尺寸比例、风格词、构图说明和参数建议。",
        sections: [
          { title: "输入信息", note: "填必要信息后启动", runner: { name: "ai-imagegen-prompt", fields: [
            { label: "图片用途", param: "图片用途", type: "select", options: ["封面图", "商品图", "人物设定图", "海报图", "漫画分镜", "短视频素材", "其他"] },
            { label: "目标平台 / 尺寸", param: "目标平台或尺寸", placeholder: "例：小红书3:4、抖音9:16、小说封面、16:9横图" },
            { label: "计划使用模型", param: "计划使用模型", type: "select", options: ["GPT图像模型", "即梦", "可灵", "其他平台", "暂未接入"] }
          ], wideFields: [
            { label: "画面需求", param: "画面需求", type: "textarea", placeholder: "主体、场景、动作、情绪、服装/道具、光线、构图、必须保留、禁止出现。" }
          ], actions: [{ text: "生成出图提示词", workflow: "ai-imagegen-prompt", autosend: true, runButton: true }], tip: "先生成提示词；生成后再到下面一键出图。" } },
          { title: "第二步：出图", note: imagegenLatestTip, actions: imagegenDrawActions([
            { text: "进入人物图", openPath: "山竹智能体知识库/AI出图/20-人物一致性.md", secondary: true }
          ])}
        ]
      },
      "ai-imagegen-character": {
        compact: true,
        kicker: "AI出图",
        title: "人物图",
        desc: "把人物视觉设定固定成可复用的人物图提示词和系列图规则。",
        sideTitle: "输出重点",
        sideText: "角色视觉设定卡、系列图提示词、参考图使用建议和变形规避。",
        sections: [
          { title: "输入信息", note: "填必要信息后启动", runner: { name: "ai-imagegen-character", fields: [
            { label: "角色名称 / 身份", param: "角色名称或身份", placeholder: "例：凶宅验收师沈砚 / 国风女主 / 品牌IP形象" },
            { label: "图片用途", param: "图片用途", type: "select", options: ["单张人设", "系列头像", "漫画分镜", "小说封面", "短视频角色素材", "其他"] },
            { label: "计划使用模型", param: "计划使用模型", type: "select", options: ["GPT图像模型", "即梦", "可灵", "其他平台", "暂未接入"] }
          ], wideFields: [
            { label: "角色设定 / 参考信息", param: "角色设定或参考信息", type: "textarea", placeholder: "年龄感、五官、发型、服装、气质、标志动作、必须保留、禁止变化、参考图说明。" }
          ], actions: [{ text: "生成人物一致性方案", workflow: "ai-imagegen-character", autosend: true, runButton: true }], tip: "先生成角色提示词；生成后再到下面一键出图。" } },
          { title: "第二步：出图", note: imagegenLatestTip, actions: imagegenDrawActions([
            { text: "进入封面图", openPath: "山竹智能体知识库/AI出图/40-封面图.md", secondary: true },
            { text: "进入风格图", openPath: "山竹智能体知识库/AI出图/50-风格参考.md", secondary: true }
          ])}
        ]
      },
      "ai-imagegen-product": {
        compact: true,
        kicker: "AI出图",
        title: "商品图",
        desc: "围绕商品卖点生成主图、场景图、详情页 KV 和带货素材提示词。",
        sideTitle: "输出重点",
        sideText: "商品图策略、多图拆分清单、单张提示词、负面词和真实性提醒。",
        sections: [
          { title: "输入信息", note: "填必要信息后启动", runner: { name: "ai-imagegen-product", fields: [
            { label: "商品名称", param: "商品名称", placeholder: "例：厨房收纳盒、护眼台灯、课程海报周边" },
            { label: "图片类型", param: "图片类型", type: "select", options: ["电商主图", "卖点场景图", "详情页KV", "带货素材图", "对比图/痛点图", "其他"] },
            { label: "计划使用模型", param: "计划使用模型", type: "select", options: ["GPT图像模型", "即梦", "可灵", "其他平台", "暂未接入"] }
          ], wideFields: [
            { label: "商品资料 / 卖点", param: "商品资料或卖点", type: "textarea", placeholder: "外观、材质、颜色、卖点、目标人群、使用场景、必须保留、不能夸大的效果。" }
          ], actions: [{ text: "生成商品图方案", workflow: "ai-imagegen-product", autosend: true, runButton: true }], tip: "先生成商品图提示词；生成后再到下面一键出图。" } },
          { title: "第二步：出图", note: imagegenLatestTip, actions: imagegenDrawActions([
            { text: "进入提示词生成", openPath: "山竹智能体知识库/AI出图/10-提示词生成.md", secondary: true }
          ])}
        ]
      },
      "ai-imagegen-cover": {
        compact: true,
        kicker: "AI出图",
        title: "封面图",
        desc: "生成小说、短剧、课程、直播和短视频封面的视觉方案。",
        sideTitle: "输出重点",
        sideText: "封面卖点、画面方案 A/B/C、标题排版建议、提示词和负面词。",
        sections: [
          { title: "输入信息", note: "填必要信息后启动", runner: { name: "ai-imagegen-cover", fields: [
            { label: "封面类型", param: "封面类型", type: "select", options: ["小说封面", "短剧封面", "课程封面", "短视频标题图", "直播封面", "其他"] },
            { label: "标题 / 主题", param: "标题或主题", placeholder: "例：凶宅验收师 / 7天学会AI出图 / 爆款短剧封面" },
            { label: "计划使用模型", param: "计划使用模型", type: "select", options: ["GPT图像模型", "即梦", "可灵", "其他平台", "暂未接入"] }
          ], wideFields: [
            { label: "封面需求", param: "封面需求", type: "textarea", placeholder: "题材、情绪、主视觉、人物/商品、背景元素、反差钩子、字体留白、平台尺寸。" }
          ], actions: [{ text: "生成封面图方案", workflow: "ai-imagegen-cover", autosend: true, runButton: true }], tip: "先生成封面提示词；生成后再到下面一键出图。" } },
          { title: "第二步：出图", note: imagegenLatestTip, actions: imagegenDrawActions([
            { text: "进入人物图", openPath: "山竹智能体知识库/AI出图/20-人物一致性.md", secondary: true },
            { text: "进入风格图", openPath: "山竹智能体知识库/AI出图/50-风格参考.md", secondary: true }
          ])}
        ]
      },
      "ai-imagegen-style": {
        compact: true,
        kicker: "AI出图",
        title: "风格图",
        desc: "把常用画面风格沉淀成可复用的风格图方案、风格词、禁用词和示例提示词。",
        sideTitle: "输出重点",
        sideText: "风格方向、适用场景、画面关键词、禁用词、示例提示词和复用注意。",
        sections: [
          { title: "输入信息", note: "填必要信息后启动", runner: { name: "ai-imagegen-style", fields: [
            { label: "风格方向", param: "风格方向", type: "select", options: ["电商高级感", "真实产品摄影", "直播间热卖感", "小红书种草感", "抖音信息流广告感", "极简白底产品图", "儿童清新可爱", "写实电影感", "欧美杂志感", "复古港风", "国风质感", "新中式高级感", "漫画分镜", "3D立体可爱", "科技蓝未来感", "赛博都市", "暗黑悬疑", "中式恐怖", "自定义"] },
            { label: "自定义风格", param: "自定义风格", placeholder: "选择“自定义”时填写；例：拼多多爆款主图感、母婴店清爽感、AI工具科技感、低价促销感" },
            { label: "适用用途", param: "适用用途", placeholder: "例：小说封面、商品主图、短视频素材、人物设定图" },
            { label: "计划使用模型", param: "计划使用模型", type: "select", options: ["GPT图像模型", "即梦", "可灵", "其他平台", "暂未接入"] }
          ], wideFields: [
            { label: "参考描述 / 禁用元素", param: "参考描述或禁用元素", type: "textarea", placeholder: "想要的画面气质、色彩、镜头、材质、参考方向，以及禁止出现的元素。" }
          ], actions: [{ text: "生成风格图方案", workflow: "ai-imagegen-style", autosend: true, runButton: true }], tip: "先生成风格提示词；生成后再到下面一键出图。" } },
          { title: "第二步：出图", note: imagegenLatestTip, actions: imagegenDrawActions([
            { text: "进入提示词生成", openPath: "山竹智能体知识库/AI出图/10-提示词生成.md", secondary: true }
          ])}
        ]
      },
      "ai-imagegen-generate": {
        compact: true,
        kicker: "AI出图",
        title: "第二步：一键出图",
        desc: "默认读取刚才生成并保存的提示词；也可以手动粘贴最终提示词，再调用当前可用出图模型生成图片。",
        sideTitle: "执行规则",
        sideText: "点击后不是只出提示词：能调用模型就直接生成图片，并保存到 zahuo/AI出图/ 后归档。",
        sections: [
          { title: "出图信息", note: imagegenLatestTip, runner: { name: "ai-imagegen-generate", fields: [
            ...sourceFields(latestImagegenData),
            { label: "出图模型", param: "出图模型", type: "select", options: ["自动选择可用模型", "GPT 图像模型", "即梦", "可灵", "其他可用平台"] },
            { label: "图片数量", param: "图片数量", type: "select", options: ["1", "2", "3", "4"] },
            { label: "尺寸 / 比例", param: "尺寸或比例", type: "select", options: ["自动匹配", "1:1", "3:4", "4:3", "9:16", "16:9"] }
          ], wideFields: [
            { label: "最终提示词 / 补充要求", param: "最终提示词或补充要求", type: "textarea", placeholder: "可留空：默认读取最近生成的提示词。也可以粘贴最终提示词、负面词、参考图、风格要求。" }
          ], actions: [{ text: "点击出图", workflow: "ai-imagegen-generate", autosend: true, runButton: true, accent: true }], tip: "有可用出图模型时必须直接生成图片；没有模型时才输出可复制提示词和接入提醒。" } },
          { title: "下一步", actions: [
            { text: "进入出图归档", openPath: "山竹智能体知识库/AI出图/60-出图归档与复盘.md", secondary: true },
            { text: "回到AI出图入口", openPath: "山竹智能体知识库/AI出图/00-入口.md", secondary: true }
          ] }
        ]
      },
      "ai-imagegen-image-to-image": {
        compact: true,
        kicker: "AI出图",
        title: "图生图 / 改图",
        desc: "选择桌面上的图片，基于原图改信息、换场景、换风格，或者参考原图出一张新图。",
        sideTitle: "使用方式",
        sideText: "先选图片，再说清楚：哪些必须保留，哪些要修改。改真实商品图时不要编造功效、认证或不存在的包装信息。",
        sections: [
          { title: "图片与修改要求", note: latestImageResultData ? `也可以参考最近成图记录：${latestImageResultData}` : "优先点“选择桌面图片”，也可以手动粘贴图片路径。", runner: { name: "ai-imagegen-image-to-image", fields: [
            { label: "原图路径", param: "原图路径", placeholder: "点击右侧按钮选择桌面图片，或粘贴图片路径", filePicker: true, allowFolder: false, fileButtonText: "选择桌面图片", desktopDefault: true, accept: "image" },
            { label: "处理方式", param: "处理方式", type: "select", options: ["基于原图改图", "参考原图出新图", "换背景/场景", "换风格", "改文字/卖点", "局部修改", "放大优化"] },
            { label: "计划使用模型", param: "计划使用模型", type: "select", options: ["自动选择可用模型", "GPT 图像模型", "即梦", "可灵", "其他可用平台"] },
            { label: "尺寸 / 比例", param: "尺寸或比例", type: "select", options: ["保持原图", "自动匹配", "1:1", "3:4", "4:3", "9:16", "16:9"] }
          ], wideFields: [
            { label: "修改要求", param: "修改要求", type: "textarea", placeholder: "用大白话写：保留什么？改什么？例如：保留瓶子和包装，把背景改成夏天户外草地；或者参考这张图重新出一张更高级的电商主图。" },
            { label: "禁止修改 / 风险提醒", param: "禁止修改或风险提醒", type: "textarea", placeholder: "例：不要改瓶身文字；不要夸大功效；不要生成儿童直接喷入口鼻眼睛；不要加虚假认证。" }
          ], actions: [{ text: "开始图生图", workflow: "ai-imagegen-image-to-image", autosend: true, runButton: true, accent: true }], tip: "会读取图片路径；能直接调用出图/改图模型时直接生成，并保存到 zahuo/AI出图/。" } },
          { title: "下一步", actions: [
            { text: "进入出图归档", openPath: "山竹智能体知识库/AI出图/60-出图归档与复盘.md", secondary: true },
            { text: "回到AI出图入口", openPath: "山竹智能体知识库/AI出图/00-入口.md", secondary: true }
          ] }
        ]
      },
      "ai-imagegen-archive": {
        compact: true,
        kicker: "AI出图",
        title: "出图归档与复盘",
        desc: "把每次出图的模型、提示词、成图、修改意见和可复用经验沉淀下来。",
        sideTitle: "输出重点",
        sideText: "归档记录、复盘结论、可复用提示词和下次优化方向。",
        sections: [
          { title: "输入信息", note: "填必要信息后启动", runner: { name: "ai-imagegen-archive", fields: [
            { label: "归档类型", param: "归档类型", type: "select", options: ["提示词记录", "成图复盘", "风格经验", "人物一致性记录", "商品图经验", "封面图经验"] },
            { label: "用途 / 项目", param: "用途或项目", placeholder: "例：凶宅验收师封面、厨房收纳商品图、小红书海报" },
            { label: "使用模型 / 平台", param: "使用模型或平台", type: "select", options: ["GPT图像模型", "即梦", "可灵", "其他平台", "暂未生成"] }
          ], wideFields: [
            { label: "提示词 / 成图反馈 / 修改意见", param: "提示词成图反馈或修改意见", type: "textarea", placeholder: "粘贴原始提示词、最终提示词、成图问题、修改意见、可复用经验。" }
          ], actions: [{ text: "整理出图归档", workflow: "ai-imagegen-archive", autosend: true, runButton: true }], tip: "沉淀越细，下次复用越快。" } },
          { title: "下一步", actions: [
            { text: "回到AI出图入口", openPath: "山竹智能体知识库/AI出图/00-入口.md", secondary: true },
            { text: "打开旧版归档索引", openPath: "山竹智能体知识库/AI出图/02-出图归档索引.md", secondary: true }
          ]}
        ]
      },      "ai-coding-home": {
        compact: true,
        kicker: "AI编程",
        title: "说需求 → 选形态 → 做第一版 → 试用修改",
        desc: "不会编程也能用：你只需要像产品经理一样说清楚需求，选择想做成 HTML 网页 / 小程序 / APP，AI 帮你拆功能、做第一版、根据试用反馈继续改。",
        sideTitle: "小白原则",
        sideText: "不要一开始追求完美。先做一个能用的版本，再像普通用户一样试用，把问题告诉 AI 继续改。",
        sections: [
          { title: "1. 我的项目", note: "每个项目都可以持续修改", aiCodingProjects: true },
          { title: "2. 小白做项目流程", note: "按顺序走：先说需求，再做第一版，再试用修改", cards: [
            { step: "01", title: "新建项目", desc: "说清楚你要做什么、给谁用、想做成 HTML 网页 / 小程序 / APP。", prep: "准备项目名、使用人群、需求形态、第一版要完成的事。", button: "开始新项目", openPath: "山竹智能体知识库/AI编程/01-新建项目.md", primary: true },
            { step: "02", title: "拆功能并生成第一版", desc: "AI 把需求拆成页面、按钮、操作流程，并生成第一个能试用的版本。", prep: "确认第一版只做最核心的 1-3 个功能。", button: "生成第一版", openPath: "山竹智能体知识库/AI编程/03-AI帮我拆功能.md", accent: true },
            { step: "03", title: "试用并修改", desc: "像普通用户一样点一遍，把不好用、看不懂、点不了的地方反馈给 AI 修改。", prep: "记录你点了哪里、期待什么、实际发生什么。", button: "试用修改", openPath: "山竹智能体知识库/AI编程/05-试用并反馈问题.md" }
          ]}
        ]
      },
      "ai-coding-project-create": this.getAICodingWorkflowConfig("新建项目", "ai-coding-project-create", "像产品经理一样说需求", "你不用写代码，也不用懂专业词。只要说清楚想做什么、给谁用、想做成什么形态。", [
        { label: "项目名", param: "项目名", placeholder: "例：视频素材管理工具 / 门店预约小程序 / 会员记录APP", required: true },
        { label: "需求形态", param: "需求形态", type: "select", options: ["HTML网页", "小程序", "APP", "后台管理页", "不确定，让AI建议"] },
        { label: "给谁用", param: "给谁用", placeholder: "例：自己用、员工用、客户用、门店会员用" },
        { label: "要解决的问题", param: "要解决的问题", type: "textarea", placeholder: "用大白话写：现在有什么麻烦？希望这个工具帮你完成什么？用户打开后要能做什么？" },
        { label: "第一版必须有", param: "第一版必须有", type: "textarea", placeholder: "只写最重要的 1-3 个功能。例：上传素材、按标签搜索、保存记录。" },
        { label: "参考对象 / 补充说明", param: "参考对象或补充说明", type: "textarea", placeholder: "可以写参考网站、参考小程序、现有表格、手工流程，或者不需要。" }
      ], [{ text: "提交需求，创建项目", workflow: "ai-coding-project-create", autosend: true, runButton: true }], [
        { text: "打开项目库", openPath: "山竹智能体知识库/AI编程/项目库/00-项目库索引.md", secondary: true }
      ]),
      "ai-coding-requirements": this.getAICodingWorkflowConfig("需求拆解", "ai-coding-requirements", "想法 → 可开发需求", "把模糊需求拆成用户故事、边界和验收标准。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/00-项目总控.md` : latestCodingData),
        { label: "项目 / 功能", param: "项目或功能", placeholder: "例：给素材库加搜索和标签" },
        { label: "需求描述", param: "需求描述", type: "textarea", placeholder: "写清用户是谁、要完成什么、现在卡在哪里、期望效果。" }
      ], [{ text: "拆解需求", workflow: "ai-coding-requirements", autosend: true, runButton: true }], [
        { text: "进入功能拆解", openPath: codingProjectPath ? `${codingProjectPath}/02-功能清单.md` : "山竹智能体知识库/AI编程/03-AI帮我拆功能.md", secondary: true }
      ]),
      "ai-coding-technical-design": this.getAICodingWorkflowConfig("拆功能并生成第一版", "ai-coding-technical-design", "需求 → 页面 → 功能 → 第一版", "AI 会把你的需求拆成页面、按钮、操作流程，并生成第一个能试用的版本。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/01-我的想法.md` : latestCodingData),
        { label: "项目 / 想法", param: "项目或想法", placeholder: "例：视频素材管理工具" },
        { label: "想做成什么", param: "想做成什么", type: "select", options: ["HTML网页", "小程序", "APP", "后台管理页", "不确定，让AI建议"] },
        { label: "第一版功能", param: "第一版功能", type: "textarea", placeholder: "第一版只做 1-3 个核心功能。写清用户打开后要看到什么、点什么、得到什么结果。" },
        { label: "补充要求", param: "补充要求", type: "textarea", placeholder: "有哪些参考、颜色风格、使用流程、不要做的内容，都可以写在这里。" }
      ], [{ text: "拆功能并生成第一版", workflow: "ai-coding-technical-design", autosend: true, runButton: true }], [
        { text: "进入做第一版", openPath: codingProjectPath ? `${codingProjectPath}/03-版本计划.md` : "山竹智能体知识库/AI编程/04-生成第一个版本.md", secondary: true }
      ]),
      "ai-coding-task-board": this.getAICodingWorkflowConfig("第一版计划", "ai-coding-task-board", "功能 → 第一版 → 可试用", "把功能拆成用户能看懂的小步骤，明确第一版先做什么。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/02-功能清单.md` : latestCodingData),
        { label: "项目 / 页面", param: "项目或页面", placeholder: "例：视频素材管理工具第一版" },
        { label: "第一版计划", param: "第一版计划", type: "textarea", placeholder: "写清第一版要做哪几个页面、哪些按钮、用户点完看到什么。" }
      ], [{ text: "生成第一版计划", workflow: "ai-coding-task-board", autosend: true, runButton: true }], [
        { text: "开始生成第一版", openPath: codingProjectPath ? `${codingProjectPath}/03-版本计划.md` : "山竹智能体知识库/AI编程/04-生成第一个版本.md", secondary: true }
      ]),
      "ai-coding-first-version": this.getAICodingWorkflowConfig("生成第一版", "ai-coding-first-version", "功能清单 → 可试用版本", "基于当前项目需求和功能清单，生成一个能打开、能点击、能跑通主流程的第一版。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/02-功能清单.md` : latestCodingData),
        { label: "第一版目标", param: "第一版目标", placeholder: "例：先做单文件 HTML 版，打开就能玩" },
        { label: "产物形式", param: "产物形式", type: "select", options: ["单文件 HTML", "HTML/CSS/JS 三文件", "React/Vite 项目", "小程序页面", "让AI建议"] },
        { label: "必须跑通", param: "必须跑通", type: "textarea", placeholder: "写清第一版打开后必须能完成的主流程。例：开始游戏、移动、射击、敌人、胜负反馈。" },
        { label: "暂时不做", param: "暂时不做", type: "textarea", placeholder: "例：不做联机、不做排行榜、不做地图编辑器。" }
      ], [{ text: "生成可试用第一版", workflow: "ai-coding-first-version", autosend: true, runButton: true }], [
        { text: "进入试用修改", openPath: codingProjectPath ? `${codingProjectPath}/04-试用反馈.md` : "山竹智能体知识库/AI编程/05-试用并反馈问题.md", secondary: true }
      ]),
      "ai-coding-development": this.getAICodingWorkflowConfig("试用并修改", "ai-coding-development", "试用反馈 → 修改版本", "你负责像用户一样试用，AI 负责根据反馈修改。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/03-版本计划.md` : latestCodingData),
        { label: "项目 / 页面", param: "项目或页面", placeholder: "例：视频素材管理工具第一版" },
        { label: "试用反馈", param: "试用反馈", type: "textarea", placeholder: "写清：我点了哪里、期待发生什么、实际发生什么、哪里看不懂、想改成什么。" },
        { label: "修改重点", param: "修改重点", type: "select", options: ["页面看不懂", "按钮点不了", "流程不顺", "结果不对", "想加小功能", "报错了"] }
      ], [{ text: "让 AI 修改", workflow: "ai-coding-development", autosend: true, runButton: true }], [
        { text: "继续试用修改", openPath: codingProjectPath ? `${codingProjectPath}/04-试用反馈.md` : "山竹智能体知识库/AI编程/06-修改和优化.md", secondary: true },
        { text: "添加新功能", openPath: codingProjectPath ? `${codingProjectPath}/05-修改记录.md` : "山竹智能体知识库/AI编程/07-添加新功能.md", secondary: true }
      ]),
      "ai-coding-debug-test": this.getAICodingWorkflowConfig("继续修改", "ai-coding-debug-test", "问题反馈 → 修改 → 再试用", "把试用时发现的问题说清楚，让 AI 继续改到顺手。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/04-试用反馈.md` : latestCodingData),
        { label: "项目 / 页面", param: "项目或页面", placeholder: "例：视频素材管理工具第一版" },
        { label: "发现的问题", param: "发现的问题", type: "textarea", placeholder: "写清：哪里不好用、哪里点不了、哪里看不懂、希望改成什么。" }
      ], [{ text: "继续修改", workflow: "ai-coding-debug-test", autosend: true, runButton: true }], [
        { text: "回到试用修改", openPath: codingProjectPath ? `${codingProjectPath}/04-试用反馈.md` : "山竹智能体知识库/AI编程/05-试用并反馈问题.md", secondary: true }
      ]),
      "ai-coding-feature-add": this.getAICodingWorkflowConfig("添加新功能", "ai-coding-feature-add", "可用版本 → 安全加功能", "在已有版本能用的基础上，说明想加什么、加在哪里，AI 评估影响后再改。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/03-版本计划.md` : latestCodingData),
        { label: "想加的功能", param: "想加的功能", type: "textarea", placeholder: "例：增加双人模式、增加关卡选择、增加暂停按钮。" },
        { label: "加在哪里", param: "加在哪里", placeholder: "例：首页、游戏画面、设置弹窗、结算页" },
        { label: "不能影响", param: "不能影响", type: "textarea", placeholder: "例：不能影响已有移动射击、不能破坏当前关卡逻辑。" }
      ], [{ text: "安全添加功能", workflow: "ai-coding-feature-add", autosend: true, runButton: true }], [
        { text: "进入交付复盘", openPath: codingProjectPath ? `${codingProjectPath}/06-发布交付.md` : "山竹智能体知识库/AI编程/08-打包发布交付.md", secondary: true }
      ]),
      "ai-coding-deploy": this.getAICodingWorkflowConfig("发布部署", "ai-coding-deploy", "发布检查和部署记录", "整理发布步骤、验证清单和回滚方案。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/03-版本计划.md` : latestCodingData),
        { label: "项目 / 环境", param: "项目或环境", placeholder: "例：本地 Obsidian 插件 / Vercel / Docker / Windows 桌面" },
        { label: "发布内容", param: "发布内容", type: "textarea", placeholder: "本次发布改了什么、版本号、部署命令、风险点。" }
      ], [{ text: "生成发布部署清单", workflow: "ai-coding-deploy", autosend: true, runButton: true }], [
        { text: "进入迭代复盘", openPath: codingProjectPath ? `${codingProjectPath}/07-下轮计划.md` : "山竹智能体知识库/AI编程/08-打包发布交付.md", secondary: true }
      ]),
      "ai-coding-retrospective": this.getAICodingWorkflowConfig("迭代复盘", "ai-coding-retrospective", "开发记录 → 下一轮计划", "复盘本轮开发质量、技术债和下一轮优先级。", [
        ...codingProjectFields(codingProjectPath ? `${codingProjectPath}/06-发布交付.md` : latestCodingData),
        { label: "本轮记录", param: "本轮记录", type: "textarea", placeholder: "粘贴任务完成情况、Bug、测试结果、用户反馈、技术债。" }
      ], [{ text: "生成迭代复盘", workflow: "ai-coding-retrospective", autosend: true, runButton: true }], [
        { text: "回到 AI编程入口", openPath: "山竹智能体知识库/AI编程/00-入口.md", secondary: true }
      ]),
      "ai-coding-project-workbench": {
        compact: true,
        kicker: "AI编程项目",
        title: (context.project_name || context.project || "项目") + " · 项目总控",
        desc: "围绕当前项目持续说需求、拆功能、做版本、试用修改、交付复盘。",
        sideTitle: "当前项目",
        sideText: context.project_name || context.project || "未选择项目",
        sections: [{ title: "项目操作", note: "所有操作都围绕当前项目需求和试用反馈", cards: [
          { step: "01", title: "需求说明", desc: "说明谁用、做什么、解决什么问题。", prep: "先读项目总控和已有需求。", button: "看需求", openPath: (context.project_path || "山竹智能体知识库/AI编程/项目库") + "/01-我的想法.md", primary: true },
          { step: "02", title: "功能拆解", desc: "拆页面、按钮、填写内容和操作流程。", prep: "基于当前需求，不重新开项目。", button: "拆功能", openPath: (context.project_path || "山竹智能体知识库/AI编程/项目库") + "/02-功能清单.md" },
          { step: "03", title: "第一版", desc: "先做能打开、能点击、能跑通的版本。", prep: "每次只推进一个可试用版本。", button: "做第一版", openPath: (context.project_path || "山竹智能体知识库/AI编程/项目库") + "/03-版本计划.md", accent: true },
          { step: "04", title: "试用修改", desc: "根据看不懂、点不了、不顺手继续改。", prep: "准备试用反馈。", button: "试用修改", openPath: (context.project_path || "山竹智能体知识库/AI编程/项目库") + "/04-试用反馈.md" },
          { step: "05", title: "添加功能", desc: "在能用的基础上继续加新功能。", prep: "说清想加什么、加在哪里。", button: "加功能", openPath: (context.project_path || "山竹智能体知识库/AI编程/项目库") + "/05-修改记录.md" },
          { step: "06", title: "交付复盘", desc: "整理使用说明、版本记录和下一步计划。", prep: "确认是自己用、团队用还是给用户用。", button: "交付复盘", openPath: (context.project_path || "山竹智能体知识库/AI编程/项目库") + "/06-发布交付.md" }
        ]}]
      },
      "skill-market": {
        compact: true,
        kicker: "Skill 市场",
        title: "搜索、查看、安装 Skill",
        desc: "输入关键词，选择 Claude 或 Codex 后一键安装；默认安装到当前 Claude 仓库。",
        sections: [
          { title: "搜索 / 安装", note: "默认 Claude，也可以切换为 Codex", skillMarket: { installTarget: "claude" } }
        ]
      },      "office-home": {
        compact: true,
        kicker: "日常办公",
        title: "常用办公 → 项目知识库 → 资料处理 → 交付结果",
        desc: "先创建/选择项目知识库，再把办公资料变成表格、PPT、文档、待办和项目沉淀。",
        sideTitle: "办公工作区",
        sideText: "每个项目单独建库；常用办公动作放在最前面。表格、PPT、报表做好后自动放到桌面，并同步归档。",
        sections: [
          { title: "常用办公功能", note: "先把最常用的导入、整理、出表格、出PPT放前面。", cards: [
            { step: "01", title: "导入工作文件", desc: "选择电脑文件/文件夹，转成知识库资料。", button: "导入文件", openPath: "山竹智能体知识库/日常办公/工作流/01-导入工作文件.md", primary: true },
            { step: "02", title: "整理工作文件", desc: "分类、摘要、重组为工作文档。", button: "整理文件", openPath: "山竹智能体知识库/日常办公/工作流/02-整理工作文件.md" },
            { step: "03", title: "出表格 / 报表", desc: "提取字段，生成表格和汇总。", button: "生成表格", openPath: "山竹智能体知识库/日常办公/工作流/03-出表格报表.md" },
            { step: "04", title: "出PPT", desc: "生成汇报大纲、逐页内容或PPTX。", button: "开始做PPT", openPath: "山竹智能体知识库/日常办公/工作流/04-出PPT.md", accent: true },
            { step: "05", title: "提取待办", desc: "从资料里拆负责人、截止时间、下一步。", button: "提取待办", openPath: "山竹智能体知识库/日常办公/工作流/05-提取待办.md" },
            { step: "06", title: "项目情况汇总", desc: "扫描项目资料和输出记录，给当前状态。", button: "汇总项目", openPath: "山竹智能体知识库/日常办公/工作流/06-项目情况汇总.md" }
          ]},
          { title: "项目知识库", note: "用户有不同项目，先给每个项目搭一个独立知识库。", officeProjectPlaceholders: true, cards: [
            { step: "", title: "创建项目知识库", desc: "新建项目目录、资料索引、待办、输出记录和汇报区。", button: "创建项目库", openPath: "山竹智能体知识库/日常办公/工作流/00-创建项目知识库.md", primary: true },
            { step: "", title: "项目库索引", desc: "查看所有办公项目和对应资料。", button: "打开项目库", openPath: "山竹智能体知识库/日常办公/项目库/00-项目库索引.md" },
            { step: "", title: "办公资料库", desc: "通用资料、导入摘要和跨项目素材。", button: "打开资料库", openPath: "山竹智能体知识库/日常办公/资料库/00-资料库索引.md" },
            { step: "", title: "项目情况", desc: "当前项目状态、资料覆盖、风险。", button: "查看项目", openPath: "山竹智能体知识库/日常办公/01-项目情况.md" },
            { step: "", title: "待办清单", desc: "从资料里提取待办和负责人。", button: "打开待办", openPath: "山竹智能体知识库/日常办公/02-待办清单.md" },
            { step: "", title: "输出记录", desc: "表格、PPT、文档结果归档。", button: "看输出", openPath: "山竹智能体知识库/日常办公/输出记录/00-输出记录索引.md" }
          ]},
          { title: "选择资料和要做的事情", note: "选项目资料或导入新文件，点按钮直接跑。", runner: { name: "office-workflow-router", fields: [
            { label: "资料来源", param: "资料来源", type: "select", options: officeSourceOptions, value: latestOfficeData ? "最近办公结果" : "导入新的文件", sourceSelect: true, sourceDefaultPath: latestOfficeData },
            { label: "资料路径 / 文件夹", param: "资料路径或文件夹", placeholder: latestOfficeData || "点右侧按钮选择文件/文件夹，或搜索笔记/目录", value: latestOfficeData || "", sourcePathField: true, filePicker: true, allowFolder: true, notePicker: true, requiredGroup: "office-source", pathKind: "local" },
            { label: "要做的事情", param: "要做的事情", type: "select", options: ["整理成工作文件", "生成表格/报表", "生成PPT大纲", "生成可制作PPT", "提取待办事项", "项目情况汇总", "会议纪要/通知/SOP"] },
            { label: "输出格式", param: "输出格式", type: "select", options: ["自动判断", "Markdown文档", "Excel/CSV表格", "PPT大纲", "PPTX文件", "Word文档"] },
            { label: "结果给谁看", param: "结果给谁看", type: "select", options: ["自己", "老板", "团队", "客户"] }
          ], wideFields: [
            { label: "补充要求 / 直接粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "写清楚要做什么；也可以直接粘贴会议记录、表格摘要、文档内容。", requiredGroup: "office-source" }
          ], actions: [{ text: "开始处理办公资料", workflow: "office-workflow-router", autosend: true, runButton: true }], tip: "按资料和任务直接执行；表格/PPT/报表完成后自动放到桌面，并同步归档。" } },
          { title: "快速打开", actions: [
            { text: "创建项目库", openPath: "山竹智能体知识库/日常办公/工作流/00-创建项目知识库.md", secondary: true },
            { text: "项目库索引", openPath: "山竹智能体知识库/日常办公/项目库/00-项目库索引.md", secondary: true },
            { text: "资料库", openPath: "山竹智能体知识库/日常办公/资料库/00-资料库索引.md", secondary: true },
            { text: "输出记录", openPath: "山竹智能体知识库/日常办公/输出记录/00-输出记录索引.md", secondary: true },
            { text: "待办清单", openPath: "山竹智能体知识库/日常办公/02-待办清单.md", secondary: true },
            { text: "项目规则", openPath: "山竹智能体知识库/日常办公/projectMAP.md", secondary: true }
          ]}
        ]
      },
      "office-project-create": this.getOfficeWorkflowConfig("创建项目知识库", "office-project-create", "为一个新项目创建独立资料库、待办、输出记录和汇报区。", [
        { label: "项目名称", param: "项目名称", placeholder: "例：AI办公课、某客户提案、7月运营复盘", required: true },
        { label: "项目类型", param: "项目类型", type: "select", options: ["运营项目", "客户项目", "课程/PPT项目", "电商项目", "内部管理", "其他"] },
        { label: "项目目标", param: "项目目标", placeholder: "例：做一套汇报PPT / 整理客户资料 / 建立运营复盘库" },
        { label: "初始资料", param: "初始资料", placeholder: "可选：选择文件/文件夹或填写已有笔记路径", filePicker: true, allowFolder: true, notePicker: true },
        { label: "负责人 / 成员", param: "负责人或成员", placeholder: "例：森；运营、设计、投放" },
        { label: "补充要求", param: "补充要求", type: "textarea", placeholder: "说明项目背景、交付物、文件命名习惯、是否需要导入初始资料。" }
      ], [{ text: "创建项目知识库", workflow: "office-project-create", autosend: true, runButton: true }], [
        { text: "打开项目库索引", openPath: "山竹智能体知识库/日常办公/项目库/00-项目库索引.md", secondary: true }
      ]),
      "office-workflow-router": this.getOfficeWorkflowConfig("办公资料处理", "office-workflow-router", "选择资料和任务，自动判断该出文档、表格、PPT还是待办。", [
        ...officeSourceFields(latestOfficeData),
        { label: "要做的事情", param: "要做的事情", type: "select", options: ["整理成工作文件", "生成表格/报表", "生成PPT大纲", "生成可制作PPT", "提取待办事项", "项目情况汇总", "会议纪要/通知/SOP"] },
        { label: "输出格式", param: "输出格式", type: "select", options: ["自动判断", "Markdown文档", "Excel/CSV表格", "PPT大纲", "PPTX文件", "Word文档"] },
        { label: "结果给谁看", param: "结果给谁看", type: "select", options: ["自己", "老板", "团队", "客户"] },
        { label: "补充要求 / 粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "写清楚最终要交付什么；也可以直接粘贴资料。", requiredGroup: "office-source" }
      ], [{ text: "开始处理", workflow: "office-workflow-router", autosend: true, runButton: true }], [
        { text: "打开资料库", openPath: "山竹智能体知识库/日常办公/资料库/00-资料库索引.md", secondary: true },
        { text: "打开输出记录", openPath: "山竹智能体知识库/日常办公/输出记录/00-输出记录索引.md", secondary: true }
      ]),
      "office-file-import": this.getOfficeWorkflowConfig("导入工作文件", "office-file-import", "读取文件、文件夹或粘贴材料，建立资料索引和摘要。", [
        { label: "文件/文件夹路径", param: "文件或文件夹路径", placeholder: "点右侧按钮选择文件或文件夹", filePicker: true, allowFolder: true, required: true, pathKind: "local" },
        { label: "资料类型", param: "资料类型", type: "select", options: ["自动判断", "会议资料", "表格数据", "项目资料", "客户资料", "SOP/制度", "PPT/汇报"] },
        { label: "导入目标", param: "导入目标", type: "select", options: ["资料库", "项目情况", "输出记录", "待办清单"] },
        { label: "补充说明", param: "补充说明", type: "textarea", placeholder: "说明这些资料属于哪个项目、要按什么口径整理。" }
      ], [{ text: "开始导入", workflow: "office-file-import", autosend: true, runButton: true }], [
        { text: "资料库索引", openPath: "山竹智能体知识库/日常办公/资料库/00-资料库索引.md", secondary: true }
      ]),
      "office-file-organize": this.getOfficeWorkflowConfig("整理工作文件", "office-file-organize", "把散乱资料整理成清晰工作文档、目录和摘要。", [
        ...officeSourceFields(latestOfficeData),
        { label: "整理方式", param: "整理方式", type: "select", options: ["按项目分类", "按时间线整理", "按主题/模块整理", "整理成SOP", "整理成汇报材料"] },
        { label: "输出深度", param: "输出深度", type: "select", options: ["只要目录和摘要", "要完整工作文档", "要老板版总结", "要可执行SOP"] },
        { label: "补充要求 / 粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "粘贴或说明需要整理的资料。" }
      ], [{ text: "开始整理", workflow: "office-file-organize", autosend: true, runButton: true }], [
        { text: "打开输出记录", openPath: "山竹智能体知识库/日常办公/输出记录/00-输出记录索引.md", secondary: true }
      ]),
      "office-table-report": this.getOfficeWorkflowConfig("出表格 / 报表", "office-table-report", "从资料中抽字段、做汇总，输出表格和报表。", [
        ...officeSourceFields(latestOfficeData),
        { label: "表格目标", param: "表格目标", type: "select", options: ["数据清单", "汇总报表", "问题分类表", "行动项表", "对比分析表", "老板看板"] },
        { label: "需要字段", param: "需要字段", placeholder: "例：日期、项目、负责人、金额、状态、问题、下一步" },
        { label: "补充要求 / 粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "粘贴原始资料或说明统计口径。" }
      ], [{ text: "生成表格", workflow: "office-table-report", autosend: true, runButton: true }], [
        { text: "打开表格输出", openPath: "山竹智能体知识库/日常办公/输出记录/00-输出记录索引.md", secondary: true }
      ]),
      "office-ppt-builder": this.getOfficeWorkflowConfig("出PPT", "office-ppt-builder", "MarkItDown读资料 → AI生成大纲/页面JSON → 套模板或美化生成PPTX。", [
        ...officeSourceFields(latestOfficeData),
        { label: "PPT用途", param: "PPT用途", type: "select", options: ["老板汇报", "产品方案", "课程课件", "直播成交", "客户提案", "项目复盘", "培训课件", "商业计划"] },
        { label: "PPT风格", param: "PPT风格", type: "select", options: ["黑金高级", "极简商务", "科技发布会", "咨询公司风", "课程课件风", "直播成交风", "清新品牌风"] },
        { label: "生成方式", param: "生成方式", type: "select", options: ["先出PPT大纲", "生成美化PPTX", "套用我的模板PPT", "先出页面JSON", "只优化现有PPT"] },
        { label: "美化等级", param: "美化等级", type: "select", options: ["精美版", "快速版", "发布会级", "老板汇报稳重版"] },
        { label: "页数", param: "页数", placeholder: "例：8页 / 15页 / 自动判断" },
        { label: "模板PPT路径", param: "模板PPT路径", placeholder: "可选：选择一个 .pptx 模板，留空则自动设计", filePicker: true, allowFolder: false },
        { label: "品牌色 / Logo / 字体", param: "品牌色Logo字体", placeholder: "可选：例：黑金、紫金、公司Logo路径、微软雅黑" },
        { label: "补充要求 / 粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "粘贴资料、目标听众、风格要求和必须出现的内容。" }
      ], [{ text: "开始做PPT", workflow: "office-ppt-builder", autosend: true, runButton: true }], [
        { text: "打开PPT输出", openPath: "山竹智能体知识库/日常办公/输出记录/00-输出记录索引.md", secondary: true },
        { text: "PPT美化引擎说明", openPath: "山竹智能体知识库/日常办公/模板库/PPT美化引擎.md", secondary: true }
      ]),
      "office-todo-extractor": this.getOfficeWorkflowConfig("提取待办事项", "office-todo-extractor", "从会议、聊天、文档里提取行动项并更新待办清单。", [
        ...officeSourceFields(latestOfficeData),
        { label: "待办口径", param: "待办口径", type: "select", options: ["全部行动项", "只要我负责的", "只要高优先级", "按项目拆分"] },
        { label: "默认负责人/截止时间", param: "默认负责人或截止时间", placeholder: "读不到时使用；例：负责人森，截止本周五" },
        { label: "补充要求 / 粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "粘贴会议记录、聊天记录或工作安排。" }
      ], [{ text: "提取待办", workflow: "office-todo-extractor", autosend: true, runButton: true }], [
        { text: "打开待办清单", openPath: "山竹智能体知识库/日常办公/02-待办清单.md", secondary: true }
      ]),
      "office-project-status": this.getOfficeWorkflowConfig("项目情况汇总", "office-project-status", "扫描办公资料库、输出记录和待办，汇总当前项目状态。", [
        { label: "项目范围", param: "项目范围", placeholder: "例：全部日常办公资料 / 某个项目名 / 某个文件夹" },
        { label: "汇总口径", param: "汇总口径", type: "select", options: ["项目总览", "老板汇报版", "风险和卡点", "本周进展", "资料库健康检查"] },
        { label: "结果给谁看", param: "结果给谁看", type: "select", options: ["自己", "老板", "团队", "客户"] },
        { label: "补充要求", param: "补充要求", type: "textarea", placeholder: "说明重点关注哪个项目、哪些文件、哪些问题。" }
      ], [{ text: "汇总项目情况", workflow: "office-project-status", autosend: true, runButton: true }], [
        { text: "打开项目情况", openPath: "山竹智能体知识库/日常办公/01-项目情况.md", secondary: true }
      ]),
      "self-media-home": {
        compact: true,
        kicker: "自媒体",
        title: "选题 → 类型 → 脚本 → 钩子 → 复盘 → 沉淀",
        desc: "把《创作系统》的学习区和工作区拆成一条可执行的自媒体内容生产链路。",
        sideTitle: "执行原则",
        sideText: "先用方法判断，再用模板产出；每次发布后都要回收数据，沉淀成自己的脚本资产。",
        sections: [{
          title: "自媒体执行流程",
          note: "按顺序跑一遍，也可以从卡住的环节直接进入",
          cards: [
            { step: "01", title: "学习爆款方法", desc: "拆选题、标题、文案的底层规律。", prep: "准备账号定位、赛道、参考爆款或竞品账号。", button: "进入学习", openPath: "山竹智能体知识库/IP内容生产/01-学习爆款方法.md", primary: true },
            { step: "02", title: "选择内容类型", desc: "判断这条适合教知识、聊观点、讲故事还是晒过程。", prep: "准备主题、受众、平台和想达到的结果。", button: "进入判断", openPath: "山竹智能体知识库/IP内容生产/02-选择内容类型.md" },
            { step: "03", title: "脚本模板与写作", desc: "按钩子、痛点、方法、收束写成完整口播脚本。", prep: "准备主题、目标用户、内容类型、案例素材。", button: "进入写作", openPath: "山竹智能体知识库/IP内容生产/03-脚本模板与写作.md", accent: true },
            { step: "04", title: "三秒钩子优化", desc: "生成并筛选前 3 秒开头，降低划走率。", prep: "准备初稿、标题候选、目标平台。", button: "优化钩子", openPath: "山竹智能体知识库/IP内容生产/04-三秒钩子优化.md" },
            { step: "05", title: "发布后数据复盘", desc: "按点击、完播、互动、转化拆问题。", prep: "准备播放、完播、点赞、评论、收藏、转化数据。", button: "进入复盘", openPath: "山竹智能体知识库/IP内容生产/05-发布后数据复盘.md" },
            { step: "06", title: "我的脚本工坊", desc: "保存脚本、拆解和经验卡，形成自己的内容资产。", prep: "准备已写脚本、爆款拆解或复盘结论。", button: "进入工坊", openPath: "山竹智能体知识库/IP内容生产/06-我的脚本工坊.md" }
          ]
        }]
      },
      "self-media-bestseller-learning": this.getSelfMediaWorkflowConfig("学习爆款方法", "self-media-bestseller-learning", "拆选题、标题、文案和爆款共性", "先从赛道和样本里抽规律，再决定什么值得写。", [
        { label: "平台 / 赛道", param: "平台或赛道", placeholder: "例：抖音职场、小红书知识付费、视频号私域" },
        { label: "账号定位", param: "账号定位", placeholder: "例：AI工具教学、宝妈副业、剪辑教程" },
        { label: "目标用户", param: "目标用户", placeholder: "例：想做自媒体但不会写脚本的新手" },
        { label: "参考样本 / 爆款文案", param: "参考样本或爆款文案", type: "textarea", placeholder: "可粘贴链接、标题、正文、数据或竞品账号。" }
      ], [{ text: "拆解爆款方法", workflow: "self-media-bestseller-learning", autosend: true, runButton: true }], [
        { text: "进入选择内容类型", openPath: "山竹智能体知识库/IP内容生产/02-选择内容类型.md", secondary: true }
      ]),
      "self-media-content-type": this.getSelfMediaWorkflowConfig("选择内容类型", "self-media-content-type", "把主题匹配到最合适的文案结构", "先判断内容类型，再选模板，避免脚本写散。", [
        ...sourceFields(latestSelfMediaData),
        { label: "主题 / 选题", param: "主题或选题", placeholder: "例：为什么新手做自媒体要先写口播" },
        { label: "目标用户", param: "目标用户", placeholder: "例：0基础自媒体新手" },
        { label: "业务目标", param: "业务目标", type: "select", options: ["涨粉", "引流", "成交", "建立专业感", "测试选题"] },
        { label: "补充素材", param: "补充素材", type: "textarea", placeholder: "可粘贴案例、观点、产品、用户痛点。" }
      ], [{ text: "判断内容类型", workflow: "self-media-content-type", autosend: true, runButton: true }], [
        { text: "进入脚本模板与写作", openPath: "山竹智能体知识库/IP内容生产/03-脚本模板与写作.md", secondary: true }
      ]),
      "self-media-script-writing": this.getSelfMediaWorkflowConfig("脚本模板与写作", "self-media-script-writing", "按结构产出完整口播脚本", "把主题写成钩子、痛点、方法、收束完整脚本。", [
        ...sourceFields(latestSelfMediaData),
        { label: "内容类型", param: "内容类型", type: "select", options: ["教知识", "聊观点", "讲故事", "晒过程", "不确定，先判断"] },
        { label: "视频时长", param: "视频时长", placeholder: "例：30秒 / 60秒 / 90秒" },
        { label: "语气风格", param: "语气风格", placeholder: "例：直接、温柔、犀利、松弛、反差" },
        { label: "主题和素材", param: "主题和素材", type: "textarea", placeholder: "粘贴选题、用户痛点、案例、想表达的观点。" }
      ], [{ text: "生成自媒体脚本", workflow: "self-media-script-writing", autosend: true, runButton: true }], [
        { text: "优化三秒钩子", openPath: "山竹智能体知识库/IP内容生产/04-三秒钩子优化.md", secondary: true },
        { text: "进入脚本工坊", openPath: "山竹智能体知识库/IP内容生产/06-我的脚本工坊.md", secondary: true }
      ]),
      "self-media-hook-optimizer": this.getSelfMediaWorkflowConfig("三秒钩子优化", "self-media-hook-optimizer", "生成多版前 3 秒开头并筛选", "用结果、反差、痛点、身份信号和悬念重写开头。", [
        ...sourceFields(latestSelfMediaData),
        { label: "目标平台", param: "目标平台", type: "select", options: ["抖音", "小红书", "视频号", "B站", "公众号", "通用"] },
        { label: "钩子方向", param: "钩子方向", type: "select", options: ["结果型", "反差型", "痛点型", "身份信号型", "悬念型", "每种都给"] },
        { label: "原脚本 / 主题", param: "原脚本或主题", type: "textarea", placeholder: "粘贴原开头或完整脚本；也可以只写主题和目标用户。" }
      ], [{ text: "优化前3秒钩子", workflow: "self-media-hook-optimizer", autosend: true, runButton: true }], [
        { text: "回到脚本写作", openPath: "山竹智能体知识库/IP内容生产/03-脚本模板与写作.md", secondary: true },
        { text: "进入发布后复盘", openPath: "山竹智能体知识库/IP内容生产/05-发布后数据复盘.md", secondary: true }
      ]),
      "self-media-data-review": this.getSelfMediaWorkflowConfig("发布后数据复盘", "self-media-data-review", "从数据反推下一条怎么改", "按点击、前 3 秒、完播、互动、转化定位问题。", [
        ...sourceFields(latestSelfMediaData),
        { label: "平台", param: "平台", type: "select", options: ["抖音", "小红书", "视频号", "B站", "公众号", "其他"] },
        { label: "核心数据", param: "核心数据", type: "textarea", placeholder: "播放/曝光、点击率、3秒留存、完播率、点赞、评论、收藏、转发、关注、私信、成交。" },
        { label: "原脚本 / 标题", param: "原脚本或标题", type: "textarea", placeholder: "粘贴标题、封面文案、脚本或视频链接说明。" }
      ], [{ text: "开始数据复盘", workflow: "self-media-data-review", autosend: true, runButton: true }], [
        { text: "沉淀到脚本工坊", openPath: "山竹智能体知识库/IP内容生产/06-我的脚本工坊.md", secondary: true }
      ]),
      "self-media-script-workshop": this.getSelfMediaWorkflowConfig("我的脚本工坊", "self-media-script-workshop", "沉淀脚本、拆解和经验卡", "把有效脚本和复盘结论归档成可复用内容资产。", [
        { label: "归档类型", param: "归档类型", type: "select", options: ["新脚本", "爆款拆解", "经验卡", "复盘结论", "选题库"] },
        { label: "标题 / 主题", param: "标题或主题", placeholder: "例：新手做自媒体先写口播" },
        { label: "内容素材", param: "内容素材", type: "textarea", placeholder: "粘贴脚本、拆解、复盘结论或经验规律。" }
      ], [{ text: "整理并归档到工坊", workflow: "self-media-script-workshop", autosend: true, runButton: true }], [
        { text: "回到自媒体入口", openPath: "山竹智能体知识库/IP内容生产/00-入口.md", secondary: true }
      ]),
      "short-video-home": {
        compact: true,
        kicker: "短视频带货",
        title: "找品 → 判断 → 脚本 → 制作",
        desc: "每个功能独立启动，也可以读取上一环节归档结果连续迭代。",
        sideTitle: "安全边界",
        sideText: "平台账号、扫码、验证码由用户自己处理；所有浏览器操控统一用 Kimi WebBridge 接管已登录页面。",
        sections: [{
          title: "系统准备",
          note: "完整跑通前先检查/安装一次",
          gridClass: "system-prep-grid",
          cards: [
            { step: "必装", title: "浏览器接管", desc: "Kimi WebBridge 接管已登录页面。", prep: "账号、扫码、验证码、授权由用户处理。", button: "查看清单", openPath: "山竹智能体知识库/短视频带货/00-系统能力安装清单.md", primary: true },
            { step: "必装", title: "Vault 写入", desc: "读取上一环节并归档结果。", prep: "确保能写入短视频带货各目录。", button: "查看清单", openPath: "山竹智能体知识库/短视频带货/00-系统能力安装清单.md" },
            { step: "必装", title: "工作流 Skills", desc: "找品、评分、脚本、视频制作。", prep: "浏览器流程统一用 Kimi。", button: "查看清单", openPath: "山竹智能体知识库/短视频带货/00-系统能力安装清单.md", accent: true }
          ],
          actions: [
            { text: "安装/检查功能插件", workflow: "short-video-install-capabilities", autosend: true, runButton: true, accent: true },
            { text: "打开系统能力清单", openPath: "山竹智能体知识库/短视频带货/00-系统能力安装清单.md", secondary: true }
          ]
        }, {
          title: "功能按钮",
          note: "每个功能都有独立页面",
          cards: [
            { step: "01", title: "平台自动找品", desc: "登录平台后只读取商品数据，整理候选品。", prep: "准备平台账号、类目/关键词、价格带、佣金要求。", button: "进入找品", openPath: "山竹智能体知识库/短视频带货/平台找品/00-平台自动找品.md", primary: true },
            { step: "", title: "选品记录", desc: "沉淀已跑量商品，方便反复出新脚本、新视频和复盘迭代。", prep: "记录商品链接、跑量数据、最好素材、评论反馈和下一轮方向。", button: "打开记录", openPath: "山竹智能体知识库/短视频带货/选品记录/00-选品记录.md" },
            { step: "02", title: "内容形式判断", desc: "判断适合图文、AI 视频、真人实拍或直播切片。", prep: "可读取选品记录、平台找品或评分结果，也可自定义产品名、价格、卖点、图片/链接。", button: "进入判断", openPath: "山竹智能体知识库/短视频带货/内容形式判断/00-内容形式判断.md" },
            { step: "03", title: "脚本口播生成", desc: "生成钩子、口播、画面、字幕、CTA。", prep: "准备产品、卖点、内容形式；也可以读取内容形式判断结果。", button: "进入脚本", openPath: "山竹智能体知识库/短视频带货/产品脚本/00-带货脚本分镜.md" },
            { step: "04", title: "制作视频", desc: "先生成即梦/可灵提示词，再确认后发送到平台生成。", prep: "准备脚本口播、产品图、卖点、目标时长和工具选择。", button: "进入制作", openPath: "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md", accent: true }
          ]
        }]
      },
      "novel-home": {
        compact: true,
        kicker: "写小说",
        title: "先选小说项目，再继续写",
        desc: "小说不是一次性生成。先选正在写的项目，进入项目总控页后再做爆款参考、世界观、人设、大纲、正文和质检。",
        sideTitle: "小白原则",
        sideText: "每本小说独立保存爆款参考、世界观、人设、大纲、章节和质检记录；按钮会围绕当前项目复用上下文，避免每次从零开始。",
        sections: [
          { title: "1. 当前优先继续", note: "显示为：项目名 - 当前板块；点击直接回到该节点继续完成", novelActiveNodes: { limit: 1 } },
          { title: "2. 新建 / 前期准备", note: "没项目时先从这里开始；找爆款和新建项目都要先起项目名", gridClass: "novel-prep-grid", cards: [
            { step: "新建", title: "新建小说项目", desc: "创建一套可长期迭代的小说项目文件夹和项目总控页。", prep: "准备小说名、题材、目标平台和一句话创意。", button: "新建项目", openPath: "山竹智能体知识库/写小说/作品项目/00-新建小说项目.md", primary: true },
            { step: "参考", title: "爆款参考 / 仿写改造", desc: "还没确定写哪本时，先找爆款、拆爽点，再做差异化创意。", prep: "准备题材关键词或榜单方向。", button: "进入参考", openPath: "山竹智能体知识库/写小说/找爆款/00-找爆款.md", accent: true }
          ]},
          { title: "3. 全部项目进展", note: "显示每个项目当前做到哪一步；例如：项目名 - 仿写爆款，点击直接继续", novelActiveNodes: { limit: 12, empty: "还没有项目进展。先起项目名，再跑找爆款或新建项目。" } }
        ]
      },
      "novel-project-workbench": {
        compact: true,
        kicker: "小说项目",
        title: `《${novelProjectTitle}》项目总控`,
        desc: "这里是单本小说的持续写作工作台。先读项目资料，再继续做世界观、人设、大纲、正文和质检。",
        sideProgress: novelProjectProgress,
        sections: [
          { title: "创作进度 / 文章库", note: "每章卡片可直接打开正文，摘要用于快速过进度", novelChapterLibrary: novelProjectProgress },
          { title: "项目功能", note: "围绕当前小说复用上下文", cards: [
            { step: "01", title: "爆款参考 / 仿写改造", desc: "拆爆款结构和爽点，再转成这本书自己的差异化方案。", prep: "适合开书前、卡题材、想换开篇时使用。", button: "进入参考", openPath: `${novelProjectPath}/01-爆款参考与仿写.md`, primary: true },
            { step: "02", title: "世界观设定", desc: "先定世界规则、时代背景、势力、地点和不能破坏的边界。", prep: "先把世界规则跑顺，再做人设，避免人物和规则打架。", button: "做世界观", openPath: `${novelProjectPath}/02-世界观设定.md` },
            { step: "03", title: "人设关系", desc: "再定主角、反派、配角、欲望、秘密、关系张力和成长线。", prep: "人物要服务世界规则和核心爽点。", button: "做人设", openPath: `${novelProjectPath}/03-人设关系.md` },
            { step: "04", title: "大纲规划", desc: "从世界观和人设出发，规划整卷节奏、前 30 章和下一章场景。", prep: "适合定前 30 章、卷尾钩子、下一章冲突。", button: "进入大纲", openPath: `${novelProjectPath}/04-大纲规划.md` },
            { step: "05", title: "正文续写", desc: "读取项目设定、大纲和最近章节后继续写，不从零开始。", prep: "适合日更续写、补一章、改写开头。", button: "继续写", openPath: `${novelProjectPath}/05-正文续写.md`, accent: true },
            { step: "06", title: "连续性 / 质检润色", desc: "检查时间线、伏笔、人物动机、去 AI 味和网文节奏。", prep: "适合写完一章后统一检查和修。", button: "进入质检", openPath: `${novelProjectPath}/06-质检润色.md` }
          ]},
          { title: "项目文件", note: "直接打开项目资料", actions: [
            { text: "项目总控", openPath: `${novelProjectPath}/00-项目总控.md`, secondary: true },
            { text: "章节目录", openPath: `${novelProjectPath}/章节正文/00-章节目录.md`, secondary: true },
            { text: "返回写小说入口", openPath: "山竹智能体知识库/写小说/00-入口.md", secondary: true }
          ]}
        ]
      },
      "platform-product-mining": {
        compact: true,
        kicker: "平台自动找品",
        title: "找品出数据 → AI 评分 → Kimi 确认加橱窗",
        desc: "第一步只抓商品数据，不再连带评分和内容判断；后续可读取上一轮结果继续迭代。",
        sideTitle: "流程",
        sideText: "找品出数据 → AI 选品评分 → Kimi 复用第一步浏览器确认添加选品车/橱窗",
        sections: [
          { title: "1. 打开平台", platforms: [
            { text: "巨量百应 / 精选联盟", openUrl: "https://buyin.jinritemai.com/", openMode: "chrome", agentSession: "senxue-buyin" }
          ]},
          { title: "2. 找品出数据", note: "只读取候选商品，不评分、不判断内容形式", runner: {
            name: "platform-product-mining",
            fields: [
              { label: "平台", param: "平台", type: "select", options: ["巨量百应 / 精选联盟", "其他已登录平台"] },
              { label: "类目 / 关键词", param: "类目或关键词", placeholder: "例：厨房收纳、银发用品、宠物清洁" },
              { label: "价格带", param: "价格带", placeholder: "例：29-99 元" },
              { label: "佣金要求", param: "佣金要求", placeholder: "例：20% 以上 / 不限" },
              { label: "抓取数量", param: "抓取数量", value: "30" },
              { label: "商品图采集", param: "商品图采集", type: "select", options: ["开启：抓取主图并归档", "关闭：只抓文字数据"] },
              { label: "排序方式", param: "排序方式", type: "select", options: ["佣金从高到低", "产品价格从高到低", "销量从高到低"] }
            ],
            actions: [{ text: "我已登录，开始找品出数据", workflow: "platform-product-mining", autosend: true, runButton: true }],
            tip: "使用 Kimi WebBridge，只抓取并归档候选商品数据。"
          }},
          { title: "3. AI 选品评分", note: "默认读取第二步刚产出的找品结果", runner: {
            name: "product-selection-score",
            fields: [
              ...sourceFields(latestPlatformData),
              { label: "评分重点", param: "评分重点", type: "select", options: ["综合评分", "优先内容潜力", "优先利润空间", "优先低退货风险"] },
              { label: "TOP3主图采集", param: "TOP3主图采集", type: "select", options: ["开启：评分后自动截TOP3主图", "关闭：只输出评分"] },
              { label: "排除条件", param: "排除条件", placeholder: "例：不要食品/保健/高售后品" }
            ],
            wideFields: [
              { label: "自定义候选商品数据 / 补充说明", param: "候选商品数据", type: "textarea", placeholder: "可粘贴商品名、价格、佣金、销量、链接、风险备注；选择读取上一结果时可留空。" }
            ],
            actions: [{ text: "开始 AI 选品评分", workflow: "product-selection-score", autosend: true, runButton: true }],
            tip: "执行前会重新读取平台找品目录里的最新产出，不使用页面打开时的旧资料。评分结果可继续用于内容形式判断或添加橱窗。"
          }},
          { title: "4. 确认添加橱窗", note: "直接复用第一步选品浏览器；Kimi 先读清单，用户确认后才点击添加", runner: {
            name: "showcase-confirm-add",
            fields: [
              { label: "目标位置", param: "目标位置", type: "select", options: ["巨量百应选品车 / 合作商品", "抖音橱窗", "两个都支持，执行前再确认"] },
              ...sourceFields(latestSelectionData),
              { label: "添加范围", param: "添加范围", type: "select", options: ["读取评分结果 TOP1，添加前确认", "读取评分结果 TOP3，添加前逐个确认", "按我填写的商品清单，添加前确认"] }
            ],
            wideFields: [
              { label: "待添加商品 / 用户确认说明", param: "待添加商品或确认说明", type: "textarea", placeholder: "可填商品名、链接、商品ID；若读取评分结果，可写：读取 TOP3，先列出清单让我确认，确认后在第一步选品浏览器里用 Kimi 添加。" }
            ],
            actions: [{ text: "用 Kimi 确认后添加橱窗/选品车", workflow: "showcase-confirm-add", autosend: true, runButton: true }],
            tip: "强制复用第一步已登录浏览器；添加前必须二次确认清单，不保存账号密码，不绕过验证码/风控/授权。"
          }},
          { title: "更多入口", actions: [
            { text: "打开找品库", openPath: "山竹智能体知识库/短视频带货/平台找品/00-索引.md", secondary: true },
            { text: "进入内容形式判断", openPath: "山竹智能体知识库/短视频带货/内容形式判断/00-内容形式判断.md", secondary: true }
          ]}
        ]
      },
      "product-records": this.getFormWorkflowConfig("选品总记录", "product-records", "product-records", "默认读取 AI 选品评分，只沉淀历史选品商品名称、评分、风险和复测状态。", [
        ...sourceFields(latestProductRecordData),
        { label: "查看范围", param: "查看范围", type: "select", options: ["汇总全部选品", "只看高分品", "只看待复测", "只看风险品"] },
        { label: "选择商品", param: "选择商品", type: "select", options: this.collectProductHistoryOptions(30) },
        { label: "记录动作", param: "记录动作", type: "select", options: ["生成/更新选品总台账", "查看单品历史情况", "复盘迭代建议"] },
        { label: "商品名称 / 链接", param: "商品名称或链接", placeholder: "可选：商品名、平台链接、橱窗/选品车链接；不填则按上方选择读取" },
        { label: "补充说明", param: "补充说明", type: "textarea", placeholder: "可选：补充跑量数据、成交情况、评论反馈、下一轮想测的方向。" }
      ], [{ text: "生成/查看选品总记录", workflow: "product-records", autosend: true, runButton: true }], [
        { text: "生成脚本口播", openPath: "山竹智能体知识库/短视频带货/产品脚本/00-带货脚本分镜.md", secondary: true },
        { text: "进入制作视频", openPath: "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md", secondary: true },
        { text: "内容形式判断", openPath: "山竹智能体知识库/短视频带货/内容形式判断/00-内容形式判断.md", secondary: true }
      ], [
        { title: "历史选品记录", note: "只显示历史商品名称，点商品名查看对应选品记录。", knowledgeLinks: { prefixes: ["山竹智能体知识库/短视频带货/AI选品评分/", "山竹智能体知识库/短视频带货/选品记录/"], limit: 12, productNamesOnly: true, empty: "还没有历史选品商品。先跑一次 AI 选品评分。" } }
      ]),
      "product-selection-score": this.getFormWorkflowConfig("AI 选品评分", "product-selection-score", "product-selection", "对候选品做市场热度、利润、内容潜力、竞争强度、退货/合规风险评分。", [
        ...sourceFields(latestPlatformData),
        { label: "候选商品数据", param: "候选商品数据", type: "textarea", placeholder: "粘贴或概括平台找品结果、商品名、价格、佣金、销量、GMV、评论风险。" },
        { label: "评分重点", param: "评分重点", type: "select", options: ["综合评分", "优先内容潜力", "优先利润空间", "优先低退货风险"] },
        { label: "TOP3主图采集", param: "TOP3主图采集", type: "select", options: ["开启：评分后自动截TOP3主图", "关闭：只输出评分"] },
        { label: "排除条件", param: "排除条件", placeholder: "例：不要食品/保健/高售后品" }
      ], [{ text: "开始选品评分", workflow: "product-selection-score", autosend: true, runButton: true }], [
        { text: "判断内容形式", openPath: "山竹智能体知识库/短视频带货/内容形式判断/00-内容形式判断.md", secondary: true },
        { text: "进入制作视频", openPath: "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md", secondary: true },
        { text: "回到平台找品页", openPath: "山竹智能体知识库/短视频带货/平台找品/00-平台自动找品.md", secondary: true }
      ]),
      "product-content-fit": this.getFormWorkflowConfig("内容形式判断", "product-content-fit", "product-content-fit", "判断这个产品适合图文、AI 视频、真人实拍、直播切片，还是不建议内容带货。", [
        ...sourceFields(latestSelectionData),
        { label: "产品信息", param: "产品信息", type: "textarea", placeholder: "产品名、价格、卖点、人群、平台数据、评论风险。" },
        { label: "产品图 / 链接", param: "产品图或链接", placeholder: "可填链接、图片说明或素材路径" },
        { label: "目标人群", param: "目标人群", placeholder: "例：宝妈、银发、租房党、宠物人群" }
      ], [{ text: "判断内容形式", workflow: "product-content-fit", autosend: true, runButton: true }], [
        { text: "生成脚本口播", openPath: "山竹智能体知识库/短视频带货/产品脚本/00-带货脚本分镜.md", secondary: true },
        { text: "进入制作视频", openPath: "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md", secondary: true }
      ]),
      "video-duration-calculator": this.getFormWorkflowConfig("视频秒数测算", "video-duration-calculator", "video-duration-calculator", "测算适合 8-12 秒、15 秒、30 秒、45 秒、60 秒，还是图文优先。", [
        ...sourceFields(latestScriptData),
        { label: "产品和卖点", param: "产品和卖点", type: "textarea", placeholder: "产品、客单价、卖点数量、是否需要演示、用户疑虑。" },
        { label: "内容形式", param: "内容形式", type: "select", options: ["未判断", "图文", "AI 视频", "真人实拍", "直播切片", "混合"] },
        { label: "测试目标", param: "测试目标", placeholder: "例：高完播、强转化、低成本测品" }
      ], [{ text: "测算视频秒数", workflow: "video-duration-calculator", autosend: true, runButton: true }], [
        { text: "进入制作视频", openPath: "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md", secondary: true }
      ]),
      "jimeng-kling-prompt-builder": this.getFormWorkflowConfig("即梦 / 可灵提示词", "jimeng-kling-prompt-builder", "jimeng-kling-prompt-builder", "生成带货口播、画面、字幕、CTA 和匹配内容音乐/BGM 的即梦/可灵视频提示词。", [
        ...sourceFields(latestScriptData),
        { label: "产品和卖点", param: "产品和卖点", type: "textarea", placeholder: "产品、核心卖点、目标人群、使用场景。" },
        { label: "参考图 / 商品图", param: "参考图或商品图", placeholder: "可留空：默认读取最新AI选品评分里的TOP3主图路径" },
        { label: "口播 / 音乐要求", param: "口播BGM字幕", type: "select", options: ["写死：带货口播 + 匹配内容音乐/BGM + 字幕 + CTA"] },
        { label: "工具", param: "工具", type: "select", options: ["即梦 + 可灵都要", "即梦", "可灵"] },
        { label: "画面风格", param: "画面风格", placeholder: "例：真实电商场景、家庭生活、干净高级、强对比" }
      ], [{ text: "生成提示词", workflow: "jimeng-kling-prompt-builder", autosend: true, runButton: true }], [
        { text: "生成脚本口播", openPath: "山竹智能体知识库/短视频带货/产品脚本/00-带货脚本分镜.md", secondary: true }
      ]),
      "video-production": {
        compact: true,
        kicker: "短视频带货",
        title: "制作视频",
        desc: "把脚本变成可执行的视频制作资料：先生成带货口播和匹配音乐的即梦/可灵提示词，再确认后发送到平台生成。",
        sideTitle: "生成提醒",
        sideText: "只负责填入提示词；点击生成前必须由你确认，避免误扣积分或额度。",
        sections: [
          { title: "1. 生成即梦 / 可灵提示词", note: "把脚本转成可直接复制到平台的视频提示词，写死带货口播和匹配内容音乐/BGM", runner: {
            name: "jimeng-kling-prompt-builder",
            fields: [
              ...sourceFields(latestScriptData),
              { label: "工具", param: "工具", type: "select", options: ["即梦 + 可灵都要", "即梦", "可灵"] },
              { label: "视频类型", param: "视频类型", type: "select", options: ["图生视频", "文生视频", "商品场景视频", "口播 B-roll", "混合"] },
              { label: "参考图 / 商品图", param: "参考图或商品图", placeholder: "可留空：默认读取最新AI选品评分里的TOP3主图路径" },
              { label: "口播 / 音乐要求", param: "口播BGM字幕", type: "select", options: ["写死：带货口播 + 匹配内容音乐/BGM + 字幕 + CTA"] },
              { label: "画面风格", param: "画面风格", placeholder: "例：真实电商场景、家庭生活、干净高级、强对比" }
            ],
            wideFields: [
              { label: "脚本 / 分镜 / 产品图说明", param: "脚本分镜或产品图说明", type: "textarea", placeholder: "粘贴脚本、分镜、产品图描述、商品特征；系统会强制补入带货口播和匹配内容音乐/BGM。" }
            ],
            actions: [{ text: "生成视频提示词", workflow: "jimeng-kling-prompt-builder", autosend: true, runButton: true }],
            tip: "提示词会写死：带货口播、匹配内容音乐/BGM、字幕和CTA；不再只出无声画面。"
          }},
          { title: "2. 发送到即梦 / 可灵生成视频", note: "先填入提示词，生成前必须由你确认", runner: {
            name: "ai-video-submit-confirm",
            fields: [
              ...sourceFields(latestVideoData),
              { label: "工具", param: "工具", type: "select", options: ["即梦", "可灵"] },
              { label: "生成模式", param: "生成模式", type: "select", options: ["图生视频", "文生视频", "商品场景视频", "口播 B-roll", "混合"] },
              { label: "生成前确认", param: "生成前确认", type: "select", options: ["开启：填入后必须由我确认再点击生成"] },
              { label: "参考图 / 商品图路径或链接（可选）", param: "参考图或商品图", placeholder: "可留空：默认读取最新AI选品评分/TOP3主图路径" }
            ],
            wideFields: [
              { label: "视频提示词", param: "视频提示词", type: "textarea", placeholder: "粘贴第一步生成的即梦/可灵提示词；缺少带货口播或匹配内容音乐/BGM时会自动补齐。" }
            ],
            actions: [{ text: "打开平台并填入提示词", workflow: "ai-video-submit-confirm", autosend: true, runButton: true }],
            tip: "不会直接扣费；填好后会等待你确认再点生成。若提示词缺少带货口播或匹配内容音乐/BGM，会先补齐。"
          }},
          { title: "下一步", actions: [
            { text: "返回脚本口播生成", openPath: "山竹智能体知识库/短视频带货/产品脚本/00-带货脚本分镜.md", secondary: true }
          ]}
        ]
      },
      "short-video-scripting": this.getFormWorkflowConfig("脚本口播生成", "short-video-scripting", "short-video-scripting", "生成钩子、口播、画面、字幕、BGM、CTA 和分镜。", [
        ...sourceFields(latestContentData),
        { label: "生成范围", param: "生成范围", type: "select", options: ["读取评分结果 TOP1", "读取评分结果 TOP3", "读取评分结果 TOP5", "指定商品序号", "自定义产品清单"] },
        { label: "每个商品脚本数", param: "每个商品脚本数", type: "select", options: ["每个商品 1 条", "每个商品 2 条", "每个商品 3 条"] },
        { label: "视频时长", param: "视频时长", placeholder: "例：15 秒 / 30 秒 / 45 秒" },
        { label: "素材方式", param: "素材方式", type: "select", options: ["AI 视频为主", "真人实拍为主", "图文为主", "混合素材"] },
        { label: "产品资料", param: "产品资料", type: "textarea", placeholder: "可选：指定商品序号、产品、卖点、目标人群、内容形式、推荐时长、提示词结果。选择读取上一结果时可留空。" }
      ], [{ text: "生成脚本口播", workflow: "short-video-scripting", autosend: true, runButton: true }], [
        { text: "进入制作视频", openPath: "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md", secondary: true },
        { text: "打开产品脚本库", openPath: "山竹智能体知识库/短视频带货/产品脚本/00-索引.md", secondary: true }
      ]),
      "novel-project-create": this.getNovelWorkflowConfig("新建小说项目", "novel-project-create", "创建可持续迭代的小说项目", "创建一个独立小说项目文件夹，后续所有世界观、人设、大纲、正文和质检都围绕这个项目复用。", [
        { label: "项目名 / 小说名", param: "项目名", placeholder: "例：凶宅验收师、玄学直播爆红", required: true },
        { label: "目标平台", param: "目标平台", type: "select", options: ["番茄小说", "七猫小说", "起点中文网", "晋江 / 女频", "飞卢 / 男频", "其他"] },
        { label: "题材类型", param: "题材类型", placeholder: "例：玄学直播、重生年代、规则怪谈、都市逆袭" },
        { label: "一句话创意", param: "一句话创意", type: "textarea", placeholder: "用一句话描述这本小说的主角、处境、金手指和核心爽点。" },
        { label: "参考爆款 / 禁区", param: "参考爆款或禁区", type: "textarea", placeholder: "可粘贴爆款参考、不要写的雷点、平台风险或你已有设定。" }
      ], [{ text: "创建小说项目", workflow: "novel-project-create", autosend: true, runButton: true }], [
        { text: "返回写小说入口", openPath: "山竹智能体知识库/写小说/00-入口.md", secondary: true }
      ]),
      "novel-project-bestseller": this.getNovelWorkflowConfig("爆款参考 / 仿写改造", "novel-project-bestseller", "项目内爆款拆解与差异化改造", "围绕当前小说项目找爆款、拆结构、提炼爽点，并转成这本书可用的差异化方案。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelBestsellerData),
        { label: "题材 / 关键词", param: "题材或关键词", placeholder: "例：玄学直播、年代文、规则怪谈" },
        { label: "平台 / 来源", param: "平台或来源", type: "select", options: ["番茄小说", "七猫小说", "起点中文网", "晋江 / 女频", "飞卢 / 男频", "用户粘贴样本"] },
        { label: "样本 / 参考链接", param: "样本或参考链接", type: "textarea", placeholder: "可粘贴榜单链接、书名列表、简介或找爆款报告。" }
      ], [{ text: "更新爆款参考", workflow: "novel-project-bestseller", autosend: true, runButton: true }], novelNext(latestNovelBestsellerData, [
        { text: "进入世界观设定", openPath: `${novelProjectPath}/02-世界观设定.md`, secondary: true }
      ])),
      "novel-project-worldbuilding": this.getNovelWorkflowConfig("世界观设定", "novel-project-worldbuilding", "先定世界规则和设定边界", "先整理时代背景、世界规则、势力、地点、限制条件和不能破坏的设定，再进入人设。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelProjectData),
        { label: "世界类型 / 时代背景", param: "世界类型或时代背景", placeholder: "例：现代都市玄学、架空仙侠、规则怪谈副本、重生年代" },
        { label: "核心规则", param: "核心规则", type: "textarea", placeholder: "写清楚这个世界最重要的规则、能力边界、势力规则、不能破坏的设定。" },
        { label: "势力 / 地点 / 禁区", param: "势力地点禁区", type: "textarea", placeholder: "写主要势力、关键地点、危险区域、平台雷点或不能写的内容。" }
      ], [{ text: "生成世界观设定", workflow: "novel-project-worldbuilding", autosend: true, runButton: true }], novelNext(latestNovelProjectData, [
        { text: "进入人设关系", openPath: `${novelProjectPath}/03-人设关系.md`, secondary: true }
      ])),
      "novel-project-character": this.getNovelWorkflowConfig("人设关系", "novel-project-character", "再做人设关系和人物张力", "基于项目卡和世界观，生成主角、反派、配角、人物欲望、秘密、冲突和成长线。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelProjectData),
        { label: "主角方向", param: "主角方向", placeholder: "例：嘴硬心软、重生复仇、天才但社恐、专业冷静" },
        { label: "反派 / 对手", param: "反派或对手", placeholder: "例：前夫家族、竞争门派、资本公司、黑中介组织" },
        { label: "关系张力", param: "关系张力", type: "textarea", placeholder: "写主角与反派、搭档、家人、客户、师门之间的利益冲突、秘密和变化。" }
      ], [{ text: "生成人设关系", workflow: "novel-project-character", autosend: true, runButton: true }], novelNext(latestNovelProjectData, [
        { text: "进入大纲规划", openPath: `${novelProjectPath}/04-大纲规划.md`, secondary: true }
      ])),
      "novel-project-settings": this.getNovelWorkflowConfig("设定库", "novel-project-settings", "旧版入口：已拆成世界观和人设", "这个入口保留兼容旧项目。新流程建议先进入世界观设定，再进入人设关系。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelProjectData),
        { label: "要更新的设定", param: "要更新的设定", type: "select", options: ["综合更新", "项目定位", "主角/反派/配角", "世界观规则", "禁用设定与雷点"] },
        { label: "新增或修改内容", param: "新增或修改内容", type: "textarea", placeholder: "写清楚你想新增、修改或检查的设定。AI 会先读项目现有设定，再给出更新版。" }
      ], [{ text: "更新旧版设定库", workflow: "novel-project-settings", autosend: true, runButton: true }], novelNext(latestNovelProjectData, [
        { text: "进入世界观设定", openPath: `${novelProjectPath}/02-世界观设定.md`, secondary: true }
      ])),
      "novel-project-outline": this.getNovelWorkflowConfig("大纲规划", "novel-project-outline", "主线卷纲 + 章节场景卡合并", "从当前项目设定出发，规划整卷节奏、前 30 章、下一章场景卡和结尾钩子。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelSettingsData),
        { label: "规划颗粒度", param: "规划颗粒度", type: "select", options: ["下一章场景卡", "前10章", "前30章", "第一卷", "修大纲"] },
        { label: "当前进度 / 需求", param: "当前进度或需求", type: "textarea", placeholder: "例：当前第12章，女主刚发现真相；下一章要打脸但不能暴露男主身份。" }
      ], [{ text: "更新大纲", workflow: "novel-project-outline", autosend: true, runButton: true }], novelNext(latestNovelSettingsData, [
        { text: "进入正文续写", openPath: `${novelProjectPath}/05-正文续写.md`, secondary: true }
      ])),
      "novel-project-draft": this.getNovelWorkflowConfig("正文续写", "novel-project-draft", "读取当前项目后续写正文", "先读取当前项目设定、大纲和最近章节，再按目标继续写，不重新开书。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelOutlineData),
        { label: "写作任务", param: "写作任务", type: "select", options: ["继续写下一章", "重写本章开头", "补一段冲突", "扩写场景", "改写成更爽"] },
        { label: "目标字数", param: "目标字数", placeholder: "例：800字、1500字、3000字" },
        { label: "本次要求", param: "本次要求", type: "textarea", placeholder: "写本章目标、必须承接的上一章状态、不能提前泄露的信息。" }
      ], [{ text: "开始续写", workflow: "novel-project-draft", autosend: true, runButton: true }], novelNext(latestNovelOutlineData, [
        { text: "进入质检润色", openPath: `${novelProjectPath}/06-质检润色.md`, secondary: true }
      ])),
      "novel-project-qc": this.getNovelWorkflowConfig("连续性 / 质检润色", "novel-project-qc", "时间线伏笔 + 去 AI 味合并检查", "检查当前项目正文的时间线、人物信息差、伏笔、节奏、AI 味和标点格式。", [
        { label: "小说项目", param: "小说项目", value: novelProjectTitle },
        { label: "小说项目路径", param: "小说项目路径", value: novelProjectPath },
        ...novelSourceFields(latestNovelDraftData),
        { label: "质检类型", param: "质检类型", type: "select", options: ["综合质检", "只查连续性", "只查伏笔", "只去 AI 味", "只看爽点节奏"] },
        { label: "待检查正文 / 章节范围", param: "待检查正文或章节范围", type: "textarea", placeholder: "可粘贴正文片段，或写：检查最近一章 / 检查第1-5章。" }
      ], [{ text: "开始质检润色", workflow: "novel-project-qc", autosend: true, runButton: true }], novelNext(latestNovelDraftData, [
        { text: "继续写正文", openPath: `${novelProjectPath}/05-正文续写.md`, secondary: true }
      ])),
      "novel-bestseller-mining": this.getNovelWorkflowConfig("找爆款", "novel-bestseller-mining", "爆款样本发现与结构拆解", "按平台、题材、关键词或样本链接，找到可参考的爆款样本并拆结构，不复制正文。", [
        { label: "项目名", param: "项目名", placeholder: "例：凶宅验收师、玄学直播爆红、重生年代小饭馆", required: true },
        { label: "平台 / 来源", param: "平台或来源", type: "select", options: ["番茄小说", "七猫小说", "起点中文网", "晋江 / 女频", "飞卢 / 男频", "用户粘贴样本"] },
        { label: "题材 / 关键词", param: "题材或关键词", placeholder: "例：玄学、重生爽文、年代文、赘婿、规则怪谈" },
        { label: "榜单 / 范围", param: "榜单或范围", placeholder: "例：新书榜、完结榜、热度榜、近30天" },
        { label: "抓取数量", param: "抓取数量", value: "10" },
        { label: "样本链接 / 已知爆款", param: "样本链接或已知爆款", type: "textarea", placeholder: "可粘贴榜单链接、书名列表、简介、开篇片段；没有就留空，由 AI 先搜索核验。" }
      ], [{ text: "开始找爆款", workflow: "novel-bestseller-mining", autosend: true, runButton: true }], novelNext(latestNovelBestsellerData, [
        { text: "进入仿写爆款", openPath: "山竹智能体知识库/写小说/仿写爆款/00-仿写爆款.md", secondary: true }
      ])),
      "novel-bestseller-imitation": this.getNovelWorkflowConfig("仿写爆款", "novel-bestseller-imitation", "爆款结构仿写与差异化改造", "基于爆款拆解结果，仿结构、仿节奏、仿爽点，不仿具体表达。", [
        ...novelSourceFields(latestNovelBestsellerData),
        { label: "项目名", param: "项目名", placeholder: "例：凶宅验收师；如果读取上一环节可自动沿用" },
        { label: "爆款样本 / 拆解结果", param: "爆款样本或拆解结果", type: "textarea", placeholder: "粘贴找爆款报告、书名、简介、开篇、爽点机制或章节节奏。" },
        { label: "仿写重点", param: "仿写重点", type: "select", options: ["同题材差异化", "同人设张力", "同爽点机制", "同节奏结构", "综合仿写"] },
        { label: "目标平台", param: "目标平台", type: "select", options: ["番茄小说", "七猫小说", "起点中文网", "晋江 / 女频", "其他"] },
        { label: "避开方向", param: "避开方向", placeholder: "例：不要校园、不要系统流、不要抄原主角职业" }
      ], [{ text: "开始仿写爆款", workflow: "novel-bestseller-imitation", autosend: true, runButton: true }], novelNext(latestNovelImitationData, [
        { text: "初始化作品项目", openPath: "山竹智能体知识库/写小说/作品项目/00-作品项目初始化.md", secondary: true }
      ])),
      "novel-project-setup": this.getNovelWorkflowConfig("作品项目初始化", "novel-project-setup", "小说项目卡生成", "把题材、读者、卖点、禁区、更新目标固化成可持续创作的项目卡。", [
        ...novelSourceFields(latestNovelImitationData),
        { label: "项目名", param: "项目名", placeholder: "例：凶宅验收师；必须写，后续用它归档和显示当前节点", required: true },
        { label: "一句话创意", param: "一句话创意", placeholder: "例：被退婚的玄学少女靠直播抓鬼爆红" },
        { label: "目标平台 / 读者", param: "目标平台或读者", placeholder: "例：番茄女频、爽文读者、30岁女性" },
        { label: "题材类型", param: "题材类型", type: "select", options: ["都市爽文", "玄幻 / 仙侠", "悬疑 / 规则怪谈", "年代 / 种田", "言情 / 甜宠", "自定义"] },
        { label: "参考爆款 / 禁区", param: "参考爆款或禁区", type: "textarea", placeholder: "可粘贴爆款拆解结果；也可写不要出现的设定、雷点和平台风险。" }
      ], [{ text: "生成项目卡", workflow: "novel-project-setup", autosend: true, runButton: true }], novelNext(latestNovelProjectData, [
        { text: "做世界观设定", openPath: "山竹智能体知识库/写小说/世界观设定/00-世界观设定.md", secondary: true }
      ])),
      "novel-character-web": this.getNovelWorkflowConfig("人设关系网", "novel-character-web", "人物设定与关系张力", "生成主角、反派、配角、人物欲望、秘密、冲突和成长线。", [
        ...novelSourceFields(latestNovelProjectData),
        { label: "作品项目卡", param: "作品项目卡", type: "textarea", placeholder: "粘贴项目卡、题材、世界观或已有人设。" },
        { label: "主角方向", param: "主角方向", placeholder: "例：嘴硬心软、重生复仇、天才但社恐" },
        { label: "反派 / 对手", param: "反派或对手", placeholder: "例：前夫家族、竞争门派、资本公司" },
        { label: "关系张力", param: "关系张力", placeholder: "例：师徒、宿敌、真假千金、合作但互不信任" }
      ], [{ text: "生成人设关系网", workflow: "novel-character-web", autosend: true, runButton: true }], novelNext(latestNovelSettingsData, [
        { text: "生成主线卷纲", openPath: "山竹智能体知识库/写小说/作品项目/00-主线卷纲规划.md", secondary: true }
      ])),
      "novel-worldbuilding": this.getNovelWorkflowConfig("世界观设定", "novel-worldbuilding", "世界规则与设定边界", "整理时代背景、规则、势力、地图、限制条件和不能破坏的设定。", [
        ...novelSourceFields(latestNovelProjectData),
        { label: "项目 / 题材", param: "项目或题材", type: "textarea", placeholder: "粘贴项目卡、题材方向或已有世界观。" },
        { label: "核心规则", param: "核心规则", placeholder: "例：灵气复苏规则、系统限制、家族势力规则" },
        { label: "势力 / 地点", param: "势力或地点", placeholder: "例：三大家族、学院、直播平台、异世界大陆" },
        { label: "禁用设定", param: "禁用设定", placeholder: "例：不要无限升级、不要降智反派、不要突然开挂" }
      ], [{ text: "生成世界观设定", workflow: "novel-worldbuilding", autosend: true, runButton: true }], novelNext(latestNovelProjectData, [
        { text: "生成人设关系网", openPath: "山竹智能体知识库/写小说/人物设定/00-人设关系网.md", secondary: true }
      ])),
      "novel-plot-arc": this.getNovelWorkflowConfig("主线 / 卷纲规划", "novel-plot-arc", "主线目标与卷纲节奏", "把项目卡拆成主线目标、阶段爽点、反转、卷尾钩子和持续追读理由。", [
        ...novelSourceFields(latestNovelSettingsData),
        { label: "项目卡 / 人设 / 世界观", param: "项目卡人设世界观", type: "textarea", placeholder: "粘贴已生成的项目卡、人设和世界观。" },
        { label: "规划长度", param: "规划长度", placeholder: "例：前30章、第一卷、10万字试写" },
        { label: "爽点类型", param: "爽点类型", type: "select", options: ["打脸逆袭", "事业升级", "情感拉扯", "悬疑反转", "群像成长", "综合"] },
        { label: "必须保留 / 禁止剧情", param: "必须保留或禁止剧情", placeholder: "例：必须第5章爆第一个大爽点；不要误会拖太久" }
      ], [{ text: "生成主线卷纲", workflow: "novel-plot-arc", autosend: true, runButton: true }], novelNext(latestNovelSettingsData, [
        { text: "拆章节场景卡", openPath: "山竹智能体知识库/写小说/章节大纲/00-章节大纲场景卡.md", secondary: true }
      ])),
      "novel-scene-card": this.getNovelWorkflowConfig("章节大纲 / 场景卡", "novel-scene-card", "章节场景卡拆分", "把卷纲拆成每章目标、冲突、信息差、出场人物、结尾钩子。", [
        ...novelSourceFields(latestNovelOutlineData),
        { label: "卷纲 / 上一章状态", param: "卷纲或上一章状态", type: "textarea", placeholder: "粘贴卷纲、上一章结尾、人物当前状态。" },
        { label: "本章目标", param: "本章目标", placeholder: "例：女主第一次反杀、主角拿到关键线索" },
        { label: "出场人物", param: "出场人物", placeholder: "例：主角、反派母亲、暗中观察的男主" },
        { label: "结尾钩子", param: "结尾钩子", placeholder: "例：门外的人竟然听完了全部对话" }
      ], [{ text: "生成场景卡", workflow: "novel-scene-card", autosend: true, runButton: true }], novelNext(latestNovelOutlineData, [
        { text: "开始正文续写", openPath: "山竹智能体知识库/写小说/章节正文/00-正文续写.md", secondary: true }
      ])),
      "novel-timeline-foreshadowing": this.getNovelWorkflowConfig("时间线与伏笔检查", "novel-timeline-foreshadowing", "连续性、伏笔和逻辑质检", "检查人物知道什么、事件顺序、伏笔回收、设定突兀和信息提前泄露。", [
        ...novelSourceFields(latestNovelOutlineData),
        { label: "大纲 / 正文", param: "大纲或正文", type: "textarea", placeholder: "粘贴章节大纲、正文片段或时间线记录。" },
        { label: "检查重点", param: "检查重点", type: "select", options: ["综合检查", "只查时间线", "只查人物信息差", "只查伏笔回收", "只查设定冲突"] },
        { label: "伏笔清单", param: "伏笔清单", placeholder: "例：玉佩、录音、旧照片、男主真实身份" }
      ], [{ text: "开始检查", workflow: "novel-timeline-foreshadowing", autosend: true, runButton: true }], novelNext(latestNovelOutlineData, [
        { text: "回到场景卡", openPath: "山竹智能体知识库/写小说/章节大纲/00-章节大纲场景卡.md", secondary: true }
      ])),
      "novel-chapter-draft": this.getNovelWorkflowConfig("正文续写", "novel-chapter-draft", "按场景卡写正文", "按场景卡续写正文，控制动作、对话、节奏、细节和结尾钩子。", [
        ...novelSourceFields(latestNovelOutlineData),
        { label: "上一章 / 场景卡", param: "上一章或场景卡", type: "textarea", placeholder: "粘贴上一章结尾、本章场景卡、必须承接的状态。" },
        { label: "目标字数", param: "目标字数", placeholder: "例：800字、1500字、3000字" },
        { label: "叙事风格", param: "叙事风格", type: "select", options: ["番茄爽文", "女频细腻", "男频快节奏", "悬疑压迫感", "轻松沙雕", "自定义"] },
        { label: "禁止事项", param: "禁止事项", placeholder: "例：不要总结、不要跳时间、不要提前揭露身份" }
      ], [{ text: "开始续写正文", workflow: "novel-chapter-draft", autosend: true, runButton: true }], novelNext(latestNovelDraftData, [
        { text: "润色去 AI 味", openPath: "山竹智能体知识库/写小说/润色质检/00-润色去AI味质检.md", secondary: true }
      ])),
      "novel-polish-qc": this.getNovelWorkflowConfig("润色去 AI 味 / 质检", "novel-polish-qc", "文本润色与网文质检", "去除空泛 AI 味，检查标点、节奏、人物动机、对话和爽点密度。", [
        ...novelSourceFields(latestNovelDraftData),
        { label: "正文片段", param: "正文片段", type: "textarea", placeholder: "粘贴需要润色或质检的正文。" },
        { label: "目标风格", param: "目标风格", type: "select", options: ["更像番茄网文", "更口语自然", "更有压迫感", "更细腻", "只质检不改写"] },
        { label: "质检重点", param: "质检重点", type: "select", options: ["综合质检", "去 AI 味", "节奏和爽点", "人物动机", "标点和格式"] }
      ], [{ text: "开始润色质检", workflow: "novel-polish-qc", autosend: true, runButton: true }], novelNext(latestNovelDraftData, [
        { text: "继续写下一章", openPath: "山竹智能体知识库/写小说/章节正文/00-正文续写.md", secondary: true }
      ]))
    };
    const officeScenePages = {
      "office-order-analysis": ["订单数据分析", "读取订单或销售明细，汇总销量、客单价、Top 商品和异常订单。"],
      "office-ad-data-review": ["投放数据复盘", "读取投放数据，分析渠道效果、成本、ROI 和下一步调整建议。"],
      "office-refund-analysis": ["退款原因分析", "读取退款或售后记录，归类主要原因、责任和减少退款的措施。"],
      "office-customer-service-classify": ["客服问题归类", "读取客服聊天或工单，提炼高频问题、优先级和 FAQ。"],
      "office-logistics-exception": ["物流异常分析", "读取物流或发货记录，定位延迟、丢件、地区和供应商异常。"],
      "office-finance-summary": ["财务数据整理", "读取收入、成本、费用或回款数据，生成收支摘要和异常提示。"],
      "office-meeting-minutes": ["会议纪要整理", "读取会议转写或记录，整理结论、行动项、负责人和截止时间。"],
      "office-boss-feedback": ["老板反馈拆解", "读取语音转写、文字反馈或批注，拆解要求、风险、优先级和回复建议。"]
    };
    for (const [scenePage, [title, desc]] of Object.entries(officeScenePages)) {
      if (functionPages[scenePage]) continue;
      functionPages[scenePage] = this.getOfficeWorkflowConfig(title, scenePage, desc, [
        ...officeSourceFields(latestOfficeData),
        { label: "补充要求 / 直接粘贴材料", param: "补充要求或粘贴材料", type: "textarea", placeholder: "可直接粘贴资料，并说明重点、时间范围和最终交付要求。", requiredGroup: "office-source" }
      ], [
        { text: `开始${title}`, workflow: scenePage, autosend: true, runButton: true }
      ], [
        { text: "返回日常办公", openPath: "山竹智能体知识库/日常办公/00-入口.md", secondary: true }
      ]);
    }
    if (!functionPages["content-data-review"]) {
      functionPages["content-data-review"] = this.getFormWorkflowConfig(
        "内容数据复盘",
        "content-data-review",
        "内容数据复盘",
        "读取内容发布或投放数据，找出有效素材、低效环节和下一轮改进动作。",
        [
          ...sourceFields(latestContentData),
          { label: "平台 / 时间范围", param: "平台或时间范围", placeholder: "例：抖音近7天、小红书本月" },
          { label: "重点问题 / 补充数据", param: "重点问题或补充数据", type: "textarea", placeholder: "可粘贴播放、点击、转化、完播、评论等数据，并说明最想解决的问题。" }
        ],
        [{ text: "开始复盘", workflow: "content-data-review", autosend: true, runButton: true }],
        [{ text: "返回短视频带货", openPath: "山竹智能体知识库/短视频带货/00-入口.md", secondary: true }]
      );
    }
    return functionPages[page] || null;
  }

  getOfficeWorkflowConfig(title, page, desc, fields, actions, nextActions) {
    return {
      compact: true,
      kicker: "日常办公",
      title,
      desc,
      sideTitle: "办公执行链路",
      sideText: "读取用户选择的资料，按任务输出文档、表格、PPT或待办；表格/PPT/报表完成后，除归档到日常办公库，也自动放一份到桌面。",
      sections: [
        { title: "输入信息", note: "填必要信息后启动；不清楚就选直接粘贴材料", runner: { name: page, fields: fields.filter((f) => f.type !== "textarea"), wideFields: fields.filter((f) => f.type === "textarea"), actions, tip: "点按钮后直接执行；表格/PPT/报表完成后自动放到桌面，并把结果写回办公库。" } },
        { title: "下一步", actions: nextActions || [] }
      ]
    };
  }

  getAICodingWorkflowConfig(title, page, processName, desc, fields, actions, nextActions) {
    return {
      compact: true,
      kicker: "AI编程",
      title,
      desc,
      sideTitle: "对应流程",
      sideText: processName,
      sections: [
        { title: "输入信息", note: "填必要信息后启动", runner: { name: page, fields: fields.filter((f) => f.type !== "textarea"), wideFields: fields.filter((f) => f.type === "textarea"), actions, tip: "会自动发送到山竹智能体执行。" } },
        { title: "下一步", actions: nextActions || [] }
      ]
    };
  }

  getSelfMediaWorkflowConfig(title, page, processName, desc, fields, actions, nextActions) {
    return {
      compact: true,
      kicker: "自媒体",
      title,
      desc,
      sideTitle: "对应流程",
      sideText: processName,
      sections: [
        { title: "输入信息", note: "填必要信息后启动", runner: { name: page, fields: fields.filter((f) => f.type !== "textarea"), wideFields: fields.filter((f) => f.type === "textarea"), actions, tip: "会自动发送到山竹智能体执行。" } },
        { title: "下一步", actions: nextActions || [] }
      ]
    };
  }

  getFormWorkflowConfig(title, page, skill, desc, fields, actions, nextActions, extraSections) {
    return {
      compact: true,
      kicker: "短视频带货",
      title,
      desc,
      sideTitle: "对应 Skill",
      sideText: skill,
      sections: [
        { title: "输入信息", note: "填必要信息后启动", runner: { name: page, fields: fields.filter((f) => f.type !== "textarea"), wideFields: fields.filter((f) => f.type === "textarea"), actions, tip: "会自动发送到山竹智能体执行。" } },
        ...(extraSections || []),
        { title: "下一步", actions: nextActions || [] }
      ]
    };
  }

  getNovelWorkflowConfig(title, page, processName, desc, fields, actions, nextActions, extraSections) {
    const nextConfig = Array.isArray(nextActions) ? { actions: nextActions } : (nextActions || { actions: [] });
    const nextSection = { title: "下一步", actions: nextConfig.actions || [] };
    if (Object.prototype.hasOwnProperty.call(nextConfig, "statusSourcePath")) {
      nextSection.note = nextConfig.statusSourcePath
        ? "当前环节：已完成。确认无误后，可以进入下一步。"
        : "当前环节：未完成。先跑完上面的按钮，再进入下一步。";
    }
    return {
      compact: true,
      kicker: "写小说",
      title,
      desc,
      sideTitle: "对应流程",
      sideText: processName,
      sections: [
        { title: "输入信息", note: "填必要信息后启动", runner: { name: page, fields: fields.filter((f) => f.type !== "textarea"), wideFields: fields.filter((f) => f.type === "textarea"), actions, tip: "会自动发送到山竹智能体执行。" } },
        ...(extraSections || []),
        nextSection
      ]
    };
  }


}

function getWorkflowDisplayName(label, workflow) {
  const normalized = String(label || "").replace(/\s+/g, " ").trim();
  if (normalized && normalized.length <= 40) return normalized;
  return workflow ? String(workflow).replace(/[-_]+/g, " ") : "执行当前任务";
}

function createWorkflowCatalog(queries = {}) {
  const catalog = new WorkflowCatalog(queries);
  return {
    getModules: () => getEnabledBusinessModules(),
    getPageConfig: (page, context = {}) => catalog.getWorkflowPageConfig(page, context),
    getDisplayName: getWorkflowDisplayName
  };
}

module.exports = {
  createWorkflowCatalog,
  getWorkflowDisplayName,
  normalizeWorkflowInput,
  buildWorkflowTask
};
