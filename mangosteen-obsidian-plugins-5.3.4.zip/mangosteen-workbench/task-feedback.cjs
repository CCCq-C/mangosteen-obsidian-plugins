const ACTIVE_STATUSES = new Set(["preparing", "submitted", "running"]);
const HUMAN_HANDOFF_WORKFLOWS = new Set([
  "platform-product-mining",
  "showcase-confirm-add",
  "ai-video-submit-confirm"
]);
const LONG_WAIT_MS = 8 * 60 * 1000;
const PREPARING_TIMEOUT_MS = 45 * 1000;

const PROJECT_WORKFLOWS = {
  "novel-project-create": {
    paramKeys: ["项目名", "项目名 / 小说名"],
    root: "森雪赚AI工作台知识库/写小说/作品项目",
    controlFile: "00-项目总控.md",
    kind: "小说项目"
  },
  "ai-coding-project-create": {
    paramKeys: ["项目名"],
    root: "森雪赚AI工作台知识库/AI编程/项目库",
    controlFile: "00-项目总控.md",
    kind: "AI 编程项目"
  },
  "office-project-create": {
    paramKeys: ["项目名称", "项目名"],
    root: "森雪赚AI工作台知识库/日常办公/项目库",
    controlFile: "00-项目总览.md",
    kind: "办公项目"
  }
};

function isTaskActive(task) {
  return ACTIVE_STATUSES.has(String(task?.status || ""));
}

function findLatestWorkflowTask(tasks, workflow) {
  return (Array.isArray(tasks) ? tasks : [])
    .filter((task) => task?.workflow === workflow)
    .sort((a, b) => Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0))[0] || null;
}

function safePathExists(pathExists, value) {
  if (!value || typeof pathExists !== "function") return false;
  try {
    return Boolean(pathExists(value));
  } catch (_) {
    return false;
  }
}

function cleanProjectName(value) {
  return String(value || "")
    .trim()
    .replace(/[\\/:*?"<>|]+/g, "-")
    .replace(/\s+/g, " ")
    .replace(/[. ]+$/g, "");
}

function getTaskParam(task, keys) {
  const wanted = new Set(keys || []);
  const match = (Array.isArray(task?.params) ? task.params : [])
    .find((item) => wanted.has(String(item?.key || "").trim()));
  return String(match?.value || "").trim();
}

function getProjectSpec(task) {
  const config = PROJECT_WORKFLOWS[task?.workflow];
  if (!config) return null;
  const projectName = cleanProjectName(getTaskParam(task, config.paramKeys));
  if (!projectName) return null;
  return {
    ...config,
    projectName,
    expectedPath: `${config.root}/${projectName}/${config.controlFile}`
  };
}

function findVerifiedResult(task, options = {}) {
  const pathExists = options.pathExists;
  for (const item of Array.isArray(task?.outputPaths) ? task.outputPaths : []) {
    const candidate = String(item?.resolvedPath || item?.path || "");
    if (candidate && (item?.exists === true || safePathExists(pathExists, candidate))) return candidate;
  }
  const project = getProjectSpec(task);
  if (project && safePathExists(pathExists, project.expectedPath)) return project.expectedPath;
  return "";
}

function buildTaskFeedback(task, options = {}) {
  const status = String(task?.status || "");
  const now = Number(options.now || Date.now());
  const active = isTaskActive(task);
  const verifiedResult = findVerifiedResult(task, options);
  const waitedFrom = Number(task?.updatedAt || task?.submittedAt || task?.createdAt || now);
  const waitedTooLong = active && now - waitedFrom >= LONG_WAIT_MS;
  const longWaitText = waitedTooLong
    ? "等待时间较长，可打开 AI 查看是否需要你确认。"
    : "";

  if (!["failed", "interrupted"].includes(status) && verifiedResult) {
    return {
      tone: "ready",
      label: "结果已生成，可以继续",
      detail: "已检测到真实结果文件，点击即可继续。",
      active: false,
      ready: true,
      canRetry: false,
      action: "open-result",
      actionLabel: "打开结果",
      resultPath: verifiedResult
    };
  }

  if (status === "failed") {
    return {
      tone: "failed",
      label: "任务未完成",
      detail: String(task?.error || "AI 任务没有成功启动，请检查 AI 对话后重新提交。"),
      active: false,
      ready: false,
      canRetry: true,
      action: "open-ai",
      actionLabel: "查看 AI",
      resultPath: ""
    };
  }

  if (status === "interrupted") {
    const interruptedByError = task?.interruptionReason === "error";
    return {
      tone: "interrupted",
      label: interruptedByError ? "AI 因错误中断" : "AI 已由你中断",
      detail: interruptedByError
        ? "Claudian 因错误停止了本次生成；请打开 AI 查看错误信息，修正后重新提交。"
        : "这次生成没有完成；你可以修改要求后重新提交，或打开 AI 查看已产生的部分内容。",
      active: false,
      ready: false,
      canRetry: true,
      action: "open-ai",
      actionLabel: "查看 AI",
      resultPath: ""
    };
  }

  if (status === "completed") {
    return {
      tone: "responded",
      label: "AI 已回复，请检查右侧结果",
      detail: "AI 已结束本轮回复；如果结果需要保存，请先在右侧确认文件路径。",
      active: false,
      ready: false,
      canRetry: false,
      action: "open-ai",
      actionLabel: "查看 AI",
      resultPath: ""
    };
  }

  if (status === "preparing" && now - waitedFrom >= PREPARING_TIMEOUT_MS) {
    return {
      tone: "interrupted",
      label: "上次启动未完成，可以重新提交",
      detail: "AI 对话没有完成接收；请检查右侧 AI 后重新点击原按钮。",
      active: false,
      ready: false,
      canRetry: true,
      action: "open-ai",
      actionLabel: "查看 AI",
      resultPath: ""
    };
  }

  if (active && HUMAN_HANDOFF_WORKFLOWS.has(String(task?.workflow || ""))) {
    return {
      tone: "waiting-user",
      label: "等待你登录或确认",
      detail: longWaitText || "这一步需要你在浏览器或 AI 对话中完成登录、确认或验证码。",
      active: true,
      ready: false,
      canRetry: false,
      action: "open-ai",
      actionLabel: "查看 AI",
      resultPath: ""
    };
  }

  const states = {
    preparing: ["preparing", "正在启动 AI", "正在准备任务并连接 AI 对话。"],
    submitted: ["submitted", "任务已提交，等待 AI 接收", "任务已发出，你可以继续浏览其他页面。"],
    running: ["running", "AI 正在处理", "AI 正在后台执行，你可以继续使用工作台。"]
  };
  const [tone, label, defaultDetail] = states[status] || ["unknown", "正在读取任务状态", "可打开 AI 对话查看当前情况。"];
  return {
    tone,
    label,
    detail: longWaitText || defaultDetail,
    active,
    ready: false,
    canRetry: false,
    action: active ? "open-ai" : "",
    actionLabel: active ? "查看 AI" : "",
    resultPath: ""
  };
}

function shouldLockTask(task, options = {}) {
  if (!task) return false;
  return buildTaskFeedback(task, options).active;
}

function getProjectPlaceholder(task, options = {}) {
  const project = getProjectSpec(task);
  if (!project || safePathExists(options.pathExists, project.expectedPath)) return null;
  const feedback = buildTaskFeedback(task, options);
  return {
    taskId: task.id,
    workflow: task.workflow,
    projectName: project.projectName,
    projectKind: project.kind,
    expectedPath: project.expectedPath,
    pending: true,
    feedback
  };
}

function collectProjectPlaceholders(tasks, workflow, options = {}) {
  const seen = new Set();
  const placeholders = [];
  const ordered = (Array.isArray(tasks) ? tasks : [])
    .filter((task) => task?.workflow === workflow)
    .sort((a, b) => Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0));
  for (const task of ordered) {
    const placeholder = getProjectPlaceholder(task, options);
    if (!placeholder || seen.has(placeholder.expectedPath)) continue;
    seen.add(placeholder.expectedPath);
    placeholders.push(placeholder);
  }
  return placeholders;
}

module.exports = {
  buildTaskFeedback,
  collectProjectPlaceholders,
  findLatestWorkflowTask,
  getProjectPlaceholder,
  isTaskActive,
  shouldLockTask
};
