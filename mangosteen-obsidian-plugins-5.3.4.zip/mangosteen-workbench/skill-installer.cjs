const pathModule = require("path");

function normalizeSkillTarget(value) {
  return String(value || "").toLowerCase() === "codex" ? "codex" : "claude";
}

function resolveSkillRoot(target, context = {}) {
  if (normalizeSkillTarget(target) === "codex") {
    return pathModule.join(String(context.homeDir || ""), ".codex", "skills");
  }
  return pathModule.join(String(context.vaultPath || ""), ".claude", "skills");
}

function isValidSkillSlug(slug) {
  return /^[A-Za-z0-9][A-Za-z0-9_-]{1,120}$/.test(String(slug || ""));
}

function isSkillInstalled(slug, target, context = {}) {
  if (!isValidSkillSlug(slug) || typeof context.pathExists !== "function") return false;
  const root = resolveSkillRoot(target, context);
  return Boolean(context.pathExists(pathModule.join(root, slug, "SKILL.md")));
}

function deployPreparedSkill(options = {}) {
  const slug = String(options.slug || "");
  if (!isValidSkillSlug(slug)) throw new Error("Skill 标识无效，无法安装");
  const system = options.system;
  if (!system) throw new Error("安装所需的系统能力不可用");
  const sourceDir = pathModule.resolve(String(options.sourceDir || ""));
  if (!system.pathExists(pathModule.join(sourceDir, "SKILL.md"))) {
    throw new Error("压缩包中未读取到 SKILL.md");
  }

  const target = normalizeSkillTarget(options.target);
  const root = pathModule.resolve(resolveSkillRoot(target, {
    vaultPath: options.vaultPath,
    homeDir: options.homeDir
  }));
  const targetDir = pathModule.resolve(root, slug);
  if (!targetDir.startsWith(root + pathModule.sep)) throw new Error("安装路径越界，已停止");

  const stamp = typeof options.now === "function" ? options.now() : Date.now();
  const stageRoot = pathModule.join(root, ".senxue-staging");
  const stageDir = pathModule.join(stageRoot, `${slug}-${stamp}`);
  const backupRoot = pathModule.join(root, ".senxue-backups");
  let backupDir = "";

  system.makeDirectory(stageRoot);
  if (system.pathExists(stageDir)) system.removePath(stageDir, { recursive: true });
  system.copyDirectory(sourceDir, stageDir);
  if (!system.pathExists(pathModule.join(stageDir, "SKILL.md"))) {
    system.removePath(stageDir, { recursive: true });
    throw new Error("Skill 暂存验证失败");
  }

  try {
    if (system.pathExists(targetDir)) {
      system.makeDirectory(backupRoot);
      backupDir = pathModule.join(backupRoot, `${slug}-${stamp}`);
      if (system.pathExists(backupDir)) system.removePath(backupDir, { recursive: true });
      system.renamePath(targetDir, backupDir);
    }
    system.renamePath(stageDir, targetDir);
  } catch (error) {
    if (backupDir && !system.pathExists(targetDir) && system.pathExists(backupDir)) {
      system.renamePath(backupDir, targetDir);
    }
    throw error;
  } finally {
    if (system.pathExists(stageDir)) system.removePath(stageDir, { recursive: true });
  }

  return { target, targetDir, backupDir };
}

module.exports = {
  normalizeSkillTarget,
  resolveSkillRoot,
  isSkillInstalled,
  deployPreparedSkill
};
