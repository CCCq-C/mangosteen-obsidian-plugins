function createSystemError(code, message, cause) {
  const error = new Error(message);
  error.name = "SystemAdapterError";
  error.code = code;
  if (cause) error.cause = cause;
  return error;
}

function optionalRequire(name) {
  try {
    return require(name);
  } catch (_) {
    return null;
  }
}

function createSystemAdapter(options = {}) {
  const fs = options.fs || require("fs");
  const path = options.path || require("path");
  const os = options.os || require("os");
  const childProcess = options.childProcess || require("child_process");
  const electron = Object.prototype.hasOwnProperty.call(options, "electron")
    ? options.electron
    : optionalRequire("electron");
  const requestUrl = options.requestUrl;
  const windowRef = options.windowRef || globalThis.window;

  function pathExists(value) {
    return Boolean(value && fs.existsSync(value));
  }

  function readText(value) {
    return fs.readFileSync(value, "utf8");
  }

  function writeFile(value, data) {
    fs.writeFileSync(value, data);
  }

  function makeDirectory(value) {
    fs.mkdirSync(value, { recursive: true });
  }

  function removePath(value, removeOptions = {}) {
    fs.rmSync(value, { force: true, ...removeOptions });
  }

  function readDirectory(value, readOptions = {}) {
    return fs.readdirSync(value, readOptions);
  }

  function stat(value) {
    return fs.statSync(value);
  }

  function copyFile(source, destination) {
    fs.copyFileSync(source, destination);
  }

  function copyDirectory(source, destination) {
    makeDirectory(destination);
    for (const entry of readDirectory(source, { withFileTypes: true })) {
      const from = path.join(source, entry.name);
      const to = path.join(destination, entry.name);
      if (entry.isDirectory()) copyDirectory(from, to);
      else if (entry.isFile()) copyFile(from, to);
    }
  }

  function renamePath(source, destination) {
    fs.renameSync(source, destination);
  }

  function homeDirectory() {
    return os.homedir();
  }

  function temporaryDirectory() {
    return os.tmpdir();
  }

  function resolveDialog() {
    return electron?.remote?.dialog || electron?.dialog || null;
  }

  async function pickPath(dialogOptions = {}) {
    const dialog = resolveDialog();
    if (typeof dialog?.showOpenDialog !== "function") {
      throw createSystemError("UNAVAILABLE", "Native file picker is unavailable");
    }
    return dialog.showOpenDialog(dialogOptions);
  }

  async function openPath(value) {
    if (!pathExists(value)) throw createSystemError("NOT_FOUND", `Path does not exist: ${value}`);
    if (typeof electron?.shell?.openPath !== "function") {
      throw createSystemError("UNAVAILABLE", "Native path opening is unavailable");
    }
    const message = await electron.shell.openPath(value);
    if (message) throw createSystemError("OPEN_FAILED", message);
    return true;
  }

  async function openExternal(url) {
    if (typeof electron?.shell?.openExternal === "function") {
      await electron.shell.openExternal(url);
      return true;
    }
    if (typeof windowRef?.open === "function") {
      windowRef.open(url, "_blank", "noopener");
      return true;
    }
    throw createSystemError("UNAVAILABLE", "External URL opening is unavailable");
  }

  function getPathForFile(file) {
    if (typeof electron?.webUtils?.getPathForFile === "function") {
      return electron.webUtils.getPathForFile(file);
    }
    return file?.path || file?.webkitRelativePath || file?.name || "";
  }

  function execute(command, args = [], executeOptions = {}) {
    if (!command || !Array.isArray(args)) {
      return Promise.reject(createSystemError("INVALID_COMMAND", "Command and argument array are required"));
    }
    return new Promise((resolve, reject) => {
      childProcess.execFile(command, args, executeOptions, (error, stdout, stderr) => {
        if (error) {
          reject(createSystemError("EXEC_FAILED", stderr || error.message, error));
          return;
        }
        resolve({ stdout: stdout || "", stderr: stderr || "" });
      });
    });
  }

  function spawnDetached(command, args = [], spawnOptions = {}) {
    const child = childProcess.spawn(command, args, {
      detached: true,
      stdio: "ignore",
      windowsHide: false,
      ...spawnOptions
    });
    child.unref?.();
    return child;
  }

  async function request(requestOptions) {
    if (typeof requestUrl !== "function") {
      throw createSystemError("UNAVAILABLE", "Obsidian request API is unavailable");
    }
    return requestUrl(requestOptions);
  }

  return {
    pathExists,
    readText,
    writeFile,
    makeDirectory,
    removePath,
    readDirectory,
    stat,
    copyFile,
    copyDirectory,
    renamePath,
    homeDirectory,
    temporaryDirectory,
    pickPath,
    openPath,
    openExternal,
    getPathForFile,
    execute,
    spawnDetached,
    request
  };
}

module.exports = { createSystemAdapter };
