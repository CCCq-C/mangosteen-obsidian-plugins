const { Plugin, MarkdownView, Notice, TFile, requestUrl, Modal } = require("obsidian");
const pathModule = require("path");
let createClaudianAdapter;
let validateWorkflowParams;
let normalizeTaskStore;
let createTaskRecord;
let updateTaskRecord;
let createConversationSignature;
let buildConversationTrend;
let assertFunctionContract;
let createResourceScope;
let createLatestRefreshCoordinator;
let createWorkflowCatalog;
let buildWorkflowTask;
let createSystemAdapter;
let createDashboardService;
let splitResourcePaths;
let getResourceDisplayName;
let filterResourceOptions;
let buildTaskFeedback;
let collectProjectPlaceholders;
let findLatestWorkflowTask;
let shouldLockTask;
let normalizeSkillTarget;
let isSkillInstalled;
let deployPreparedSkill;
let findVaultFile;
let getVaultBasePath;
let resolvePluginRoot;

const WORKBENCH_FILE = "00-山竹智能体.md";
const WORKBENCH_KNOWLEDGE_ROOT = "山竹智能体知识库";
const CONVERSATION_POLL_INTERVAL_MS = 1500;
const TASK_START_RECHECK_MS = 46 * 1000;
const STANDBY_TEXT = "暂无最新结果";
const FORCE_PREVIEW_FILES = new Set([
  WORKBENCH_FILE,
  "山竹智能体知识库/00-工作台使用说明.md",
  "山竹智能体知识库/00-使用问题解答.md",
  "山竹智能体知识库/AI编程/00-入口.md",
  "山竹智能体知识库/AI编程/01-新建项目.md",
  "山竹智能体知识库/AI编程/02-描述我的想法.md",
  "山竹智能体知识库/AI编程/03-AI帮我拆功能.md",
  "山竹智能体知识库/AI编程/04-生成第一个版本.md",
  "山竹智能体知识库/AI编程/05-试用并反馈问题.md",
  "山竹智能体知识库/AI编程/06-修改和优化.md",
  "山竹智能体知识库/AI编程/07-添加新功能.md",
  "山竹智能体知识库/AI编程/08-打包发布交付.md",
  "山竹智能体知识库/00-Skill市场.md",
  "山竹智能体知识库/IP内容生产/00-入口.md",
  "山竹智能体知识库/IP内容生产/01-学习爆款方法.md",
  "山竹智能体知识库/IP内容生产/02-选择内容类型.md",
  "山竹智能体知识库/IP内容生产/03-脚本模板与写作.md",
  "山竹智能体知识库/IP内容生产/04-三秒钩子优化.md",
  "山竹智能体知识库/IP内容生产/05-发布后数据复盘.md",
  "山竹智能体知识库/IP内容生产/06-我的脚本工坊.md",
  "山竹智能体知识库/短视频带货/00-入口.md",
  "山竹智能体知识库/短视频带货/内容形式判断/00-内容形式判断.md",
  "山竹智能体知识库/短视频带货/产品脚本/00-带货脚本分镜.md",
  "山竹智能体知识库/短视频带货/制作视频/00-制作视频.md",
  "山竹智能体知识库/短视频带货/平台找品/00-平台自动找品.md",
  "山竹智能体知识库/短视频带货/AI选品评分/00-AI选品评分.md",
  "山竹智能体知识库/短视频带货/选品记录/00-选品记录.md",
  "山竹智能体知识库/写小说/00-入口.md",
  "山竹智能体知识库/AI出图/80-图生图.md"
]);

const PLATFORM_CDP_DOMAINS = {
  "senxue-buyin": ["buyin.jinritemai.com", "douyinec.com"],
  "senxue-chanmama": ["chanmama.com"],
  "senxue-alimama": ["alimama.com"]
};

class SenxueResourcePickerModal extends Modal {
  constructor(app, options = {}) {
    super(app);
    this.options = options;
  }

  onOpen() {
    this.modalEl.addClass("senxue-resource-picker-modal");
    this.contentEl.empty();
    this.contentEl.createEl("h2", { text: "添加材料" });
    this.contentEl.createEl("p", {
      cls: "senxue-resource-picker-intro",
      text: "只显示材料名称，选择后会自动保存完整路径。"
    });

    const sourceActions = this.contentEl.createDiv({ cls: "senxue-resource-source-actions" });
    if (this.options.allowFile) {
      this.addSourceButton(sourceActions, "选择本机文件", async () => {
        await this.options.onPickFile?.();
      });
    }
    if (this.options.allowFolder) {
      this.addSourceButton(sourceActions, "选择本机文件夹", async () => {
        await this.options.onPickFolder?.();
      });
    }

    if (!this.options.allowNote) return;
    this.contentEl.createEl("h3", { text: "搜索工作台笔记" });
    const search = this.contentEl.createEl("input", {
      cls: "senxue-resource-search",
      attr: {
        type: "search",
        placeholder: "输入笔记或文件夹名称",
        "aria-label": "搜索工作台笔记"
      }
    });
    const status = this.contentEl.createDiv({
      cls: "senxue-resource-search-status",
      text: "至少输入 2 个字符后显示结果"
    });
    const results = this.contentEl.createDiv({ cls: "senxue-resource-results" });

    const renderResults = () => {
      const query = search.value.trim();
      results.empty();
      if (query.length < 2) {
        status.setText("至少输入 2 个字符后显示结果");
        return;
      }
      const matches = this.options.searchNotes?.(query) || [];
      status.setText(matches.length ? `找到 ${matches.length} 项` : "没有找到匹配材料");
      for (const item of matches) {
        const result = results.createEl("button", { cls: "senxue-resource-result" });
        result.type = "button";
        result.title = item.path;
        result.createEl("span", {
          cls: "senxue-resource-result-name",
          text: getResourceDisplayName(item.path)
        });
        result.createEl("small", {
          text: item.type === "folder" ? "文件夹" : "笔记"
        });
        result.addEventListener("click", () => {
          this.options.onSelectNote?.(item.path);
          this.close();
        });
      }
    };
    search.addEventListener("input", renderResults);
    search.focus();
  }

  addSourceButton(parent, text, handler) {
    const button = parent.createEl("button", { text });
    button.type = "button";
    button.addEventListener("click", async () => {
      await handler();
      this.close();
    });
  }

  onClose() {
    this.contentEl.empty();
  }
}

class SenxueTaskConfirmModal extends Modal {
  constructor(app, details) {
    super(app);
    this.details = details || {};
    this.settled = false;
    this.result = new Promise((resolve) => {
      this.resolveResult = resolve;
    });
  }

  openAndWait() {
    this.open();
    return this.result;
  }

  finish(approved) {
    if (this.settled) return;
    this.settled = true;
    this.resolveResult(Boolean(approved));
    this.close();
  }

  onOpen() {
    this.modalEl.addClass("senxue-task-confirm-modal");
    this.contentEl.empty();
    this.contentEl.createEl("h2", { text: "开始前确认一下" });
    this.contentEl.createEl("p", {
      cls: "senxue-confirm-intro",
      text: "确认资料和结果位置没有问题，再让 AI 开始执行。"
    });

    this.addSummary("你要做什么", this.details.title || "执行当前任务");
    const params = (this.details.params || []).filter((item) => item.value);
    const inputText = params.length
      ? params.map((item) => `${item.key}：${item.value}`).join("\n")
      : "本页没有额外填写内容，AI 会按当前工作流规则执行。";
    this.addSummary("AI 将读取什么", inputText, "senxue-confirm-inputs");
    this.addSummary(
      "完成后去哪里找",
      this.details.expectedOutput || "AI 完成后会在结果中告诉你保存位置"
    );

    const advanced = this.contentEl.createEl("details", { cls: "senxue-confirm-details" });
    advanced.createEl("summary", { text: "查看详细指令" });
    advanced.createEl("pre", {
      cls: "senxue-confirm-prompt",
      text: this.details.prompt || ""
    });

    const actions = this.contentEl.createDiv({ cls: "senxue-confirm-actions" });
    const backButton = actions.createEl("button", { text: "返回修改" });
    backButton.type = "button";
    backButton.addEventListener("click", () => this.finish(false));
    const startButton = actions.createEl("button", {
      cls: "mod-cta",
      text: "开始执行"
    });
    startButton.type = "button";
    startButton.addEventListener("click", () => this.finish(true));
  }

  addSummary(label, text, cls = "") {
    const block = this.contentEl.createDiv({
      cls: `senxue-confirm-summary ${cls}`.trim()
    });
    block.createEl("strong", { text: label });
    block.createEl("div", { text: text || "--" });
  }

  onClose() {
    if (!this.settled) {
      this.settled = true;
      this.resolveResult(false);
    }
    this.contentEl.empty();
  }
}

module.exports = class SenxueWorkbenchStartup extends Plugin {
  async onload() {
    const adapter = this.app?.vault?.adapter;
    const initialBasePath = adapter?.getBasePath?.() || adapter?.basePath;
    const initialHelperRoot = initialBasePath
      ? pathModule.join(initialBasePath, ...String(this.manifest.dir || "").replaceAll("\\", "/").split("/").filter(Boolean))
      : "";
    if (!initialHelperRoot) {
      throw new Error("无法定位山竹智能体工作台插件目录，工作台插件未加载");
    }
    ({ findVaultFile, getVaultBasePath, resolvePluginRoot } = require(pathModule.join(initialHelperRoot, "vault-path.cjs")));
    const basePath = getVaultBasePath(adapter);
    if (!basePath) {
      throw new Error("无法定位 Obsidian 仓库路径，工作台插件未加载");
    }
    const helperRoot = resolvePluginRoot(basePath, this.manifest.dir);
    const helperFiles = [
      "runtime-core.cjs",
      "workbench-runtime-v3.cjs",
      "claudian-bridge.cjs",
      "task-store.cjs",
      "workflow-model.cjs",
      "workflow-catalog.cjs",
      "system-adapter.cjs",
      "dashboard-model.cjs",
      "dashboard-service.cjs",
      "resource-picker-model.cjs",
      "task-feedback.cjs",
      "skill-installer.cjs",
      "vault-path.cjs"
    ];
    for (const fileName of helperFiles) {
      const modulePath = pathModule.join(helperRoot, fileName);
      try {
        delete require.cache[require.resolve(modulePath)];
      } catch (_) {}
    }
    const runtimeCorePath = pathModule.join(helperRoot, "runtime-core.cjs");
    ({
      assertFunctionContract,
      createResourceScope,
      createLatestRefreshCoordinator
    } = require(runtimeCorePath));
    assertFunctionContract({
      assertFunctionContract,
      createResourceScope,
      createLatestRefreshCoordinator
    }, [
      "assertFunctionContract",
      "createResourceScope",
      "createLatestRefreshCoordinator"
    ], "workbench runtime core");
    const helperPath = pathModule.join(helperRoot, "workbench-runtime-v3.cjs");
    const helpers = require(helperPath);
    assertFunctionContract(helpers, [
      "resolveClaudianIntegration",
      "getActiveClaudianTab",
      "getActiveClaudianInput",
      "waitForValue",
      "dispatchExplicitSend",
      "createClaudianAdapter",
      "validateWorkflowParams",
      "inferExpectedOutput",
      "normalizeTaskStore",
      "createTaskRecord",
      "updateTaskRecord",
      "applyTaskSnapshot",
      "extractOutputPaths",
      "collectLocalConversationSnapshot",
      "createConversationSignature",
      "buildConversationMetrics",
      "buildConversationTrend"
    ], "workbench runtime helpers");
    ({
      createClaudianAdapter,
      validateWorkflowParams,
      normalizeTaskStore,
      createTaskRecord,
      updateTaskRecord,
      createConversationSignature,
      buildConversationTrend
    } = helpers);
    const workflowCatalogPath = pathModule.join(helperRoot, "workflow-catalog.cjs");
    const workflowCatalogModule = require(workflowCatalogPath);
    assertFunctionContract(workflowCatalogModule, [
      "createWorkflowCatalog",
      "buildWorkflowTask"
    ], "workbench workflow catalog");
    ({ createWorkflowCatalog, buildWorkflowTask } = workflowCatalogModule);
    const systemAdapterPath = pathModule.join(helperRoot, "system-adapter.cjs");
    const systemAdapterModule = require(systemAdapterPath);
    assertFunctionContract(systemAdapterModule, ["createSystemAdapter"], "workbench system adapter");
    ({ createSystemAdapter } = systemAdapterModule);
    const skillInstallerPath = pathModule.join(helperRoot, "skill-installer.cjs");
    const skillInstallerModule = require(skillInstallerPath);
    assertFunctionContract(skillInstallerModule, [
      "normalizeSkillTarget",
      "isSkillInstalled",
      "deployPreparedSkill"
    ], "workbench skill installer");
    ({ normalizeSkillTarget, isSkillInstalled, deployPreparedSkill } = skillInstallerModule);
    const resourcePickerModelPath = pathModule.join(helperRoot, "resource-picker-model.cjs");
    const resourcePickerModel = require(resourcePickerModelPath);
    assertFunctionContract(resourcePickerModel, [
      "splitResourcePaths",
      "getResourceDisplayName",
      "filterResourceOptions"
    ], "workbench resource picker model");
    ({ splitResourcePaths, getResourceDisplayName, filterResourceOptions } = resourcePickerModel);
    const dashboardServicePath = pathModule.join(helperRoot, "dashboard-service.cjs");
    const dashboardServiceModule = require(dashboardServicePath);
    assertFunctionContract(dashboardServiceModule, ["createDashboardService"], "workbench dashboard service");
    ({ createDashboardService } = dashboardServiceModule);
    const taskFeedbackPath = pathModule.join(helperRoot, "task-feedback.cjs");
    const taskFeedbackModule = require(taskFeedbackPath);
    assertFunctionContract(taskFeedbackModule, [
      "buildTaskFeedback",
      "collectProjectPlaceholders",
      "findLatestWorkflowTask",
      "shouldLockTask"
    ], "workbench task feedback");
    ({
      buildTaskFeedback,
      collectProjectPlaceholders,
      findLatestWorkflowTask,
      shouldLockTask
    } = taskFeedbackModule);

    this.lastConversationSignature = "";
    this.refreshScheduleVersion = 0;
    this.workflowPreviewScheduleVersion = 0;
    this.runtimeScope = createResourceScope({
      setTimeoutFn: window.setTimeout.bind(window),
      clearTimeoutFn: window.clearTimeout.bind(window)
    });
    this.systemAdapter = createSystemAdapter({ requestUrl, windowRef: window });
    this.claudianAdapter = createClaudianAdapter({
      app: this.app,
      documentRef: document,
      platform: navigator.platform || "",
      sleep: (ms) => this.runtimeScope.sleep(ms)
    });
    this.workflowCatalog = createWorkflowCatalog({
      findLatestWorkflowSourcePath: (prefixes) => this.findLatestWorkflowSourcePath(prefixes),
      collectNovelProjectProgress: (projectPath, projectTitle) => (
        this.collectNovelProjectProgress(projectPath, projectTitle)
      ),
      collectProductHistoryOptions: (limit) => this.collectProductHistoryOptions(limit)
    });
    this.dashboardRefresh = createLatestRefreshCoordinator({
      run: (request) => this.performDashboardRefresh(request),
      onCommitted: (signature) => {
        this.lastConversationSignature = signature;
      },
      onError: (error) => {
        console.warn("Senxue workbench: dashboard refresh coordinator failed", error);
      }
    });
    this.conversationTrendDays = 7;
    this.expandedKnowledgePaths = new Set();
    this.collapsedKnowledgePaths = new Set();
    this.pluginData = await this.loadData() || {};
    this.workbenchTasks = normalizeTaskStore(this.pluginData.workbenchTasks);
    this.notifiedTaskIds = new Set();
    this.taskSaveChain = Promise.resolve();
    this.dashboardService = createDashboardService({
      claudian: this.claudianAdapter,
      system: this.systemAdapter,
      basePath,
      getTasks: () => this.workbenchTasks,
      saveTasks: async (tasks) => {
        const previousTasks = this.workbenchTasks;
        const nextTasks = normalizeTaskStore(tasks);
        this.notifyCompletedTasks(previousTasks, nextTasks);
        this.workbenchTasks = nextTasks;
        await this.persistWorkbenchTasks();
      },
      collectKnowledge: () => this.collectKnowledgeData()
    });
    this.resetClaudianInputHeight();
    this.removeLegacyUsageFloat();
    this.addCommand({
      id: "open-senxue-workbench",
      name: "打开山竹智能体工作台",
      callback: () => this.openWorkbench(false),
    });
    this.addCommand({
      id: "refresh-senxue-workbench-data",
      name: "刷新山竹智能体工作台数据",
      callback: () => this.refreshDashboard(true),
    });

    this.registerEvent(this.app.workspace.on("layout-change", () => {
      this.scheduleRefresh();
      this.scheduleWorkflowPreviewMode();
      this.runtimeScope.timeout(() => this.disableDashboardCardPreviews(document), 50);
    }));
    this.registerEvent(this.app.workspace.on("active-leaf-change", () => {
      this.scheduleWorkflowPreviewMode();
      this.runtimeScope.timeout(() => this.disableDashboardCardPreviews(document), 50);
    }));
    this.registerEvent(this.app.workspace.on("file-open", () => {
      this.scheduleWorkflowPreviewMode();
      this.runtimeScope.timeout(() => this.disableDashboardCardPreviews(document), 50);
    }));
    this.registerInterval(window.setInterval(
      () => this.pollConversationChanges(),
      CONVERSATION_POLL_INTERVAL_MS
    ));
    this.registerDomEvent(document, "click", (event) => this.handleDashboardAction(event));
    this.registerMarkdownCodeBlockProcessor("senxue-workflow", (source, el) => this.renderWorkflowCodeBlock(source, el));

    this.app.workspace.onLayoutReady(() => {
      if (this.runtimeScope.disposed) return;
      this.runtimeScope.timeout(() => this.openWorkbench(true), 700);
      this.runtimeScope.timeout(() => this.refreshDashboard(false), 1200);
      this.runtimeScope.timeout(() => this.refreshDashboard(false), 2600);
      this.runtimeScope.timeout(() => this.scheduleWorkflowPreviewMode(), 900);
      this.runtimeScope.timeout(() => this.disableDashboardCardPreviews(document), 1000);
    });
  }

  onunload() {
    this.dashboardRefresh?.dispose();
    this.runtimeScope?.dispose();
    this.resetClaudianInputHeight();
    this.removeLegacyUsageFloat();
  }

  renderWorkflowCodeBlock(source, el) {
    el.replaceChildren();
    const block = this.parseWorkflowBlockOptions(source);
    const page = block.page || this.parseWorkflowBlockPage(source);
    const config = this.workflowCatalog.getPageConfig(page, block);
    if (!config) {
      const empty = document.createElement("div");
      empty.className = "workflow-shell";
      empty.textContent = `未配置的功能页面：${page || "unknown"}`;
      el.appendChild(empty);
      return;
    }

    const root = document.createElement("div");
    root.className = `workflow-shell workflow-render ${config.compact ? "workflow-compact-page" : ""}`.trim();
    this.renderWorkflowHero(root, config);
    for (const section of config.sections || []) this.renderWorkflowSection(root, section);
    el.appendChild(root);
    this.refreshWorkflowTaskFeedback();
  }

  parseWorkflowBlockPage(source) {
    const match = String(source || "").match(/(?:^|\n)\s*page\s*:\s*([^\n]+)/i);
    return (match?.[1] || "short-video-home").trim();
  }

  parseWorkflowBlockOptions(source) {
    const options = {};
    String(source || "").split(/\r?\n/).forEach((line) => {
      const match = line.match(/^\s*([A-Za-z0-9_\-]+)\s*:\s*(.+?)\s*$/);
      if (!match) return;
      options[match[1].trim()] = match[2].trim();
    });
    return options;
  }

  renderWorkflowHero(root, config) {
    const hero = this.createEl("div", "workflow-hero compact");
    const main = document.createElement("div");
    this.createEl("div", "workflow-kicker", config.kicker || "短视频带货", main);
    this.createEl("h1", "", config.title || "功能链路", main);
    if (config.desc) this.createEl("p", "", config.desc, main);
    hero.appendChild(main);

    if (config.sideProgress) {
      hero.appendChild(this.createNovelProgressPanel(config.sideProgress));
    } else if (config.sideTitle || config.sideText) {
      const side = this.createEl("div", "workflow-safe-card");
      this.createEl("strong", "", config.sideTitle || "使用方式", side);
      this.createEl("span", "", config.sideText || "", side);
      hero.appendChild(side);
    }
    root.appendChild(hero);
  }

  renderWorkflowSection(root, section) {
    const title = this.createEl("div", "workflow-section-title");
    this.createEl("span", "", section.title || "", title);
    if (section.note) this.createEl("em", "", section.note, title);
    root.appendChild(title);

    if (section.platforms) {
      const row = this.createEl("div", "workflow-platform-row");
      for (const platform of section.platforms) row.appendChild(this.createWorkflowButton(platform));
      root.appendChild(row);
    }

    if (section.runner) root.appendChild(this.createWorkflowRunner(section.runner));

    if (section.cards) {
      const grid = this.createEl("div", `workflow-grid ${section.gridClass || ""}`.trim());
      for (const card of section.cards) grid.appendChild(this.createWorkflowCard(card));
      root.appendChild(grid);
    }

    if (section.novelProjects) root.appendChild(this.createNovelProjectGrid(section));

    if (section.novelActiveNodes) root.appendChild(this.createNovelActiveNodeGrid(section.novelActiveNodes));

    if (section.aiCodingProjects) root.appendChild(this.createAICodingProjectGrid(section));

    if (section.officeProjectPlaceholders) root.appendChild(this.createOfficeProjectPlaceholderGrid());

    if (section.novelChapterLibrary) root.appendChild(this.createNovelChapterLibrary(section.novelChapterLibrary));

    if (section.knowledgeLinks) root.appendChild(this.createWorkflowKnowledgeLinks(section.knowledgeLinks));

    if (section.skillMarket) root.appendChild(this.createSkillMarketPanel(section.skillMarket));

    if (section.actions) {
      const row = this.createEl("div", "workflow-platform-row");
      for (const action of section.actions) row.appendChild(this.createWorkflowButton(action));
      root.appendChild(row);
    }
  }

  createWorkflowCard(card) {
    const node = this.createEl("div", `workflow-card workflow-tap-card ${card.primary ? "primary" : ""} ${card.accent ? "accent" : ""} ${card.className || ""}`.trim());
    if (card.openPath) node.setAttribute("data-senxue-open-path", card.openPath);
    if (card.action) node.setAttribute("data-senxue-action", card.action);
    if (card.pendingProject) node.setAttribute("data-senxue-pending-project", "true");
    if (card.workflow) node.setAttribute("data-senxue-workflow", card.workflow);
    if (card.autosend) node.setAttribute("data-senxue-autosend", "true");
    if (card.collectParams) node.setAttribute("data-senxue-collect-params", "true");
    const stepText = (card.step || "").toString().trim();
    if (stepText && !/^\d+$/.test(stepText)) this.createEl("span", "workflow-step", stepText, node);
    this.createEl("h2", "", card.title || "", node);
    if (card.desc) this.createEl("p", "", card.desc, node);
    if (card.prep) {
      const prep = this.createEl("div", "workflow-prep");
      this.createEl("strong", "", "先做：", prep);
      prep.appendChild(document.createTextNode(card.prep));
      node.appendChild(prep);
    }
    node.appendChild(this.createWorkflowButton({
      text: card.button || "进入",
      openPath: card.openPath,
      action: card.action,
      workflow: card.workflow,
      autosend: card.autosend,
      collectParams: card.collectParams
    }));
    return node;
  }

  createNovelProjectGrid() {
    const projects = this.collectNovelProjects();
    const grid = this.createEl("div", "workflow-grid novel-project-grid");
    if (!projects.length) {
      grid.appendChild(this.createWorkflowCard({
        step: "未开始",
        title: "还没有小说项目",
        desc: "先新建一个项目。以后每次进入写小说第二页，都会先从这里选择正在写的小说。",
        prep: "新建后会生成项目总控页、世界观、人设、大纲、正文和质检页。",
        button: "新建小说项目",
        openPath: "山竹智能体知识库/写小说/作品项目/00-新建小说项目.md",
        primary: true
      }));
      return grid;
    }

    projects.forEach((project, index) => {
      const status = project.status || "未标记状态";
      const stage = project.stage || project.currentChapter || "未标记阶段";
      const updated = project.updated ? `最近更新：${project.updated}` : "最近更新：未读取到";
      grid.appendChild(this.createWorkflowCard({
        step: status,
        title: `${project.title} - ${project.currentNodeLabel || "继续写作"}`,
        desc: `当前板块：${project.currentNodeLabel || stage} · ${updated}`,
        prep: project.summary || "进入项目总控页后，围绕这本小说继续写，不会从零开始。",
        button: "继续完成",
        openPath: project.currentNodePath || project.path,
        primary: index === 0
      }));
    });
    return grid;
  }

  createNovelActiveNodeGrid(config = {}) {
    const items = this.collectNovelActiveNodes(config.limit || 8);
    const placeholders = collectProjectPlaceholders(this.workbenchTasks, "novel-project-create", {
      pathExists: (value) => this.workbenchPathExists(value)
    });
    const limit = Number(config.limit || 8);
    const grid = this.createEl("div", "workflow-grid novel-active-node-grid");
    grid.setAttribute("data-senxue-novel-active-grid", "true");
    grid.setAttribute("data-senxue-novel-active-limit", String(limit));
    if (config.empty) grid.setAttribute("data-senxue-empty-text", config.empty);
    if (!items.length && !placeholders.length) {
      grid.appendChild(this.createWorkflowCard({
        step: "待开始",
        title: "还没有继续节点",
        desc: config.empty || "先跑一次找爆款，或新建一个小说项目。",
        prep: "后续会在这里显示：项目名 - 当前板块。",
        button: "去新建项目",
        openPath: "山竹智能体知识库/写小说/作品项目/00-新建小说项目.md",
        primary: true
      }));
      return grid;
    }

    placeholders.slice(0, limit).forEach((placeholder) => {
      grid.appendChild(this.createPendingProjectCard(placeholder));
    });
    items.slice(0, Math.max(0, limit - placeholders.length)).forEach((item, index) => {
      grid.appendChild(this.createWorkflowCard({
        step: "继续",
        title: `${item.projectName} - ${item.nodeLabel}`,
        desc: `当前板块：${item.nodeLabel} · ${item.updated ? `最近更新：${item.updated}` : "最近更新：未读取到"}`,
        prep: item.summary || "点击直接回到这个项目当前节点继续完成。",
        button: "继续完成",
        openPath: item.openPath,
        primary: index === 0,
        accent: index === 0
      }));
    });
    return grid;
  }


  createAICodingProjectGrid() {
    const projects = this.collectAICodingProjects();
    const placeholders = collectProjectPlaceholders(this.workbenchTasks, "ai-coding-project-create", {
      pathExists: (value) => this.workbenchPathExists(value)
    });
    const grid = this.createEl("div", "workflow-grid ai-coding-project-grid");
    grid.setAttribute("data-senxue-ai-coding-project-grid", "true");
    if (!projects.length && !placeholders.length) {
      grid.appendChild(this.createWorkflowCard({
        step: "",
        title: "还没有 AI 编程项目",
        desc: "先新建一个项目。以后每次进入 AI 编程库，都可以从这里继续开发。",
        prep: "新建后会生成项目总控、需求说明、功能拆解、试用修改、发布交付和复盘页。",
        button: "新建项目",
        openPath: "山竹智能体知识库/AI编程/01-新建项目.md",
        primary: true
      }));
      return grid;
    }

    placeholders.forEach((placeholder) => {
      grid.appendChild(this.createPendingProjectCard(placeholder));
    });
    projects.forEach((project, index) => {
      const status = project.status || "项目";
      const stage = project.stage || "持续开发";
      const updated = project.updated ? "最近更新：" + project.updated : "最近更新：未读取到";
      grid.appendChild(this.createWorkflowCard({
        step: "",
        title: project.title,
        desc: stage + " · " + updated,
        prep: project.summary || "进入项目总控页后，围绕这个项目继续说需求、做第一版、试用修改和交付。",
        button: "继续开发",
        openPath: project.path,
        primary: index === 0
      }));
    });
    return grid;
  }

  createOfficeProjectPlaceholderGrid() {
    const placeholders = collectProjectPlaceholders(this.workbenchTasks, "office-project-create", {
      pathExists: (value) => this.workbenchPathExists(value)
    });
    const grid = this.createEl("div", "workflow-grid office-project-placeholder-grid");
    grid.setAttribute("data-senxue-office-project-grid", "true");
    grid.hidden = placeholders.length === 0;
    placeholders.forEach((placeholder) => {
      grid.appendChild(this.createPendingProjectCard(placeholder));
    });
    return grid;
  }

  createPendingProjectCard(placeholder, options = {}) {
    const feedback = placeholder.feedback || {};
    return this.createWorkflowCard({
      step: feedback.tone === "failed" ? "需处理" : "生成中",
      title: `${placeholder.projectName} · ${placeholder.projectKind}`,
      desc: feedback.label || "AI 正在创建项目",
      prep: feedback.detail || "项目生成完成后，这张卡会自动变成可继续的真实项目。",
      button: feedback.actionLabel || "查看 AI",
      action: "open-ai",
      className: `is-pending is-${feedback.tone || "submitted"}`,
      pendingProject: true,
      primary: Boolean(options.primary)
    });
  }

  notifyCompletedTasks(previousTasks, nextTasks) {
    const previousById = new Map((previousTasks || []).map((task) => [task.id, task]));
    for (const task of nextTasks || []) {
      const previous = previousById.get(task.id);
      if (task.status !== "completed" || previous?.status === "completed" || this.notifiedTaskIds.has(task.id)) continue;
      this.notifiedTaskIds.add(task.id);
      const feedback = buildTaskFeedback(task, {
        pathExists: (value) => this.workbenchPathExists(value)
      });
      new Notice(feedback.ready ? "AI 任务已完成，结果已生成" : "AI 已回复，请检查右侧结果");
    }
  }

  refreshWorkflowTaskFeedback() {
    for (const runner of document.querySelectorAll(".workflow-runner[data-senxue-runner]")) {
      const workflow = runner.getAttribute("data-senxue-runner") || "";
      const task = findLatestWorkflowTask(this.workbenchTasks, workflow);
      const active = shouldLockTask(task, {
        pathExists: (value) => this.workbenchPathExists(value)
      });
      for (const button of runner.querySelectorAll("[data-senxue-autosend='true'][data-senxue-workflow]")) {
        button.disabled = active;
        button.setAttribute("aria-busy", active ? "true" : "false");
      }
      const host = runner.querySelector("[data-senxue-task-feedback]");
      if (host) this.renderWorkflowTaskFeedback(host, task);
    }
  }

  renderWorkflowTaskFeedback(host, task) {
    host.replaceChildren();
    if (!task) {
      host.hidden = true;
      host.removeAttribute("data-tone");
      return;
    }
    const feedback = buildTaskFeedback(task, {
      pathExists: (value) => this.workbenchPathExists(value)
    });
    host.hidden = false;
    host.setAttribute("data-tone", feedback.tone);
    const icon = this.createEl("span", "workflow-task-status-icon", "", host);
    icon.setAttribute("aria-hidden", "true");
    if (feedback.active) icon.classList.add("is-spinning");
    const copy = this.createEl("div", "workflow-task-status-copy", "", host);
    this.createEl("strong", "", feedback.label, copy);
    this.createEl("span", "", feedback.detail, copy);
    if (feedback.action === "open-result" && feedback.resultPath) {
      const isVaultPath = feedback.resultPath.startsWith(`${WORKBENCH_KNOWLEDGE_ROOT}/`);
      host.appendChild(this.createWorkflowButton({
        text: feedback.actionLabel,
        openPath: isVaultPath ? feedback.resultPath : "",
        resultPath: isVaultPath ? "" : feedback.resultPath,
        secondary: true
      }));
    } else if (feedback.action === "open-ai") {
      host.appendChild(this.createWorkflowButton({
        text: feedback.actionLabel,
        action: "open-ai",
        secondary: true
      }));
    }
  }

  refreshProjectPlaceholderGrids() {
    for (const grid of Array.from(document.querySelectorAll("[data-senxue-novel-active-grid='true']"))) {
      grid.replaceWith(this.createNovelActiveNodeGrid({
        limit: Number(grid.getAttribute("data-senxue-novel-active-limit") || 8),
        empty: grid.getAttribute("data-senxue-empty-text") || ""
      }));
    }
    for (const grid of Array.from(document.querySelectorAll("[data-senxue-ai-coding-project-grid='true']"))) {
      grid.replaceWith(this.createAICodingProjectGrid());
    }
    for (const grid of Array.from(document.querySelectorAll("[data-senxue-office-project-grid='true']"))) {
      grid.replaceWith(this.createOfficeProjectPlaceholderGrid());
    }
  }

  workbenchPathExists(value) {
    const candidate = String(value || "").replace(/\\/g, "/");
    if (!candidate) return false;
    if (!pathModule.isAbsolute(candidate) && this.app.vault.getAbstractFileByPath(candidate)) return true;
    const basePath = this.app?.vault?.adapter?.basePath || "";
    const resolved = pathModule.isAbsolute(candidate) ? candidate : pathModule.join(basePath, candidate);
    return Boolean(resolved && this.systemAdapter.pathExists(resolved));
  }

  createNovelProgressPanel(progress = {}) {
    const panel = this.createEl("div", "workflow-safe-card workflow-project-progress");
    this.createEl("strong", "", "创作进度总览", panel);
    this.createEl("span", "workflow-project-path", progress.projectPath || "未绑定项目路径", panel);

    const stats = this.createEl("div", "workflow-progress-stats");
    const statItems = [
      ["正文章数", `${progress.chapterCount || 0} 章`],
      ["累计字数", progress.totalChars ? `约 ${this.formatNumber(progress.totalChars)} 字` : "未统计"],
      ["最新章节", progress.latestChapter?.title || "暂无正文"]
    ];
    for (const [label, value] of statItems) {
      const item = this.createEl("div", "workflow-progress-stat");
      this.createEl("em", "", label, item);
      this.createEl("b", "", value, item);
      stats.appendChild(item);
    }
    panel.appendChild(stats);

    if (progress.latestChapter?.summary) {
      const summary = this.createEl("div", "workflow-progress-summary");
      this.createEl("em", "", "本章大概内容", summary);
      this.createEl("span", "", progress.latestChapter.summary, summary);
      panel.appendChild(summary);
    }

    const actions = this.createEl("div", "workflow-progress-actions");
    actions.appendChild(this.createWorkflowButton({
      text: "打开文章库",
      openPath: `${progress.projectPath || ""}/章节正文/00-章节目录.md`,
      secondary: true
    }));
    if (progress.latestChapter?.path) {
      actions.appendChild(this.createWorkflowButton({
        text: "打开最新章节",
        openPath: progress.latestChapter.path
      }));
    }
    panel.appendChild(actions);
    return panel;
  }

  createNovelChapterLibrary(progress = {}) {
    const grid = this.createEl("div", "workflow-grid novel-chapter-library");
    const chapters = progress.chapters || [];
    if (!chapters.length) {
      grid.appendChild(this.createWorkflowCard({
        step: "暂无",
        title: "还没有正文",
        desc: "写完第一章后，会自动出现在这里。",
        prep: "先进入正文续写页，围绕当前项目继续写。",
        button: "继续写正文",
        openPath: `${progress.projectPath || ""}/04-正文续写.md`,
        primary: true
      }));
      return grid;
    }

    for (const chapter of chapters) grid.appendChild(this.createNovelChapterCard(chapter));
    return grid;
  }

  createNovelChapterCard(chapter) {
    const node = this.createEl("div", "workflow-card workflow-tap-card workflow-chapter-card");
    if (chapter.path) node.setAttribute("data-senxue-open-path", chapter.path);
    this.createEl("span", "workflow-step", chapter.chapterLabel || "章节", node);
    this.createEl("h2", "", chapter.title || chapter.basename || "未命名章节", node);
    this.createEl("p", "", chapter.summary || "未填写章节概要；打开正文可查看具体内容。", node);
    const meta = this.createEl("small", "", `${chapter.charCount ? `约 ${this.formatNumber(chapter.charCount)} 字` : "字数未统计"} · ${chapter.updated ? `更新 ${chapter.updated}` : "未读取更新时间"}`);
    node.appendChild(meta);
    node.appendChild(this.createWorkflowButton({
      text: "打开本章",
      openPath: chapter.path
    }));
    return node;
  }

  collectNovelProjectProgress(projectPath, projectTitle) {
    const normalizedProjectPath = String(projectPath || "").replace(/\\/g, "/").replace(/\/$/, "");
    const chapters = this.collectNovelChapters(normalizedProjectPath);
    const latestChapter = chapters.at(-1) || null;
    return {
      projectTitle,
      projectPath: normalizedProjectPath,
      chapterCount: chapters.length,
      totalChars: chapters.reduce((sum, chapter) => sum + (chapter.charCount || 0), 0),
      latestChapter,
      chapters
    };
  }

  collectNovelChapters(projectPath) {
    if (!projectPath) return [];
    const chapterPrefix = `${projectPath}/章节正文/`;
    return this.app.vault.getFiles()
      .filter((file) => file.extension === "md" && file.path.startsWith(chapterPrefix) && file.name !== "00-章节目录.md")
      .map((file) => this.buildNovelChapterRecord(file))
      .sort((a, b) => {
        const chapterDiff = (a.chapterNumber || 9999) - (b.chapterNumber || 9999);
        if (chapterDiff !== 0) return chapterDiff;
        return (a.path || "").localeCompare(b.path || "");
      });
  }

  buildNovelChapterRecord(file) {
    const cache = this.app.metadataCache.getFileCache(file) || {};
    const frontmatter = cache.frontmatter || {};
    const text = this.readVaultFileTextSync(file);
    const body = this.stripFrontmatter(text);
    const title = frontmatter.title || this.extractMarkdownTitle(body) || file.basename;
    const summary = frontmatter.summary || this.extractChapterSummary(body);
    const chapterNumber = Number(frontmatter.chapter || this.extractChapterNumber(title) || this.extractChapterNumber(file.basename) || 0);
    const updated = frontmatter.updated || this.dateKey(new Date(file.stat?.mtime || Date.now()));
    const charCount = this.countDraftChars(body);
    return {
      path: file.path,
      basename: file.basename,
      title: String(title).replace(/^第\s*\d+\s*章\s*/, (match) => match.trim() + " "),
      summary,
      chapterNumber,
      chapterLabel: chapterNumber ? `第${chapterNumber}章` : "正文",
      updated,
      charCount
    };
  }

  readVaultFileTextSync(file) {
    const basePath = this.app.vault.adapter?.basePath;
    if (!basePath || !file?.path) return "";
    try {
      return this.systemAdapter.readText(pathModule.join(basePath, file.path));
    } catch (_) {
      return "";
    }
  }

  stripFrontmatter(text) {
    return String(text || "").replace(/^---[\s\S]*?---\s*/, "");
  }

  extractMarkdownTitle(text) {
    const match = String(text || "").match(/^#\s+(.+?)\s*$/m);
    return match?.[1] || "";
  }

  extractChapterNumber(text) {
    const match = String(text || "").match(/第\s*(\d+)\s*章|^(\d+)[-_]/);
    return Number(match?.[1] || match?.[2] || 0);
  }

  extractChapterSummary(text) {
    const clean = String(text || "")
      .replace(/^#\s+.+$/gm, "")
      .replace(/^##\s+(正文草稿|承接说明|下一章钩子|建议保存文件名)\s*$/gm, "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("```") && !line.startsWith("- ") && !line.startsWith("|"));
    const first = clean.find((line) => !/^第?\d/.test(line)) || clean[0] || "";
    return this.clipText(first, 86);
  }

  countDraftChars(text) {
    const draft = String(text || "").split(/^##\s+承接说明\s*$/m)[0] || "";
    return Array.from(draft.replace(/^#+\s+.+$/gm, "").replace(/\s+/g, "")).length;
  }

  clipText(text, limit) {
    const chars = Array.from(String(text || "").trim());
    if (chars.length <= limit) return chars.join("");
    return `${chars.slice(0, limit).join("")}…`;
  }

  createWorkflowKnowledgeLinks(config = {}) {
    const wrap = this.createEl("div", "workflow-runner workflow-knowledge-links");
    const files = this.collectWorkflowKnowledgeFiles(config);
    if (!files.length) {
      const empty = this.createEl("div", "workflow-prep");
      this.createEl("strong", "", "暂无沉淀：", empty);
      empty.appendChild(document.createTextNode(config.empty || "还没有读取到已归档内容。跑完一次后会自动出现在这里。"));
      wrap.appendChild(empty);
      return wrap;
    }

    const list = this.createEl("div", "workflow-platform-row");
    files.forEach((file, index) => {
      list.appendChild(this.createWorkflowButton({
        text: file.label,
        openPath: file.path,
        secondary: index !== 0,
        accent: index === 0
      }));
    });
    wrap.appendChild(list);
    return wrap;
  }

  collectWorkflowKnowledgeFiles(config = {}) {
    if (config.productNamesOnly) return this.collectProductNameKnowledgeFiles(config);
    const prefixes = (config.prefixes || [])
      .map((prefix) => String(prefix || "").replace(/\\/g, "/"))
      .filter(Boolean)
      .map((prefix) => prefix.endsWith("/") ? prefix : `${prefix}/`);
    const limit = Number(config.limit || 8);
    if (!prefixes.length) return [];
    return this.app.vault.getFiles()
      .filter((file) => {
        if (file.extension !== "md") return false;
        if (!prefixes.some((prefix) => file.path.startsWith(prefix))) return false;
        if (config.excludeIndex !== false && /^00-/.test(file.name)) return false;
        return true;
      })
      .sort((a, b) => (b.stat?.mtime || 0) - (a.stat?.mtime || 0))
      .slice(0, limit)
      .map((file) => ({
        path: config.resolveNovelExecution ? this.resolveNovelExecutionPath(file.path) : file.path,
        label: file.basename.length > 22 ? `${file.basename.slice(0, 22)}…` : file.basename
      }));
  }

  resolveNovelExecutionPath(path) {
    const normalized = String(path || "").replace(/\\/g, "/");
    if (normalized.includes("/仿写爆款/")) return "山竹智能体知识库/写小说/作品项目/00-作品项目初始化.md";
    if (normalized.includes("/找爆款/")) return "山竹智能体知识库/写小说/仿写爆款/00-仿写爆款.md";
    if (normalized.includes("/作品项目/") && normalized.endsWith("/00-项目总控.md")) return normalized;
    if (normalized.includes("/作品项目/")) return "山竹智能体知识库/写小说/作品项目/00-作品项目初始化.md";
    return normalized;
  }

  collectNovelProjects() {
    const prefix = "山竹智能体知识库/写小说/作品项目/";
    const suffix = "/00-项目总控.md";
    return this.app.vault.getFiles()
      .filter((file) => file.path.startsWith(prefix) && file.path.endsWith(suffix))
      .map((file) => {
        const folder = file.path.slice(prefix.length, -suffix.length);
        const projectPath = `${prefix}${folder}`;
        const frontmatter = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
        const title = frontmatter.title || frontmatter.project || folder || file.basename;
        const updated = frontmatter.updated || frontmatter.modified || this.dateKey(new Date(file.stat?.mtime || Date.now()));
        const current = this.resolveNovelProjectCurrentNode(projectPath, frontmatter);
        return {
          title: String(title).replace(/\s*·?\s*项目总控$/, ""),
          path: file.path,
          projectPath,
          status: frontmatter.status || "项目",
          stage: frontmatter.stage || frontmatter.current_stage || "",
          currentChapter: frontmatter.current_chapter || frontmatter.chapter || "",
          currentNodeLabel: current.label,
          currentNodePath: current.path,
          updated,
          summary: frontmatter.summary || frontmatter.desc || ""
        };
      })
      .sort((a, b) => String(b.updated || "").localeCompare(String(a.updated || "")));
  }

  resolveNovelProjectCurrentNode(projectPath, frontmatter = {}) {
    const explicitPath = frontmatter.current_node_path || frontmatter.currentNodePath || frontmatter.next_node_path || "";
    const explicitLabel = frontmatter.current_node || frontmatter.currentNode || frontmatter.next_node || "";
    if (explicitPath || explicitLabel) {
      return {
        label: explicitLabel || this.labelNovelNodeByPath(explicitPath) || "继续写作",
        path: explicitPath || `${projectPath}/${this.fileNameForNovelNode(explicitLabel)}`
      };
    }
    const stage = String(frontmatter.stage || frontmatter.current_stage || frontmatter.status || "");
    if (/质检|润色/.test(stage)) return { label: "质检润色", path: `${projectPath}/06-质检润色.md` };
    if (/正文|章节|续写/.test(stage)) return { label: "正文续写", path: `${projectPath}/05-正文续写.md` };
    if (/大纲|卷纲/.test(stage)) return { label: "大纲规划", path: `${projectPath}/04-大纲规划.md` };
    if (/人设|人物|角色/.test(stage)) return { label: "人设关系", path: `${projectPath}/03-人设关系.md` };
    if (/世界观|设定/.test(stage)) return { label: "世界观设定", path: `${projectPath}/02-世界观设定.md` };
    return { label: "世界观设定", path: `${projectPath}/02-世界观设定.md` };
  }

  labelNovelNodeByPath(path) {
    const normalized = String(path || "");
    if (/01-爆款参考/.test(normalized)) return "爆款参考";
    if (/02-世界观/.test(normalized)) return "世界观设定";
    if (/03-人设/.test(normalized)) return "人设关系";
    if (/04-大纲/.test(normalized)) return "大纲规划";
    if (/05-正文/.test(normalized)) return "正文续写";
    if (/06-质检/.test(normalized)) return "质检润色";
    if (/仿写爆款/.test(normalized)) return "仿写爆款";
    if (/找爆款/.test(normalized)) return "找爆款";
    return "";
  }

  fileNameForNovelNode(label) {
    const text = String(label || "");
    if (/爆款/.test(text)) return "01-爆款参考与仿写.md";
    if (/世界观/.test(text)) return "02-世界观设定.md";
    if (/人设|人物|角色/.test(text)) return "03-人设关系.md";
    if (/大纲|卷纲/.test(text)) return "04-大纲规划.md";
    if (/正文|续写|章节/.test(text)) return "05-正文续写.md";
    if (/质检|润色/.test(text)) return "06-质检润色.md";
    return "00-项目总控.md";
  }

  collectNovelActiveNodes(limit = 8) {
    const projectItems = this.collectNovelProjects().map((project) => ({
      projectName: project.title,
      nodeLabel: project.currentNodeLabel || "继续写作",
      openPath: project.currentNodePath || project.path,
      status: project.status || "项目",
      updated: project.updated,
      summary: project.summary || project.stage || "点击直接回到当前创作节点。"
    }));

    const artifactItems = this.app.vault.getFiles()
      .filter((file) => file.extension === "md" && (
        file.path.startsWith("山竹智能体知识库/写小说/找爆款/") ||
        file.path.startsWith("山竹智能体知识库/写小说/仿写爆款/")
      ) && !/^00-/.test(file.name))
      .map((file) => {
        const fm = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
        if (!(fm.project || fm.project_name || fm["项目名"] || fm.current_node || fm.current_node_path)) return null;
        const projectName = fm.project || fm.project_name || fm["项目名"] || this.inferNovelProjectNameFromFile(file.basename);
        const fromMining = file.path.includes("/找爆款/");
        return {
          projectName,
          nodeLabel: fm.current_node || (fromMining ? "仿写爆款" : "项目初始化"),
          openPath: fm.current_node_path || (fromMining ? "山竹智能体知识库/写小说/仿写爆款/00-仿写爆款.md" : "山竹智能体知识库/写小说/作品项目/00-作品项目初始化.md"),
          status: "前期",
          updated: fm.updated || this.dateKey(new Date(file.stat?.mtime || Date.now())),
          summary: fm.summary || `来源：${file.basename}`
        };
      })
      .filter(Boolean);

    const seen = new Set();
    return [...projectItems, ...artifactItems]
      .filter((item) => {
        const key = `${item.projectName}-${item.nodeLabel}-${item.openPath}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, Number(limit) || 8);
  }

  inferNovelProjectNameFromFile(name) {
    const clean = String(name || "").replace(/^\d{4}-\d{2}-\d{2}-/, "");
    const parts = clean.split(/[-_—]/).filter(Boolean);
    return parts.length ? parts[parts.length - 1].replace(/(仿写方案|热度榜|TOP\d+|爆款报告)$/g, "") || clean : clean;
  }

  collectProductNameKnowledgeFiles(config = {}) {
    const prefixes = (config.prefixes || [])
      .map((prefix) => String(prefix || "").replace(/\\/g, "/"))
      .filter(Boolean)
      .map((prefix) => prefix.endsWith("/") ? prefix : `${prefix}/`);
    const limit = Number(config.limit || 12);
    if (!prefixes.length) return [];
    const seen = new Set();
    const items = [];
    this.app.vault.getFiles()
      .filter((file) => file.extension === "md" && !/^00-/.test(file.name) && prefixes.some((prefix) => file.path.startsWith(prefix)))
      .sort((a, b) => (b.stat?.mtime || 0) - (a.stat?.mtime || 0))
      .forEach((file) => {
        const names = this.extractProductNamesFromText(this.readVaultFileTextSync(file));
        names.forEach((name) => {
          const label = this.cleanProductHistoryLabel(name);
          if (!label || seen.has(label) || items.length >= limit) return;
          seen.add(label);
          items.push({ path: file.path, label });
        });
      });
    return items;
  }

  extractProductNamesFromText(text) {
    const body = this.stripFrontmatter(text || "");
    const names = [];
    const pushName = (value) => {
      const cleaned = this.cleanProductHistoryLabel(value);
      if (cleaned && !names.includes(cleaned)) names.push(cleaned);
    };
    const tableRe = /^\|\s*\d+\s*\|\s*(?:\[([^\]]{2,})\]\([^)]+\)|([^|]+?))\s*\|/gm;
    let match;
    while ((match = tableRe.exec(body))) pushName(match[1] || match[2]);
    const boldRe = /^\s*\d+[\.、]\s*\*\*([^*]{2,80})\*\*/gm;
    while ((match = boldRe.exec(body))) pushName(match[1]);
    const fieldRe = /(?:商品名|商品名称|产品名|产品名称)[:：]\s*([^\n|，,]{2,80})/g;
    while ((match = fieldRe.exec(body))) pushName(match[1]);
    return names;
  }

  cleanProductHistoryLabel(value) {
    let text = String(value || "")
      .replace(/\[[^\]]*\]\(([^)]*)\)/g, "")
      .replace(/[*_`#>]/g, "")
      .replace(/<[^>]+>/g, "")
      .replace(/^\d{4}-\d{2}-\d{2}-\d{4}-?/, "")
      .replace(/^(TOP\s*\d+|序号\s*\d+|\d+)[、.\s-]*/i, "")
      .replace(/\s+/g, " ")
      .trim();
    text = text.replace(/\s*(AI选品评分|平台找品原始数据|内容形式判断|短视频脚本|制作视频|老板汇报)$/g, "").trim();
    if (!text || /^(商品|产品|候选商品|不建议原因|结论|未读取到)$/.test(text)) return "";
    return text.length > 18 ? `${text.slice(0, 18)}…` : text;
  }
  collectProductHistoryOptions(limit = 30) {
    const prefixes = [
      "山竹智能体知识库/短视频带货/选品记录/",
      "山竹智能体知识库/短视频带货/AI选品评分/"
    ];
    const seen = new Set();
    const items = [];
    this.app.vault.getFiles()
      .filter((file) => file.extension === "md" && !/^00-/.test(file.name) && prefixes.some((prefix) => file.path.startsWith(prefix)))
      .sort((a, b) => (b.stat?.mtime || 0) - (a.stat?.mtime || 0))
      .forEach((file) => {
        this.extractProductNamesFromText(this.readVaultFileTextSync(file)).forEach((name) => {
          const label = this.cleanProductHistoryLabel(name);
          if (!label || seen.has(label) || items.length >= (Number(limit) || 30)) return;
          seen.add(label);
          items.push(label);
        });
      });
    return items.length ? items : ["暂无历史选品商品，先跑AI选品评分"];
  }

  collectAICodingProjects() {
    const prefix = "山竹智能体知识库/AI编程/项目库/";
    const suffixes = ["/00-项目总控.md", "/00-项目总控页.md", "/00-项目.md"];
    const files = this.app.vault.getFiles()
      .filter((file) => file.extension === "md" && file.path.startsWith(prefix));
    const projectFiles = files.filter((file) => suffixes.some((suffix) => file.path.endsWith(suffix)));
    const source = projectFiles.length ? projectFiles : files.filter((file) => /00-|项目总控|项目/.test(file.name));
    return source.map((file) => {
        const folder = file.path.slice(prefix.length).split("/")[0] || file.basename;
        const frontmatter = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
        const title = frontmatter.title || frontmatter.project || folder || file.basename;
        const updated = frontmatter.updated || frontmatter.modified || this.dateKey(new Date(file.stat?.mtime || Date.now()));
        return {
          title: String(title).replace(/\s*·?\s*项目总控$/, ""),
          path: file.path,
          status: frontmatter.status || "项目",
          stage: frontmatter.stage || frontmatter.current_stage || "持续开发",
          updated,
          summary: frontmatter.summary || frontmatter.desc || ""
        };
      })
      .sort((a, b) => String(b.updated || "").localeCompare(String(a.updated || "")));
  }

  findLatestWorkflowSourcePath(prefixes) {
    const normalized = (prefixes || [])
      .map((prefix) => String(prefix || "").replace(/\\/g, "/"))
      .filter(Boolean)
      .map((prefix) => prefix.endsWith("/") ? prefix : `${prefix}/`);
    if (!normalized.length) return "";
    const files = this.app.vault.getFiles()
      .filter((file) => {
        if (file.extension !== "md") return false;
        if (!normalized.some((prefix) => file.path.startsWith(prefix))) return false;
        if (/^00-/.test(file.name)) return false;
        if (/\/00-[^/]+\.md$/i.test(file.path)) return false;
        return true;
      })
      .sort((a, b) => (b.stat?.mtime || 0) - (a.stat?.mtime || 0));
    return files[0]?.path || normalized[0];
  }

  createWorkflowRunner(runner) {
    const wrap = this.createEl("div", "workflow-runner");
    if (runner.name) wrap.setAttribute("data-senxue-runner", runner.name);
    if (runner.fields?.length) {
      const grid = this.createEl("div", "workflow-form-grid");
      for (const field of runner.fields) grid.appendChild(this.createWorkflowField(field));
      wrap.appendChild(grid);
    }
    for (const field of runner.wideFields || []) wrap.appendChild(this.createWorkflowField(field, true));
    if (runner.actions?.length) {
      const actions = this.createEl("div", "workflow-run-actions");
      for (const action of runner.actions) actions.appendChild(this.createWorkflowButton({ ...action, collectParams: action.collectParams ?? true }));
      if (runner.tip) this.createEl("span", "", runner.tip, actions);
      wrap.appendChild(actions);
      const resultHint = this.createEl(
        "div",
        "workflow-result-hint",
        "提交后，下方会显示 AI 进度；完成后可查看右侧回复或直接打开结果。"
      );
      wrap.appendChild(resultHint);
    }
    const statusHost = this.createEl("div", "workflow-task-status");
    statusHost.setAttribute("data-senxue-task-feedback", "true");
    statusHost.hidden = true;
    wrap.appendChild(statusHost);
    this.bindWorkflowFormPersistence(wrap, runner.name || "workflow");
    this.bindWorkflowSourceSync(wrap);
    this.runtimeScope.timeout(() => this.refreshWorkflowTaskFeedback(), 0);
    return wrap;
  }

  createWorkflowField(field, wide) {
    const label = this.createEl("label", wide ? "workflow-wide-label" : "");
    const fieldLabel = field.label || field.param || "参数";
    const labelHead = this.createEl("span", "workflow-field-label");
    this.createEl("span", "workflow-field-name", fieldLabel, labelHead);
    const markerText = field.required === true ? "必填" : (field.requiredGroup ? "至少填一项" : "选填");
    const markerClass = field.required === true || field.requiredGroup ? " is-required" : "";
    this.createEl("small", `workflow-field-marker${markerClass}`, markerText, labelHead);
    label.appendChild(labelHead);
    let input;
    if (field.type === "select") {
      input = document.createElement("select");
      for (const option of field.options || []) {
        const opt = document.createElement("option");
        opt.value = typeof option === "string" ? option : option.value;
        opt.textContent = typeof option === "string" ? option : option.label;
        if (typeof option !== "string" && option.selected) opt.selected = true;
        input.appendChild(opt);
      }
    } else if (field.type === "textarea") {
      input = document.createElement("textarea");
    } else {
      input = document.createElement("input");
    }
    input.setAttribute("data-senxue-param", field.param || field.label || "参数");
    if (field.required === true) input.setAttribute("data-senxue-required", "true");
    if (field.requiredGroup) input.setAttribute("data-senxue-required-group", field.requiredGroup);
    if (field.pathKind) input.setAttribute("data-senxue-path-kind", field.pathKind);
    const placeholder = field.placeholder || (field.type !== "select" ? `请填写${fieldLabel}` : "");
    if (placeholder) input.setAttribute("placeholder", placeholder);
    if (field.value) input.value = field.value;
    if (field.sourceDefaultPath) input.setAttribute("data-senxue-source-default", field.sourceDefaultPath);
    if (field.sourceSelect) input.setAttribute("data-senxue-source-select", "true");
    if (field.sourcePathField) input.setAttribute("data-senxue-source-path", "true");
    input.addEventListener("input", () => {
      input.classList.remove("is-invalid");
      input.closest?.(".workflow-resource-picker")?.classList.remove("is-invalid");
    });
    const usesResourcePicker = field.sourcePathField || field.notePicker || field.filePicker;
    if (usesResourcePicker) {
      input.type = "hidden";
      if (field.notePicker || field.sourcePathField) input.setAttribute("data-senxue-note-picker", "true");
      if (field.filePicker) input.setAttribute("data-senxue-file-picker-input", "true");
      label.appendChild(this.createWorkflowResourcePicker(input, field));
      return label;
    }
    label.appendChild(input);
    return label;
  }

  createWorkflowResourcePicker(input, field = {}) {
    const row = this.createEl("div", "workflow-resource-picker is-empty");
    row.setAttribute("data-senxue-resource-mode", "all");
    row.setAttribute("data-senxue-allow-note", field.notePicker || field.sourcePathField ? "true" : "false");
    row.setAttribute("data-senxue-allow-file", field.filePicker ? "true" : "false");
    row.setAttribute("data-senxue-allow-folder", field.filePicker && field.allowFolder !== false ? "true" : "false");
    row.appendChild(input);

    this.createEl("div", "workflow-resource-selection", "未添加材料", row);
    const actions = this.createEl("div", "workflow-resource-actions", "", row);
    const openButton = this.createEl("button", "workflow-picker-button", "添加材料", actions);
    openButton.type = "button";
    openButton.setAttribute("data-senxue-resource-open", "true");
    openButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.openWorkflowResourcePicker(input, field);
    });
    const clearButton = this.createEl("button", "workflow-picker-button secondary", "清除", actions);
    clearButton.type = "button";
    clearButton.setAttribute("data-senxue-resource-clear", "true");
    clearButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.setWorkflowResourcePaths(input, []);
    });
    input.addEventListener("input", () => this.refreshWorkflowResourcePicker(input));
    this.refreshWorkflowResourcePicker(input);
    return row;
  }

  refreshWorkflowResourcePicker(input) {
    const row = input?.closest?.(".workflow-resource-picker");
    if (!row) return;
    const selection = row.querySelector(".workflow-resource-selection");
    const openButton = row.querySelector("[data-senxue-resource-open='true']");
    const clearButton = row.querySelector("[data-senxue-resource-clear='true']");
    const paths = splitResourcePaths(input.value);
    selection?.replaceChildren();
    row.classList.toggle("is-empty", paths.length === 0);
    row.classList.toggle("is-selected", paths.length > 0);
    if (!paths.length) {
      this.createEl("span", "workflow-resource-empty", "未添加材料", selection);
    } else {
      paths.slice(0, 3).forEach((resourcePath, index) => {
        const chip = this.createEl("span", "workflow-resource-chip", "", selection);
        chip.title = resourcePath;
        this.createEl("span", "workflow-resource-name", getResourceDisplayName(resourcePath), chip);
        const removeButton = this.createEl("button", "workflow-resource-remove", "×", chip);
        removeButton.type = "button";
        removeButton.setAttribute("aria-label", `移除 ${getResourceDisplayName(resourcePath)}`);
        removeButton.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          this.setWorkflowResourcePaths(input, paths.filter((_, itemIndex) => itemIndex !== index));
        });
      });
      if (paths.length > 3) {
        this.createEl("span", "workflow-resource-overflow", `还有 ${paths.length - 3} 项`, selection);
      }
    }
    if (openButton) openButton.textContent = paths.length ? "更换材料" : "添加材料";
    if (clearButton) clearButton.hidden = paths.length === 0;
  }

  setWorkflowResourcePaths(input, paths) {
    if (!input) return;
    input.value = (paths || []).filter(Boolean).join("；");
    input.setAttribute("data-senxue-user-edited", "true");
    input.setAttribute("data-senxue-autofilled", "false");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  openWorkflowResourcePicker(input, field = {}) {
    const row = input?.closest?.(".workflow-resource-picker");
    if (!row || row.getAttribute("data-senxue-resource-mode") === "paste") return;
    const mode = row.getAttribute("data-senxue-resource-mode") || "all";
    const allowNote = mode !== "import" && row.getAttribute("data-senxue-allow-note") === "true";
    const allowFile = mode !== "note" && row.getAttribute("data-senxue-allow-file") === "true";
    const allowFolder = mode !== "note" && row.getAttribute("data-senxue-allow-folder") === "true";
    let options = null;
    new SenxueResourcePickerModal(this.app, {
      allowNote,
      allowFile,
      allowFolder,
      searchNotes: (query) => {
        if (String(query || "").trim().length < 2) return [];
        if (!options) options = this.collectWorkflowPathOptions(field);
        return filterResourceOptions(options, query, 20);
      },
      onSelectNote: (resourcePath) => {
        this.setWorkflowResourcePaths(input, [resourcePath]);
        new Notice("已选择工作台材料");
      },
      onPickFile: () => this.pickWorkflowPath(input, {
        mode: "file",
        multi: field.multiSelect,
        desktop: field.desktopDefault,
        defaultPath: field.defaultPath,
        filters: field.filters,
        accept: field.accept
      }),
      onPickFolder: () => this.pickWorkflowPath(input, {
        mode: "folder",
        multi: false,
        desktop: field.desktopDefault,
        defaultPath: field.defaultPath
      })
    }).open();
  }

  collectWorkflowPathOptions(field = {}) {
    const rawPrefixes = Array.isArray(field.pathPrefixes) ? field.pathPrefixes : [];
    const prefixes = rawPrefixes.map((item) => String(item || "").replace(/\\/g, "/")).filter(Boolean);
    const matchPrefix = (value) => !prefixes.length || prefixes.some((prefix) => value.startsWith(prefix));
    const result = [];
    const seen = new Set();
    const add = (path, type) => {
      if (!path || seen.has(path) || !matchPrefix(path)) return;
      seen.add(path);
      result.push({ path, type, label: type === "folder" ? `目录 · ${path}` : `笔记 · ${path}` });
    };
    try {
      for (const file of this.app.vault.getFiles()) {
        if (file.extension === "md") add(file.path, "file");
      }
      const walk = (folder) => {
        for (const child of folder?.children || []) {
          if (child?.children) {
            add(child.path, "folder");
            walk(child);
          }
        }
      };
      walk(this.app.vault.getRoot());
    } catch (error) {
      console.warn("Senxue workbench: failed to collect workflow path options", error);
    }
    return result.sort((a, b) => a.path.localeCompare(b.path, "zh-Hans-CN"));
  }

  async pickWorkflowPath(input, options = {}) {
    if (!input) return;
    try {
      const properties = [];
      if (options.mode === "folder") properties.push("openDirectory");
      else properties.push("openFile");
      if (options.multi) properties.push("multiSelections");
      const dialogOptions = { title: options.mode === "folder" ? "选择文件夹" : "选择文件", properties };
      if (options.defaultPath) dialogOptions.defaultPath = options.defaultPath;
      else if (options.desktop) dialogOptions.defaultPath = pathModule.join(this.systemAdapter.homeDirectory(), "Desktop");
      if (options.filters) dialogOptions.filters = options.filters;
      else if (options.accept === "image") dialogOptions.filters = [{ name: "图片", extensions: ["png", "jpg", "jpeg", "webp", "gif"] }];
      let result;
      try {
        result = await this.systemAdapter.pickPath(dialogOptions);
      } catch (error) {
        if (error?.code !== "UNAVAILABLE") throw error;
        await this.pickWorkflowPathWithNativeInput(input, options);
        return;
      }
      if (result?.canceled || !result?.filePaths?.length) return;
      const paths = result.filePaths.map((item) => this.normalizePickedPath(item));
      this.setWorkflowResourcePaths(input, paths);
      new Notice(options.mode === "folder" ? "已选择文件夹" : "已选择文件");
    } catch (error) {
      console.warn("Senxue workbench: failed to pick workflow path", error);
      new Notice("选择文件失败，请手动填写路径");
    }
  }

  async pickWorkflowPathWithNativeInput(input, options = {}) {
    return new Promise((resolve) => {
      try {
        const picker = document.createElement("input");
        picker.type = "file";
        picker.style.display = "none";
        if (options.multi) picker.multiple = true;
        if (options.accept === "image") picker.accept = "image/png,image/jpeg,image/webp,image/gif";
        if (options.mode === "folder") picker.setAttribute("webkitdirectory", "true");
        picker.addEventListener("change", () => {
          const files = Array.from(picker.files || []);
          const paths = files.map((file) => {
            try {
              return this.systemAdapter.getPathForFile(file);
            } catch (_) {}
            return file.path || file.webkitRelativePath || file.name;
          }).filter(Boolean);
          if (paths.length) {
            let finalPaths = paths;
            if (options.mode === "folder") {
              const first = paths[0];
              const relative = files[0]?.webkitRelativePath || "";
              if (relative && first.endsWith(relative.replace(/\\/g, "/"))) {
                finalPaths = [first.slice(0, first.length - relative.length).replace(/[\\/]$/, "")];
              }
            }
            this.setWorkflowResourcePaths(
              input,
              finalPaths.map((item) => this.normalizePickedPath(item))
            );
            new Notice(options.mode === "folder" ? "已选择文件夹" : "已选择文件");
          }
          picker.remove();
          resolve();
        }, { once: true });
        document.body.appendChild(picker);
        picker.click();
      } catch (error) {
        console.warn("Senxue workbench: native picker fallback failed", error);
        new Notice("当前环境不支持系统选择框，请手动填写路径");
        resolve();
      }
    });
  }

  normalizePickedPath(filePath) {
    if (!filePath) return "";
    const basePath = this.app?.vault?.adapter?.basePath;
    if (basePath) {
      try {
        const relative = pathModule.relative(basePath, filePath);
        if (relative && !relative.startsWith("..") && !pathModule.isAbsolute(relative)) return relative.replace(/\\/g, "/");
      } catch (_) {}
    }
    return String(filePath).replace(/\\/g, "/");
  }

  bindWorkflowFormPersistence(scope, runnerName) {
    if (!scope || !runnerName) return;
    const storageKey = `senxue-workflow-form:${runnerName}`;
    let saved = {};
    try {
      saved = JSON.parse(window.localStorage?.getItem(storageKey) || "{}") || {};
    } catch (_) {
      saved = {};
    }

    const fields = Array.from(scope.querySelectorAll("[data-senxue-param]"));
    fields.forEach((field) => {
      const key = field.getAttribute("data-senxue-param") || "";
      if (Object.prototype.hasOwnProperty.call(saved, key)) {
        field.value = saved[key] || "";
        field.setAttribute("data-senxue-restored", "true");
        if (field.getAttribute("data-senxue-source-path") === "true") {
          field.setAttribute("data-senxue-user-edited", "true");
          field.setAttribute("data-senxue-autofilled", "false");
        }
        this.refreshWorkflowResourcePicker(field);
      }
    });

    const persist = () => {
      const next = {};
      fields.forEach((field) => {
        const key = field.getAttribute("data-senxue-param") || "";
        if (!key) return;
        next[key] = field.value || "";
      });
      try {
        window.localStorage?.setItem(storageKey, JSON.stringify(next));
      } catch (_) {}
    };

    fields.forEach((field) => {
      field.addEventListener("input", persist);
      field.addEventListener("change", persist);
    });

    const hint = this.createEl("span", "workflow-persist-hint", "已自动保存本页填写内容，退出后再进会恢复。");
    scope.appendChild(hint);
  }

  bindWorkflowSourceSync(scope) {
    const source = scope.querySelector?.("[data-senxue-source-select='true']");
    const path = scope.querySelector?.("[data-senxue-source-path='true']");
    if (!source || !path) return;
    const defaultPath = source.getAttribute("data-senxue-source-default") || path.value || "";
    const row = path.closest?.(".workflow-resource-picker");
    const defaultPlaceholder = path.getAttribute("placeholder") || "";
    let initialized = false;
    const syncPicker = (mode) => {
      if (row) {
        row.setAttribute("data-senxue-resource-mode", mode);
        row.classList.toggle("is-hidden", mode === "paste");
      }
      this.refreshWorkflowResourcePicker(path);
      initialized = true;
    };
    const fillPath = () => {
      const sourceValue = source.value || "";
      const isImport = /导入|新文件|本地|电脑|文件夹/.test(sourceValue);
      const isNote = /指定|笔记|目录|资料库|上一环节|最近/.test(sourceValue);
      const isPaste = /粘贴|自定义输入/.test(sourceValue);
      const nextMode = isImport ? "import" : (isNote ? "note" : (isPaste ? "paste" : "all"));
      const previousMode = row?.getAttribute("data-senxue-resource-mode") || "all";
      if (initialized && previousMode !== nextMode) {
        path.value = "";
        path.removeAttribute("data-senxue-user-edited");
        path.setAttribute("data-senxue-autofilled", "false");
      }
      const wasAuto = path.getAttribute("data-senxue-autofilled") === "true";
      const userEdited = path.getAttribute("data-senxue-user-edited") === "true";
      if (isImport) {
        path.setAttribute("placeholder", "点击右侧按钮选择电脑文件/文件夹");
        if (wasAuto && !userEdited) path.value = "";
        path.setAttribute("data-senxue-autofilled", "false");
        syncPicker("import");
        return;
      }
      if (isNote) {
        path.setAttribute("placeholder", "输入关键词搜索笔记/目录，或从下拉里选择");
        if (defaultPath && /上一环节|最近/.test(sourceValue) && (!path.value || wasAuto || !userEdited)) {
          path.value = defaultPath;
          path.setAttribute("data-senxue-autofilled", "true");
        } else if (/指定|资料库/.test(sourceValue) && wasAuto && !userEdited) {
          path.value = "";
          path.setAttribute("data-senxue-autofilled", "false");
        }
        syncPicker("note");
        return;
      }
      if (isPaste) {
        path.setAttribute("placeholder", "可留空，直接在下方粘贴材料");
        if (wasAuto) path.value = "";
        path.setAttribute("data-senxue-autofilled", "false");
        syncPicker("paste");
        return;
      }
      path.setAttribute("placeholder", defaultPlaceholder);
      syncPicker("all");
    };
    path.addEventListener("input", () => {
      path.setAttribute("data-senxue-user-edited", "true");
      path.setAttribute("data-senxue-autofilled", "false");
    });
    source.addEventListener("change", fillPath);
    fillPath();
  }

  createWorkflowButton(action) {
    const button = document.createElement("button");
    button.className = `workflow-button ${action.secondary ? "secondary" : ""} ${action.accent ? "accent" : ""} ${action.runButton ? "workflow-run-button" : ""}`.trim();
    button.textContent = action.text || "启动";
    if (action.openPath) button.setAttribute("data-senxue-open-path", action.openPath);
    if (action.resultPath) button.setAttribute("data-senxue-open-result", action.resultPath);
    if (action.action) button.setAttribute("data-senxue-action", action.action);
    if (action.openUrl) button.setAttribute("data-senxue-open-url", action.openUrl);
    if (action.openMode) button.setAttribute("data-senxue-open-mode", action.openMode);
    if (action.agentSession) button.setAttribute("data-senxue-agent-session", action.agentSession);
    if (action.workflow) button.setAttribute("data-senxue-workflow", action.workflow);
    if (action.autosend) button.setAttribute("data-senxue-autosend", "true");
    if (action.collectParams) button.setAttribute("data-senxue-collect-params", "true");
    return button;
  }

  createSkillMarketPanel(config = {}) {
    const wrap = this.createEl("div", "workflow-runner skill-market-panel");
    const head = this.createEl("div", "skill-market-head");
    this.createEl("strong", "", config.title || "Skill 市场", head);
    this.createEl("span", "", config.desc || "搜索、查看、安装可用 Skill。", head);
    wrap.appendChild(head);

    const targetRow = this.createEl("label", "skill-market-target");
    this.createEl("span", "", "安装到", targetRow);
    const targetSelect = document.createElement("select");
    for (const target of [
      { value: "claude", label: "Claude（当前仓库）" },
      { value: "codex", label: "Codex（本机）" }
    ]) {
      const option = document.createElement("option");
      option.value = target.value;
      option.textContent = target.label;
      targetSelect.appendChild(option);
    }
    targetSelect.value = "claude";
    targetRow.appendChild(targetSelect);
    wrap.appendChild(targetRow);

    const search = this.createEl("div", "skill-market-search");
    const input = document.createElement("input");
    input.type = "search";
    input.placeholder = config.placeholder || "搜索 Skill 名称 / 关键词：写小说、PPT、抖音、爬虫";
    input.value = config.defaultKeyword || "";
    search.appendChild(input);

    const button = this.createEl("button", "ai-action-button primary", "搜索");
    search.appendChild(button);
    wrap.appendChild(search);

    const status = this.createEl("div", "skill-market-status", "正在读取最新 Skill…");
    const results = this.createEl("div", "skill-market-results");
    wrap.appendChild(status);
    wrap.appendChild(results);

    let skills = [];
    const runSearch = async () => {
      skills = await this.searchSkillHub(input.value, results, status, button, targetSelect.value);
    };
    button.addEventListener("click", (event) => {
      event.preventDefault();
      runSearch();
    });
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        runSearch();
      }
    });
    targetSelect.addEventListener("change", () => {
      if (skills.length) this.renderSkillHubResults(skills, results, targetSelect.value);
    });
    this.runtimeScope.timeout(runSearch, 80);
    return wrap;
  }

  getSkillInstallContext(target) {
    return {
      target: normalizeSkillTarget(target),
      vaultPath: this.app?.vault?.adapter?.basePath || "",
      homeDir: this.systemAdapter.homeDirectory(),
      pathExists: (value) => this.systemAdapter.pathExists(value)
    };
  }

  async searchSkillHub(keyword, results, status, button, target = "claude") {
    const query = String(keyword || "").trim();
    const url = `https://api.skillhub.cn/api/skills?page=1&pageSize=24&keyword=${encodeURIComponent(query)}&sortBy=updatedAt&order=desc`;
    results.replaceChildren();
    status.textContent = query ? `正在搜索：${query}…` : "正在读取最新 Skill…";
    button.disabled = true;
    try {
      const response = await this.systemAdapter.request({ url, method: "GET" });
      const data = response.json || JSON.parse(response.text || "{}");
      const skills = this.parseSkillHubListData(data);
      if (!skills.length) {
        status.textContent = "没有匹配结果，换个关键词试试。";
        return [];
      }
      const total = data?.data?.total || skills.length;
      status.textContent = `找到 ${skills.length} 个 Skill（共 ${total}）。`;
      this.renderSkillHubResults(skills, results, target);
      return skills;
    } catch (error) {
      console.warn("Senxue workbench: SkillHub search failed", error);
      status.textContent = "读取失败，请检查网络后重试。";
      return [];
    } finally {
      button.disabled = false;
    }
  }

  parseSkillHubListData(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.data?.skills)) return data.data.skills;
    if (Array.isArray(data?.data?.list)) return data.data.list;
    if (Array.isArray(data?.skills)) return data.skills;
    if (Array.isArray(data?.list)) return data.list;
    return [];
  }

  renderSkillHubResults(skills, results, target = "claude") {
    results.replaceChildren();
    const normalizedTarget = normalizeSkillTarget(target);
    const targetLabel = normalizedTarget === "claude" ? "Claude" : "Codex";
    for (const skill of skills) {
      const slug = String(skill.slug || skill.name || "").trim();
      const desc = String(skill.description_zh || skill.description || "未读取到简介").trim();
      const card = this.createEl("div", "skill-market-card");
      card.setAttribute("title", desc);
      const title = this.createEl("div", "skill-market-card-title");
      this.createEl("strong", "", skill.name || slug || "未命名 Skill", title);
      if (slug) this.createEl("em", "", slug, title);
      card.appendChild(title);
      const descEl = this.createEl("p", "skill-market-desc", desc, card);
      descEl.setAttribute("title", desc);
      this.createEl("div", "skill-market-meta", this.formatSkillHubMeta(skill), card);

      const actions = this.createEl("div", "workflow-platform-row skill-market-actions");
      const installed = this.isTargetSkillInstalled(slug, normalizedTarget);
      const installButton = this.createEl(
        "button",
        `ai-action-button primary ${installed ? "is-installed" : ""}`.trim(),
        `${installed ? "更新到" : "安装到"} ${targetLabel}`
      );
      installButton.setAttribute("data-senxue-skill-slug", slug);
      installButton.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        await this.installSkillHubSkill(skill, installButton, normalizedTarget);
      });
      actions.appendChild(installButton);

      const link = this.createEl("button", "ai-action-button", "详情");
      link.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        const detailUrl = skill.homepage || `https://www.skillhub.cn/skill/${slug}`;
        this.systemAdapter.openExternal(detailUrl).catch((error) => {
          console.warn("Senxue workbench: failed to open Skill details", error);
        });
      });
      actions.appendChild(link);
      card.appendChild(actions);
      results.appendChild(card);
    }
  }

  formatSkillHubMeta(skill = {}) {
    const parts = [];
    if (skill.ownerName) parts.push(`作者：${skill.ownerName}`);
    if (skill.category) parts.push(`分类：${skill.category}`);
    if (skill.source) parts.push(`来源：${skill.source}`);
    if (skill.downloads != null) parts.push(`下载：${this.formatNumber(skill.downloads)}`);
    if (skill.installs != null) parts.push(`安装：${this.formatNumber(skill.installs)}`);
    if (skill.stars != null) parts.push(`星标：${this.formatNumber(skill.stars)}`);
    if (skill.version) parts.push(`版本：${skill.version}`);
    return parts.join(" · ") || "热度证据：未读取到";
  }

  isTargetSkillInstalled(slug, target) {
    try {
      return isSkillInstalled(slug, target, this.getSkillInstallContext(target));
    } catch (_) {
      return false;
    }
  }

  async installSkillHubSkill(skill = {}, button, target) {
    const slug = String(skill.slug || "").trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]{1,120}$/.test(slug)) {
      new Notice("Skill 标识无效，无法安装");
      return;
    }
    const normalizedTarget = normalizeSkillTarget(target);
    const targetLabel = normalizedTarget === "claude" ? "Claude" : "Codex";
    const context = this.getSkillInstallContext(normalizedTarget);
    const originalText = button?.textContent || `安装到 ${targetLabel}`;
    let zipPath = "";
    let extractDir = "";
    if (button) {
      button.disabled = true;
      button.textContent = "安装中…";
    }
    try {
      let sourceDir = this.resolveBundledVaultSkillDir(slug);
      if (!sourceDir) {
        const tmpBase = pathModule.join(this.systemAdapter.temporaryDirectory(), `skillhub-${slug}-${Date.now()}`);
        zipPath = `${tmpBase}.zip`;
        extractDir = `${tmpBase}-extract`;
        this.systemAdapter.makeDirectory(extractDir);
        const downloadUrl = `https://api.skillhub.cn/api/v1/download?slug=${encodeURIComponent(slug)}`;
        const response = await this.systemAdapter.request({ url: downloadUrl, method: "GET" });
        const zipBuffer = Buffer.from(new Uint8Array(response.arrayBuffer || []));
        if (!zipBuffer.length) throw new Error("下载结果为空");
        this.systemAdapter.writeFile(zipPath, zipBuffer);
        await this.expandZipArchive(zipPath, extractDir);
        sourceDir = this.resolveExtractedSkillDir(extractDir);
      }
      if (!sourceDir) throw new Error("压缩包中未读取到 SKILL.md");
      deployPreparedSkill({
        slug,
        target: normalizedTarget,
        sourceDir,
        vaultPath: context.vaultPath,
        homeDir: context.homeDir,
        system: this.systemAdapter
      });
      if (button) {
        button.textContent = `已安装到 ${targetLabel} / 可更新`;
        button.classList.add("is-installed");
      }
      new Notice(`已安装到 ${targetLabel}：${skill.name || slug}`);
    } catch (error) {
      console.warn("Senxue workbench: Skill install failed", error);
      new Notice(`安装失败：${error.message || "未读取到原因"}`);
      if (button) button.textContent = originalText;
    } finally {
      try { if (zipPath) this.systemAdapter.removePath(zipPath); } catch (_) {}
      try { if (extractDir) this.systemAdapter.removePath(extractDir, { recursive: true }); } catch (_) {}
      if (button) button.disabled = false;
    }
  }

  resolveBundledVaultSkillDir(slug) {
    try {
      const basePath = this.app?.vault?.adapter?.basePath;
      if (!basePath) return null;
      const candidate = pathModule.resolve(basePath, ".claude", "skills", slug);
      const root = pathModule.resolve(basePath, ".claude", "skills");
      if (!candidate.startsWith(root + pathModule.sep)) return null;
      if (this.systemAdapter.pathExists(pathModule.join(candidate, "SKILL.md"))) return candidate;
    } catch (_) {}
    return null;
  }

  resolveExtractedSkillDir(extractDir) {
    const direct = pathModule.join(extractDir, "SKILL.md");
    if (this.systemAdapter.pathExists(direct)) return extractDir;
    const entries = this.systemAdapter.readDirectory(extractDir, { withFileTypes: true });
    const dirs = entries.filter((entry) => entry.isDirectory()).map((entry) => pathModule.join(extractDir, entry.name));
    for (const dir of dirs) {
      if (this.systemAdapter.pathExists(pathModule.join(dir, "SKILL.md"))) return dir;
    }
    return null;
  }

  expandZipArchive(zipPath, destination) {
    const isWindows = process.platform === "win32";
    const command = isWindows ? "powershell.exe" : "unzip";
    const args = isWindows
      ? ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", `Expand-Archive -LiteralPath ${this.quotePowerShellPath(zipPath)} -DestinationPath ${this.quotePowerShellPath(destination)} -Force`]
      : ["-q", "-o", zipPath, "-d", destination];
    return this.systemAdapter.execute(command, args, { windowsHide: true }).catch((error) => {
      const hint = isWindows ? "请确认 Windows PowerShell 可用" : "请确认 macOS 系统 unzip 命令可用";
      throw new Error(`${error?.message || "解压失败"}；${hint}`);
    });
  }

  quotePowerShellPath(value) {
    return `'${String(value || "").replace(/'/g, "''")}'`;
  }

  createEl(tag, cls, text, parent) {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    if (text != null && text !== "") el.textContent = text;
    if (parent) parent.appendChild(el);
    return el;
  }

  async handleDashboardAction(event) {
    const source = event.target;
    const dashboard = source?.closest?.(".senxue-dashboard, .senxue-workflow-page");
    if (!dashboard) return;

    const resultTarget = source.closest?.("[data-senxue-open-result]");
    if (resultTarget) {
      event.preventDefault();
      event.stopPropagation();
      await this.openResultPath(resultTarget.getAttribute("data-senxue-open-result"));
      return;
    }

    const copyTaskTarget = source.closest?.("[data-senxue-copy-task-prompt]");
    if (copyTaskTarget) {
      event.preventDefault();
      event.stopPropagation();
      const taskId = copyTaskTarget.getAttribute("data-senxue-copy-task-prompt") || "";
      const task = this.workbenchTasks.find((item) => item.id === taskId);
      if (!task?.prompt) {
        new Notice("没有找到这条任务的详细指令");
        return;
      }
      await this.copyTextToClipboard(task.prompt);
      new Notice("已复制这条任务的详细指令");
      return;
    }

    const externalUrlTarget = source.closest?.("[data-senxue-open-url]");
    if (externalUrlTarget) {
      event.preventDefault();
      event.stopPropagation();
      await this.openExternalUrl(
        externalUrlTarget.getAttribute("data-senxue-open-url"),
        externalUrlTarget.getAttribute("data-senxue-agent-session"),
        externalUrlTarget.getAttribute("data-senxue-open-mode")
      );
      return;
    }

    const workflowTarget = source.closest?.("[data-senxue-workflow], [data-senxue-prompt]");
    if (workflowTarget) {
      event.preventDefault();
      event.stopPropagation();
      await this.runWorkflowPrompt(workflowTarget);
      return;
    }

    const folderTarget = source.closest?.("[data-senxue-toggle-folder]");
    if (folderTarget) {
      event.preventDefault();
      event.stopPropagation();
      this.toggleKnowledgeFolder(folderTarget);
      return;
    }

    const trendRangeTarget = source.closest?.("[data-senxue-trend-days]");
    if (trendRangeTarget) {
      event.preventDefault();
      event.stopPropagation();
      const days = Number(trendRangeTarget.getAttribute("data-senxue-trend-days"));
      if (days !== 7 && days !== 30) return;
      this.conversationTrendDays = days;
      await this.refreshDashboard(false);
      return;
    }

    const openTarget = source.closest?.("[data-senxue-open-path]");
    if (openTarget) {
      event.preventDefault();
      event.stopPropagation();
      await this.openVaultPath(openTarget.getAttribute("data-senxue-open-path"));
      return;
    }

    const moduleTarget = source.closest?.("[data-senxue-module]");
    if (moduleTarget) {
      event.preventDefault();
      event.stopPropagation();
      const moduleName = moduleTarget.getAttribute("data-senxue-module") || "home";
      this.switchModule(moduleName, dashboard);
      await this.refreshDashboard(false);
      return;
    }

    const target = source.closest?.("[data-senxue-action]");
    if (!target) return;
    event.preventDefault();
    event.stopPropagation();
    const action = target.getAttribute("data-senxue-action");
    if (action === "open-ai") {
      if (target.closest?.("[data-senxue-pending-project='true']")) {
        new Notice("项目还在生成中，请在右侧 AI 对话查看当前进展");
      }
      await this.openClaudianPanel();
    }
    if (action === "new-ai") await this.openClaudianPanel({ newConversation: true });
    if (action === "refresh") await this.refreshDashboard(true);
  }

  async openResultPath(filePath) {
    const targetPath = String(filePath || "");
    if (!targetPath || !this.systemAdapter.pathExists(targetPath)) {
      new Notice("这个结果文件已经不存在，请回到任务结果查看最新路径");
      return;
    }
    const basePath = this.app?.vault?.adapter?.basePath || "";
    if (basePath) {
      const relative = pathModule.relative(basePath, targetPath);
      if (relative && !relative.startsWith("..") && !pathModule.isAbsolute(relative)) {
        await this.openVaultPath(relative.replace(/\\/g, "/"));
        return;
      }
    }
    try {
      await this.systemAdapter.openPath(targetPath);
    } catch (error) {
      console.warn("Senxue workbench: failed to open task result", error);
      new Notice("无法打开结果文件，请按任务卡上的路径手动打开");
    }
  }

  async runWorkflowPrompt(target) {
    const workflow = target.getAttribute("data-senxue-workflow") || "";
    const activeTask = findLatestWorkflowTask(this.workbenchTasks, workflow);
    if (shouldLockTask(activeTask, {
      pathExists: (value) => this.workbenchPathExists(value)
    })) {
      new Notice("这个任务正在处理中，请先查看当前 AI 进展");
      this.refreshWorkflowTaskFeedback();
      return;
    }
    const basePrompt = target.getAttribute("data-senxue-prompt") || this.buildWorkflowPrompt(workflow);
    if (!basePrompt) {
      new Notice("未找到这个按钮的工作流提示词");
      return;
    }
    const prompt = this.composeWorkflowPrompt(basePrompt, target, workflow);
    const params = this.collectWorkflowParams(target, { includeEmpty: true });
    const validation = validateWorkflowParams(params, (filePath) => this.systemAdapter.pathExists(filePath));
    if (!validation.valid) {
      const field = params.find((item) => item.key === validation.fieldKey)?.element;
      field?.classList?.add("is-invalid");
      const resourcePicker = field?.closest?.(".workflow-resource-picker");
      resourcePicker?.classList.add("is-invalid");
      const focusTarget = resourcePicker?.querySelector("[data-senxue-resource-open='true']") || field;
      focusTarget?.focus?.();
      new Notice(validation.message);
      return;
    }
    const taskDetails = buildWorkflowTask({
      workflow,
      title: this.getWorkflowDisplayName(target, workflow),
      params,
      prompt
    });
    const approved = await this.confirmWorkflowTask({
      ...taskDetails,
      params: taskDetails.params.filter((item) => item.value)
    });
    if (!approved) return;
    const shouldAutoSend = target.closest?.("[data-senxue-autosend='true']")
      || target.getAttribute("data-senxue-autosend") === "true";
    const task = shouldAutoSend ? createTaskRecord({
      ...taskDetails,
      params: taskDetails.params.filter((item) => item.value)
    }) : null;
    if (task) {
      this.workbenchTasks = normalizeTaskStore([task, ...this.workbenchTasks]);
      await this.persistWorkbenchTasks();
      this.runtimeScope.timeout(() => this.refreshWorkflowTaskFeedback(), TASK_START_RECHECK_MS);
    }
    try {
      const panel = await this.openClaudianPanel({ createIfMissing: true });
      if (!panel) throw new Error("AI 对话没有准备好");
      const input = panel?.input
        ? await this.claudianAdapter.insertAndSend(prompt, {
          input: panel.input,
          send: Boolean(shouldAutoSend),
          sendDelayMs: shouldAutoSend ? 160 : 0
        })
        : null;
      if (input) {
        if (shouldAutoSend) {
          const activeTab = panel.tab || this.claudianAdapter.getActiveTab();
          this.workbenchTasks = updateTaskRecord(this.workbenchTasks, task.id, {
            status: "submitted",
            submittedAt: Date.now(),
            updatedAt: Date.now(),
            tabId: activeTab?.id || "",
            conversationId: activeTab?.conversationId || "",
            error: ""
          });
          await this.persistWorkbenchTasks();
          new Notice("已直接启动山竹智能体执行这个任务");
          return;
        }
        new Notice("已把任务放入山竹智能体输入框，确认后发送即可开始执行");
        return;
      }
      await this.copyTextToClipboard(prompt);
      new Notice("未找到山竹智能体输入框，已复制任务提示词作为备用");
    } catch (error) {
      console.warn("Senxue workbench: failed to prepare workflow prompt", error);
      if (task) {
        this.workbenchTasks = updateTaskRecord(this.workbenchTasks, task.id, {
          status: "failed",
          error: error?.message || "AI 任务没有成功启动",
          updatedAt: Date.now()
        });
        await this.persistWorkbenchTasks();
      }
      try {
        await this.copyTextToClipboard(prompt);
        new Notice("自动填入失败，已复制任务提示词作为备用");
      } catch (_) {
        new Notice("工作流提示词准备失败");
      }
    }
  }

  getWorkflowDisplayName(target, workflow) {
    return this.workflowCatalog.getDisplayName(target?.textContent, workflow);
  }

  confirmWorkflowTask(details) {
    return new SenxueTaskConfirmModal(this.app, details).openAndWait();
  }

  persistWorkbenchTasks() {
    const save = async () => {
      this.workbenchTasks = normalizeTaskStore(this.workbenchTasks);
      this.pluginData = {
        ...this.pluginData,
        workbenchTasks: this.workbenchTasks
      };
      await this.saveData(this.pluginData);
      this.refreshWorkflowTaskFeedback();
      this.refreshProjectPlaceholderGrids();
    };
    this.taskSaveChain = this.taskSaveChain.then(save, save);
    return this.taskSaveChain;
  }

  composeWorkflowPrompt(basePrompt, target, workflow) {
    if (target.getAttribute("data-senxue-collect-params") !== "true") return basePrompt;
    const params = this.collectWorkflowParams(target);
    const paramText = params.length
      ? params.map(({ key, value }) => `- ${key}：${value}`).join("\n")
      : "- 用户没有填写额外参数，请按当前已登录页面先识别可用信息；缺关键字段再追问。";
    if (/^office-/.test(workflow)) {
      return `${basePrompt}

面板参数：
${paramText}

执行：按日常办公知识库场景卡执行；先读取 山竹智能体知识库/日常办公/projectMAP.md、MEMORY/、Resources/场景超市/ 对应卡片。若需要读取/导入电脑文件，优先使用本地 .claude/skills/markitdown-converter Skill 把文件转成 Markdown 后再处理；不要声称调用不存在的 Skill。缺关键字段再追问，非关键字段按默认值处理；输出后给出建议归档位置。桌面输出规则：凡用户选择生成表格、PPT、报表、Word 或其他可交付文件，完成后除写入日常办公输出记录，也必须复制/保存一份最终可打开文件到用户桌面（Windows：%USERPROFILE%\\Desktop；macOS：~/Desktop）；文件名用“日期-主题-类型”，无法写入桌面时说明原因并给出归档路径。`;
    }
    if (/^ai-coding-/.test(workflow)) {
      return `${basePrompt}

面板参数：
${paramText}

执行：按 山竹智能体知识库/AI编程/ 的工作流直接执行；先读取 山竹智能体知识库/AI编程/00-入口.md 和 项目库/00-项目库索引.md。不要声称调用不存在的 Skill。项目名/项目路径是关键字段，缺失时再追问；非关键字段按默认值处理。完成后必须写入或更新对应项目文件，并把下一步可点击路径告诉用户。`;
    }
    if (workflow === "product-selection-score") {
      return `${basePrompt}

面板参数：
${paramText}

执行：优先调用 product-selection-score Skill。读取规则必须按这个顺序：
1. 如果“候选商品数据”里有用户手动粘贴的商品数据，优先用粘贴内容。
2. 否则不要默认沿用页面打开时预填的旧资料路径；执行前必须重新扫描 山竹智能体知识库/短视频带货/平台找品/，按文件修改时间读取最新一份第二步“找品出数据”产出。
3. 不要把 山竹智能体知识库/短视频带货/AI选品评分/ 里的旧评分结果当作本轮候选商品输入。
4. 如果平台找品目录没有可用最新产出，再提示用户先跑第二步或粘贴候选商品数据。
5. 评分完成后，除非用户选择“关闭：只输出评分”，默认继续为 TOP3 商品采集主图：优先读取候选数据里的商品链接/商品图链接；没有链接时，使用 Kimi WebBridge 借用当前已登录平台页面按商品名搜索或定位商品卡；对每个 TOP 商品截取商品主图或商品卡主图。
6. 主图必须保存到 山竹智能体知识库/短视频带货/素材库/商品主图/，文件名用 日期-TOP序号-商品名-主图.png；同时在评分结果表里写入“主图来源”“本地主图路径”“可用于图生视频：是/否”。
7. 如果遇到登录、验证码、风控、权限页或图片无法读取，不要绕过，写“主图未读取到”并说明原因；不要用 AI 生成图替代真实商品主图。`;
    }
    const skillName = workflow || "对应";
    return `${basePrompt}

面板参数：
${paramText}

执行：优先调用 ${skillName} Skill；如果当前环境没有这个 Skill，就按同名工作流直接执行。缺关键字段再追问，非关键字段按默认值处理。`;
  }

  composePlatformProductMiningPrompt(basePrompt, params, paramText) {
    return `${basePrompt}\n\n面板参数：\n${paramText}\n\n执行：直接调用 platform-product-mining Skill；不要展开长流程提示。`;
  }

  composeShowcaseConfirmAddPrompt(basePrompt, params, paramText) {
    return `${basePrompt}\n\n面板参数：\n${paramText}\n\n执行：直接调用 showcase-confirm-add Skill；不要展开长流程提示。`;
  }

  resolveAgentBrowserSession(params) {
    const platform = params.find((item) => item.key.includes("平台") || item.key.includes("目标位置"))?.value || "";
    if (/巨量|百应|精选|抖音|buyin|jinritemai/i.test(platform)) return { name: "senxue-buyin", label: "巨量百应 / 精选联盟", domainHint: "buyin.jinritemai.com / douyinec.com" };
    if (/蝉妈妈|chanmama/i.test(platform)) return { name: "senxue-chanmama", label: "蝉妈妈", domainHint: "chanmama.com" };
    if (/淘宝|淘客|淘宝联盟|alimama/i.test(platform)) return { name: "senxue-alimama", label: "淘宝联盟", domainHint: "alimama.com" };
    return null;
  }

  collectWorkflowParams(target, options = {}) {
    const scope = target.closest("[data-senxue-runner]") || target.closest(".workflow-shell") || target.parentElement;
    if (!scope) return [];
    return Array.from(scope.querySelectorAll("[data-senxue-param]")).map((field) => {
      const key = field.getAttribute("data-senxue-param") || "参数";
      let value = "";
      if (field instanceof HTMLSelectElement) value = field.value || field.options[field.selectedIndex]?.text || "";
      else if (field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement) value = field.value || "";
      else value = field.textContent || "";
      return {
        key,
        value: value.trim(),
        required: field.getAttribute("data-senxue-required") === "true",
        requiredGroup: field.getAttribute("data-senxue-required-group") || "",
        pathKind: field.getAttribute("data-senxue-path-kind") || "",
        element: field
      };
    }).filter((item) => options.includeEmpty || item.value);
  }

  async insertPromptIntoClaudian(text, integration, preparedInput) {
    return this.claudianAdapter.insertAndSend(text, {
      input: preparedInput,
      send: false
    });
  }

  resetClaudianInputHeight() {
    this.claudianAdapter?.resetInputHeights();
  }

  isEditableVisibleElement(el) {
    if (!el) return false;
    if (el.disabled || el.readOnly) return false;
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  }

  async openExternalUrl(url, agentSessionName, openMode) {
    if (!url) return;
    const mode = openMode || (agentSessionName ? "agent-browser" : "system");
    if (mode === "agent-browser" && agentSessionName) {
      await this.openAgentBrowserUrl(url, agentSessionName);
      return;
    }
    if (mode === "chrome") {
      const openedInChrome = await this.openUrlInChrome(url);
      if (openedInChrome) {
        new Notice(await this.composeSystemBrowserNotice("Chrome"));
        return;
      }
    }
    await this.systemAdapter.openExternal(url);
    new Notice(await this.composeSystemBrowserNotice());
  }

  async composeSystemBrowserNotice(browserName = "真实浏览器") {
    const status = await this.getKimiWebBridgeStatus();
    if (status?.running && status?.extension_connected) {
      return `已用${browserName}打开平台；Kimi WebBridge 已连接，可直接接管当前标签页`;
    }
    if (status?.running) {
      return `已用${browserName}打开平台；Kimi daemon 已启动但扩展未连接，请确认浏览器扩展已启用`;
    }
    return `已用${browserName}打开平台；登录完成后回到向导点下一步`;
  }

  async openUrlInChrome(url) {
    try {
      const chromePath = this.findChromeExecutable();
      if (!chromePath) {
        new Notice("未找到 Google Chrome，已改用系统默认浏览器打开");
        return false;
      }
      this.systemAdapter.spawnDetached(chromePath, [url]);
      return true;
    } catch (error) {
      console.warn("Senxue workbench: failed to open Chrome", error);
      new Notice("Chrome 打开失败，已改用系统默认浏览器打开");
      return false;
    }
  }

  findChromeExecutable() {
    try {
      const candidates = [
        process.env.CHROME_PATH,
        process.env.PROGRAMFILES ? pathModule.join(process.env.PROGRAMFILES, "Google", "Chrome", "Application", "chrome.exe") : "",
        process.env["PROGRAMFILES(X86)"] ? pathModule.join(process.env["PROGRAMFILES(X86)"], "Google", "Chrome", "Application", "chrome.exe") : "",
        process.env.LOCALAPPDATA ? pathModule.join(process.env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe") : ""
      ].filter(Boolean);
      return candidates.find((candidate) => this.systemAdapter.pathExists(candidate)) || "";
    } catch (_) {
      return "";
    }
  }

  async getKimiWebBridgeStatus() {
    try {
      const controller = new AbortController();
      let finished = false;
      this.runtimeScope.timeout(() => {
        if (!finished) controller.abort();
      }, 1200);
      const response = await fetch("http://127.0.0.1:10086/status", { signal: controller.signal });
      finished = true;
      if (!response?.ok) return null;
      return await response.json();
    } catch (_) {
      return null;
    }
  }

  async openAgentBrowserUrl(url, sessionName) {
    try {
      const existingPage = await this.findExistingPlatformCdpPage(url, sessionName);
      if (existingPage?.port) {
        await this.execAgentBrowser(["--session", sessionName, "connect", String(existingPage.port)], 10000);
        new Notice(`已连接到已打开的平台窗口：${existingPage.title || existingPage.url || sessionName}`);
        return true;
      }

      const currentUrl = (await this.execAgentBrowser(["--session", sessionName, "get", "url"], 5000).catch(() => "")).trim();
      const hasPage = currentUrl && currentUrl !== "about:blank";
      const needsVisibleOpen = !hasPage || /about:blank|login|signin|account\/login/i.test(currentUrl);

      if (hasPage && !needsVisibleOpen) {
        new Notice(`已检测到 ${sessionName} 会话已打开，后续会直接复用这个窗口`);
        return true;
      }

      await this.execAgentBrowser(["--session", sessionName, "--headed", "open", url], 30000);
      new Notice(`已打开 AI 可接管平台窗口：${sessionName}。请在这个窗口登录`);
      return true;
    } catch (error) {
      console.warn("Senxue workbench: failed to open agent-browser session", sessionName, error);
      new Notice("AI 可接管浏览器打开失败；没有改用普通浏览器，避免后续重复登录");
      return false;
    }
  }

  async findExistingPlatformCdpPage(url, sessionName) {
    const domains = this.platformDomainsFor(url, sessionName);
    if (!domains.length) return null;
    const ports = await this.discoverChromeDebugPorts();
    const candidates = [];
    for (const port of ports) {
      const targets = await this.readCdpTargets(port).catch(() => []);
      for (const target of targets || []) {
        if (target?.type && target.type !== "page") continue;
        const targetUrl = String(target?.url || "");
        if (!/^https?:\/\//i.test(targetUrl)) continue;
        if (!this.urlMatchesAnyDomain(targetUrl, domains)) continue;
        candidates.push({ ...target, port, score: this.scorePlatformTarget(targetUrl) });
      }
    }
    candidates.sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  platformDomainsFor(url, sessionName) {
    const domains = new Set(PLATFORM_CDP_DOMAINS[sessionName] || []);
    try {
      const host = new URL(url).hostname.replace(/^www\./, "").toLowerCase();
      if (host) domains.add(host);
      if (/jinritemai|buyin|douyin/i.test(host)) {
        domains.add("buyin.jinritemai.com");
        domains.add("douyinec.com");
      }
      if (/chanmama/i.test(host)) domains.add("chanmama.com");
      if (/alimama/i.test(host)) domains.add("alimama.com");
    } catch (_) {}
    return Array.from(domains).map((item) => item.replace(/^www\./, "").toLowerCase()).filter(Boolean);
  }

  async discoverChromeDebugPorts() {
    const ports = new Set();
    try {
      const tempDir = this.systemAdapter.temporaryDirectory();
      const dirs = this.systemAdapter.readDirectory(tempDir, { withFileTypes: true })
        .filter((entry) => entry.isDirectory() && entry.name.startsWith("agent-browser-chrome-"))
        .map((entry) => {
          const fullPath = pathModule.join(tempDir, entry.name);
          let mtime = 0;
          try { mtime = this.systemAdapter.stat(fullPath).mtimeMs; } catch (_) {}
          return { fullPath, mtime };
        })
        .sort((a, b) => b.mtime - a.mtime);
      for (const dir of dirs) {
        const portFile = pathModule.join(dir.fullPath, "DevToolsActivePort");
        if (!this.systemAdapter.pathExists(portFile)) continue;
        const port = String(this.systemAdapter.readText(portFile).split(/\r?\n/)[0] || "").trim();
        if (/^\d+$/.test(port)) ports.add(port);
      }
    } catch (_) {}
    ["9222", "9333"].forEach((port) => ports.add(port));
    return Array.from(ports);
  }

  readCdpTargets(port) {
    return new Promise((resolve, reject) => {
      try {
        const http = require("http");
        const req = http.get({ hostname: "127.0.0.1", port: Number(port), path: "/json/list", timeout: 1200 }, (res) => {
          let body = "";
          res.setEncoding("utf8");
          res.on("data", (chunk) => { body += chunk; });
          res.on("end", () => {
            try { resolve(JSON.parse(body)); }
            catch (error) { reject(error); }
          });
        });
        req.on("timeout", () => { req.destroy(new Error("CDP target list timeout")); });
        req.on("error", reject);
      } catch (error) {
        reject(error);
      }
    });
  }

  urlMatchesAnyDomain(targetUrl, domains) {
    try {
      const host = new URL(targetUrl).hostname.replace(/^www\./, "").toLowerCase();
      return domains.some((domain) => host === domain || host.endsWith(`.${domain}`));
    } catch (_) {
      return false;
    }
  }

  scorePlatformTarget(targetUrl) {
    let score = 0;
    if (/dashboard|selection|merch|library|product|goods|search|item/i.test(targetUrl)) score += 20;
    if (/login|signin|passport|captcha|verify/i.test(targetUrl)) score -= 30;
    return score;
  }

  execAgentBrowser(args, timeout) {
    const command = this.agentBrowserCommandPath();
    return this.systemAdapter.execute(command, args || [], {
      windowsHide: true,
      timeout: timeout || 30000,
      maxBuffer: 1024 * 1024,
      shell: process.platform === "win32"
    }).then((result) => result.stdout || "");
  }

  agentBrowserCommandPath() {
    try {
      const appData = process.env.APPDATA || "";
      if (appData) {
        const localCmd = pathModule.join(appData, "npm", "agent-browser.cmd");
        if (this.systemAdapter.pathExists(localCmd)) return localCmd;
      }
    } catch (_) {}
    return "agent-browser.cmd";
  }

  quoteCmdArg(value) {
    const text = String(value ?? "");
    return `"${text.replace(/"/g, '""')}"`;
  }

  async copyTextToClipboard(text) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "true");
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    const ok = document.execCommand("copy");
    textarea.remove();
    if (!ok) throw new Error("document.execCommand copy failed");
  }

  buildWorkflowPrompt(workflow) {
      const prompts = {
          "workbench-usage-qa": "森雪赚AI工作台：使用问题解答。\n\n任务：读取用户在面板填写的问题类型、所在功能/页面、问题明细和补充信息，直接帮用户解决使用问题。\n\n处理逻辑：\n1. 先判断这是操作不会用、功能入口找不到、页面看不懂、结果不对、报错、资料缺失，还是工作台本身需要修改。\n2. 能直接给出答案时，用小白能听懂的话，给 1-3 步最短操作路径，不要写长篇理论。\n3. 如果需要读取当前笔记、相关知识库页面或插件代码，直接读取并判断；不要让用户重复复制已有内容。\n4. 如果能安全修复本地工作台页面、笔记或配置，先说明将改哪里，再直接修改并验证；不要动无关文件。\n5. 如果缺少关键资料，只问一个最关键的问题。\n\n输出格式：原因判断、直接解决办法、下一步点击哪里。必要时补充已修改文件和验证结果。",
          "office-project-create": "日常办公：创建项目知识库。\n\n任务：根据用户填写的项目名称、项目类型、项目目标、负责人/成员、初始资料和补充要求，在 山竹智能体知识库/日常办公/项目库/ 下创建一个独立项目知识库。\n\n必须创建：1）00-项目总览.md；2）01-资料索引.md；3）02-会议与沟通.md；4）03-表格报表.md；5）04-PPT与汇报.md；6）05-待办清单.md；7）06-输出记录.md；8）ProjectMap.md。\n\n如果用户提供初始资料，且是 PDF/Word/Excel/PPT/图片/网页等非 Markdown 文件，先使用本地 .claude/skills/markitdown-converter Skill 转成 Markdown，再放入项目资料索引；不要移动或删除原文件。\n\n要求：项目名要清理非法文件名字符；如果同名项目已存在，不要覆盖，先提示用户确认复用或换名。\n\n输出：创建的项目路径、文件列表、下一步建议，并更新 山竹智能体知识库/日常办公/项目库/00-项目库索引.md。",
          "office-workflow-router": "日常办公：办公资料处理总入口。\n\n任务：读取用户在面板填写的资料来源、资料路径/文件夹、要做的事情、输出格式、结果对象和补充材料。先判断资料是否足够；资料足够就直接执行，不要让用户重复复制。\n\n文件读取规则：当资料来源是“导入新的文件”或路径指向 PDF/Word/Excel/PPT/图片/网页等非 Markdown 文件时，先使用本地 .claude/skills/markitdown-converter Skill，将原文件转换成 Markdown，再基于转换后的 Markdown 做摘要、表格、PPT或归档；不要把二进制文件直接塞进 Prompt；转换失败时说明原因并给出手动处理建议。\n\n执行范围：可做导入资料、整理工作文件、生成表格/报表、生成PPT大纲/逐页文案/必要时制作PPTX、提取待办、项目情况汇总、会议纪要/通知/SOP。\n\n要求：优先读取 山竹智能体知识库/日常办公/projectMAP.md、资料库、输出记录、待办清单；事实/判断/建议分开；涉及删除、移动、覆盖原文件时必须先确认。\n\n归档：结果写入 山竹智能体知识库/日常办公/输出记录/；表格/PPT/报表等最终可交付文件还必须自动复制/保存一份到用户桌面；可复用资料写入资料库；行动项更新 02-待办清单.md；项目状态更新 01-项目情况.md。",
          "office-file-import": "日常办公：导入工作文件。\n\n任务：读取用户给出的文件/文件夹路径或粘贴材料，识别资料类型，生成资料摘要、字段说明、可用价值和后续可做事项。\n\n文件读取规则：当资料来源是“导入新的文件”或路径指向 PDF/Word/Excel/PPT/图片/网页等非 Markdown 文件时，先使用本地 .claude/skills/markitdown-converter Skill，将原文件转换成 Markdown，再基于转换后的 Markdown 做摘要、表格、PPT或归档；不要把二进制文件直接塞进 Prompt；转换失败时说明原因并给出手动处理建议。\n\n要求：不要移动或删除原文件；不要直接把大文件全文放进 Prompt；先转换/抽取/摘要，再按需深入读取；读不到的文件列出原因；文件较多时先建立索引。\n\n输出：导入清单、MarkItDown 转换记录、资料摘要、关键字段/主题、建议归档位置、下一步可执行任务。归档到 山竹智能体知识库/日常办公/资料库/。",
          "office-file-organize": "日常办公：整理工作文件。\n\n任务：按用户选择的整理方式，把散乱资料整理成工作文档、目录、摘要、SOP或汇报材料。\n\n文件读取规则：当资料来源是“导入新的文件”或路径指向 PDF/Word/Excel/PPT/图片/网页等非 Markdown 文件时，先使用本地 .claude/skills/markitdown-converter Skill，将原文件转换成 Markdown，再基于转换后的 Markdown 做摘要、表格、PPT或归档；不要把二进制文件直接塞进 Prompt；转换失败时说明原因并给出手动处理建议。\n\n要求：保留原始事实，清楚标注判断和建议；如需重命名、移动、删除原文件，必须先征求确认。\n\n输出：整理后的结构、可直接使用的工作文档、缺失资料、下一步动作。归档到 山竹智能体知识库/日常办公/输出记录/；如生成 Word/表格/报表/PPT 等最终文件，同时保存一份到用户桌面。",
          "office-table-report": "日常办公：出表格/报表。\n\n任务：从用户选择的资料中抽取字段，生成 Markdown 表格；适合时同步生成 CSV/XLSX 文件。\n\n文件读取规则：当资料来源是“导入新的文件”或路径指向 PDF/Word/Excel/PPT/图片/网页等非 Markdown 文件时，先使用本地 .claude/skills/markitdown-converter Skill，将原文件转换成 Markdown，再基于转换后的 Markdown 做摘要、表格、PPT或归档；不要把二进制文件直接塞进 Prompt；转换失败时说明原因并给出手动处理建议。\n\n要求：字段读不到写未读取到，不编造；统计口径要写清楚。\n\n输出：表格、字段说明、统计口径、关键发现、异常项、下一步动作。归档到 山竹智能体知识库/日常办公/输出记录/；如生成 CSV/XLSX/报表文件，必须同时保存一份到用户桌面。",
          "office-ppt-builder": "日常办公：出PPT。\n\n任务：基于用户资料和用途，按三层流程生成高质量 PPT：1）MarkItDown 读取/转换资料；2）AI 生成 PPT 大纲、逐页内容、页面 JSON；3）根据用户选择的生成方式制作或美化 PPTX。\n\n文件读取规则：当资料来源是“导入新的文件”或路径指向 PDF/Word/Excel/PPT/图片/网页等非 Markdown 文件时，先使用本地 .claude/skills/markitdown-converter Skill，将原文件转换成 Markdown，再基于转换后的 Markdown 做 PPT；不要把二进制文件直接塞进 Prompt；转换失败时说明原因并给出手动处理建议。\n\n美化生成规则：如果用户选择“套用我的模板PPT”，优先用模板PPT路径做版式参考，适合后续接 pptx-automizer；如果选择“生成美化PPTX”，优先按 PptxGenJS / python-pptx 可实现的主题系统生成；如果本地已接入 Presenton 或 PPTAgent，可优先用它们做更高级的视觉生成；如果相关工具未安装，不要假装已调用，先输出页面 JSON、设计规范和可执行安装建议，再用当前可用能力生成一个可打开的 PPTX。\n\n设计要求：根据 PPT用途、PPT风格、美化等级决定视觉系统；一页一个核心观点；标题要像汇报标题，不要像文章小标题；减少大段文字，优先用卡片、流程、对比、表格、数字页；老板汇报默认结论先行。\n\n输出：PPT大纲、页面 JSON/逐页内容、必要时 PPTX 文件、使用的工具说明、归档路径。归档到 山竹智能体知识库/日常办公/输出记录/PPT/；如果生成 PPTX，必须同时保存一份到用户桌面。",
          "office-todo-extractor": "日常办公：提取待办事项。\n\n任务：从会议记录、聊天、文档或项目资料中提取待办，拆出事项、负责人、截止时间、优先级、依赖、当前状态。\n\n要求：读不到负责人或截止时间写未明确；不要替用户编造承诺。\n\n输出：待办表、风险提醒、需要确认的问题，并更新 山竹智能体知识库/日常办公/02-待办清单.md。",
          "office-project-status": "日常办公：项目情况汇总。\n\n任务：扫描 山竹智能体知识库/日常办公/ 下的资料库、输出记录、待办清单、projectMAP 和 MEMORY，汇总当前项目情况。\n\n输出：项目总览、已有资料、已完成输出、进行中事项、风险卡点、缺失资料、下一步建议，并更新 山竹智能体知识库/日常办公/01-项目情况.md。",
          "ai-coding-project-create": "AI编程：新建项目。\n\n任务：读取用户填写的项目名、需求形态、给谁用、要解决的问题、第一版必须有、参考对象/补充说明，在 山竹智能体知识库/AI编程/项目库/ 下创建一个独立 AI 编程项目。\n\n项目名必填；项目名要清理非法文件名字符。如果同名项目已存在，不要覆盖，先提示用户确认复用或换名。\n\n必须创建：\n1. 00-项目总控.md：包含 frontmatter（title、project、status、stage、current_node、current_node_path、updated、summary、cssclasses: [senxue-workflow-page]）。新项目创建完成后的 current_node 写“功能拆解”，current_node_path 写该项目/02-功能清单.md，并写入 senxue-workflow 代码块：page: ai-coding-project-workbench、project_name、project_path。\n2. 01-我的想法.md：整理用户原始需求、使用对象、需求形态、要解决的问题、参考对象。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-requirements、project_name、project_path。\n3. 02-功能清单.md：拆成页面、按钮、输入输出、数据结构、用户流程和第一版范围。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-technical-design、project_name、project_path。\n4. 03-版本计划.md：列出第一版 MVP 计划、验收标准和后续版本。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-first-version、project_name、project_path。\n5. 04-试用反馈.md：预留试用记录模板。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-development、project_name、project_path。\n6. 05-修改记录.md：预留修改/加功能记录模板。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-feature-add、project_name、project_path。\n7. 06-发布交付.md：预留本地打开/部署/交付说明模板。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-deploy、project_name、project_path。\n8. 07-下轮计划.md：预留下轮迭代计划。frontmatter 必须包含 cssclasses: [senxue-workflow-page]，正文顶部必须写入 senxue-workflow 代码块：page: ai-coding-retrospective、project_name、project_path。\n\n同时更新 山竹智能体知识库/AI编程/项目库/00-项目库索引.md，加入项目链接。\n\n输出：创建的项目路径、文件列表、第一版建议、下一步建议。下一步优先打开项目的 02-功能清单.md 或 03-版本计划.md。",
          "ai-coding-requirements": "AI编程：需求拆解。\n\n任务：读取用户填写的项目资料/指定笔记和需求描述，把模糊想法拆成可开发需求。\n\n输出：用户是谁、核心场景、用户故事、功能边界、数据字段、验收标准、风险点、下一步开发建议。若提供了项目路径，更新该项目的 01-我的想法.md 和 02-功能清单.md。",
          "ai-coding-technical-design": "AI编程：拆功能并生成第一版。\n\n任务：读取项目资料和第一版功能，把需求拆成页面、组件、按钮、交互、数据结构、文件结构和可执行开发步骤；如果当前环境可以直接写代码，就生成第一个可打开的 HTML/前端版本或项目骨架。\n\n输出：功能拆解、页面结构、交互流程、代码/文件路径、运行方式、验收清单。若生成文件，归档到当前项目目录下的 产物/ 或用户指定目录，并更新 03-版本计划.md。",
          "ai-coding-task-board": "AI编程：第一版计划。\n\n任务：基于项目需求生成 MVP 任务板，明确第一版先做什么、暂不做什么、每个任务的验收标准。\n\n输出：任务清单、优先级、预计文件、验收标准、下一步编码顺序，并更新当前项目 03-版本计划.md。",
          "ai-coding-first-version": "AI编程：生成第一版。\n\n任务：读取当前项目总控、01-我的想法.md、02-功能清单.md、03-版本计划.md，基于用户填写的第一版目标、产物形式、必须跑通和暂时不做，生成第一个可打开、可点击、可试用的版本。\n\n要求：第一版必须小而完整；优先做用户可直接打开的产物。若用户选择 HTML，优先生成单文件 HTML，除非用户明确要求项目工程。生成后说明文件路径、打开方式、已实现功能、未实现功能和试用清单。\n\n归档：代码/产物放在当前项目目录下的 产物/ 或用户指定目录；同步更新 03-版本计划.md 和 04-试用反馈.md 的试用清单。不要重新开项目。",
          "ai-coding-development": "AI编程：试用并修改。\n\n任务：读取用户试用反馈，定位问题并修改已有项目或页面。先复述用户反馈，再判断问题类型，最后给出修改方案；能直接改文件时直接改并验证。\n\n输出：问题定位、已修改内容、受影响文件、验证方式、下一步试用建议，并更新当前项目 04-试用反馈.md 和 05-修改记录.md。",
          "ai-coding-debug-test": "AI编程：继续修改。\n\n任务：根据用户描述的问题、报错或不顺手之处继续调试。优先复现和定位，不要盲改；能运行测试就运行测试。\n\n输出：原因判断、修改记录、测试结果、仍需确认的问题，并更新当前项目 05-修改记录.md。",
          "ai-coding-feature-add": "AI编程：添加新功能。\n\n任务：读取当前项目资料、已有产物和用户填写的想加功能、加在哪里、不能影响什么；先判断是否适合现在加，再给出安全添加方案。能直接修改文件时直接修改并验证。\n\n要求：不要重新开项目；不要为了加新功能破坏已有主流程；如果新功能会影响第一版稳定性，先给出分阶段建议。\n\n输出：功能影响分析、修改方案、已修改文件、验证方式、回滚建议，并更新当前项目 05-修改记录.md；必要时更新 03-版本计划.md。",
          "ai-coding-deploy": "AI编程：发布部署。\n\n任务：整理当前项目发布/交付步骤，生成运行说明、部署清单、版本记录、回滚方案和交付注意事项。\n\n输出：发布清单、部署命令、检查项、风险点、交付说明，并更新当前项目 06-发布交付.md。",
          "ai-coding-retrospective": "AI编程：迭代复盘。\n\n任务：复盘本轮 AI 编程项目，整理已完成功能、未完成事项、Bug、技术债、下一轮优先级。\n\n输出：复盘总结、问题清单、下轮计划、可复用经验，并更新当前项目 07-下轮计划.md。",
          "self-media-bestseller-learning": `自媒体：学习爆款方法。

任务：根据用户填写的平台/赛道、账号定位、目标用户和参考样本，拆解这个赛道的爆款共性。

输出：选题底层规律、标题规律、开头规律、正文结构规律、可复用公式、不要照抄的风险点、下一步建议。

归档建议：山竹智能体知识库/IP内容生产/06-我的脚本工坊/爆款方法-日期.md。`,
          "self-media-content-type": `自媒体：选择内容类型。

任务：根据主题、目标用户、业务目标和素材，判断最适合的内容类型：教知识、聊观点、讲故事、晒过程或混合。

输出：推荐类型、为什么适合、备用类型、对应脚本结构、标题方向、下一步脚本写作提示。

要求：不要泛泛建议，必须给出可直接进入写作的结构。`,
          "self-media-script-writing": `自媒体：脚本模板与写作。

任务：按用户填写的内容类型、视频时长、语气风格、主题和素材，生成完整口播脚本。

结构必须包含：标题候选、封面文案、前3秒钩子、痛点/关联、主体展开、收束/CTA、逐段口播、画面/字幕建议。

归档建议：山竹智能体知识库/IP内容生产/06-我的脚本工坊/脚本-主题-日期.md。`,
          "self-media-hook-optimizer": `自媒体：三秒钩子优化。

任务：基于原脚本或主题，生成多版前 3 秒开头，并按平台和目标用户筛选。

输出：结果型、反差型、痛点型、身份信号型、悬念型钩子；每条给适用场景、风险、推荐指数；最后给最佳 3 条和替换后的脚本开头。`,
          "self-media-data-review": `自媒体：发布后数据复盘。

任务：基于用户填写的播放/曝光、点击率、3秒留存、完播、互动、关注/私信/成交等数据，判断内容问题在哪。

输出：数据诊断、问题定位、保留项、删除项、下一条优化方案、可复用经验卡。

归档建议：山竹智能体知识库/IP内容生产/06-我的脚本工坊/复盘-主题-日期.md。`,
          "self-media-script-workshop": `自媒体：我的脚本工坊归档。

任务：把用户提供的新脚本、爆款拆解、经验卡、复盘结论或选题库整理成 Obsidian Markdown 资产。

要求：根据归档类型自动选择文件名和结构；写入 山竹智能体知识库/IP内容生产/06-我的脚本工坊/ 下的合适文件；保留可复用结论和下一步动作。`,
          "ai-imagegen-prompt": "AI出图：提示词生成。\n\n任务：读取操作面板参数，把图片需求拆成可复制到 GPT 图像模型、即梦、可灵或其他平台的出图提示词。\n\n输出：出图条件判断、正向提示词、负面词、尺寸/比例建议、构图说明、风格词、参数建议、归档建议。\n\n强制归档：把本次最终提示词保存为一篇新笔记，位置：山竹智能体知识库/AI出图/提示词记录/YYYY-MM-DD-HHmm-主题.md，并在回复最后写出该笔记路径，方便下一步一键出图读取。\n\n要求：第一步只生成提示词，不直接出图；如果计划使用模型为暂未接入，只输出提示词和参数，不要声称已经生成图片。",
          "ai-imagegen-character": "AI出图：人物图。\n\n任务：读取操作面板参数，整理角色视觉设定卡，并生成保持人物一致性的系列出图提示词。\n\n输出：角色固定特征、可变特征、单图提示词、系列图提示词、参考图使用建议、负面词、变形规避、归档建议。\n\n强制归档：把最终可出图提示词保存为一篇新笔记，位置：山竹智能体知识库/AI出图/提示词记录/YYYY-MM-DD-HHmm-主题.md，并在回复最后写出该笔记路径。\n\n要求：第一步只生成提示词/方案，不直接出图；不凭空改变用户给定的人设。",
          "ai-imagegen-product": "AI出图：商品图。\n\n任务：读取操作面板参数，围绕商品卖点生成主图、场景图、详情页KV或带货素材图方案。\n\n输出：商品图策略、多图拆分清单、单张提示词、负面词、真实性/商用风险提醒、归档建议。\n\n强制归档：把最终可出图提示词保存为一篇新笔记，位置：山竹智能体知识库/AI出图/提示词记录/YYYY-MM-DD-HHmm-主题.md，并在回复最后写出该笔记路径。\n\n要求：第一步只生成商品图提示词/方案，不直接出图；不要夸大产品功效；没有真实参考图时不要声称精准还原实物。",
          "ai-imagegen-cover": "AI出图：封面图。\n\n任务：读取操作面板参数，为小说、短剧、课程、直播或短视频标题图生成封面视觉方案。\n\n输出：封面卖点判断、画面方案A/B/C、标题排版建议、正向提示词、负面词、尺寸建议、归档建议。\n\n强制归档：把最终可出图提示词保存为一篇新笔记，位置：山竹智能体知识库/AI出图/提示词记录/YYYY-MM-DD-HHmm-主题.md，并在回复最后写出该笔记路径。\n\n要求：第一步只生成封面提示词/方案，不直接出图；优先服务第一眼点击；保留用户给定标题和题材。",
          "ai-imagegen-style": "AI出图：风格图。\n\n任务：读取操作面板参数，把风格方向、自定义风格和适用用途整理成可复用风格图方案。\n\n输出：风格名称、适用用途、画面关键词、构图/光线/色彩建议、正向提示词、禁用词、示例提示词、复用注意。\n\n强制归档：把最终可出图提示词保存为一篇新笔记，位置：山竹智能体知识库/AI出图/提示词记录/YYYY-MM-DD-HHmm-主题.md，并在回复最后写出该笔记路径。\n\n要求：第一步只生成风格提示词/方案，不直接出图；风格词要服务具体用途，避免空泛堆词。",
          "ai-imagegen-generate": `AI出图：一键出图。

任务：优先读取 山竹智能体知识库/AI出图/提示词记录/ 里最新一篇提示词记录；如果用户手动填写了最终提示词，则优先使用手动提示词。不要把 10/20/30/40/50/70 这些功能入口页当作最终提示词。

强制要求：这一步不是继续写提示词；如果当前环境有 GPT 图像模型、imagegen 工具、即梦、可灵或其他可调用出图平台，必须直接调用模型生成图片。生成后把图片保存到 zahuo/AI出图/，文件名用 日期-主题-序号，并在回复里用 ![[zahuo/AI出图/文件名.png]] 展示。

归档：同时把最终提示词、负面词、模型/平台、尺寸、参考图、成图路径、修改建议写入 山竹智能体知识库/AI出图/02-出图归档索引.md 或新建对应归档笔记。

兜底：只有在确实没有任何可用出图模型/工具时，才说明未接入模型，并输出可复制到即梦/可灵/GPT 图像模型的最终提示词。`,
          "ai-imagegen-image-to-image": `AI出图：图生图 / 改图。

任务：读取操作面板参数中的原图路径和修改要求。优先把“原图路径”作为参考图或编辑目标：如果用户选择“基于原图改图/局部修改/改文字/换背景”，按编辑图处理；如果用户选择“参考原图出新图/换风格”，按参考图生成新图处理。

强制要求：这一步不是只写提示词。当前环境有 imagegen / GPT 图像模型 / 其他可用出图工具时，必须直接读取图片并生成结果。生成后把图片保存到 zahuo/AI出图/，文件名用 日期-图生图-主题-序号，并在回复里用 ![[zahuo/AI出图/文件名.png]] 展示。

图片读取：原图可能是桌面绝对路径，也可能是 vault 相对路径。先检查路径是否存在；如果是本地图片，先用 view_image 查看，明确它是“编辑目标”还是“参考图”。不要忽略用户选择的图片。

边界：用户没有明确要求时，尽量保留原图主体、构图和真实商品信息；不要编造品牌、认证、功效、检测报告或不存在的包装文字。涉及即梦/可灵等可能消耗积分的平台时，先填提示词并等待用户确认，不要擅自点击生成。

归档：同时把原图路径、处理方式、最终提示词/修改要求、成图路径、问题复盘写入 山竹智能体知识库/AI出图/出图记录/ 或 山竹智能体知识库/AI出图/02-出图归档索引.md。

兜底：只有在确实没有任何可用出图/改图工具时，才说明未接入模型，并输出可复制到 GPT 图像模型、即梦或可灵的图生图提示词。`,
          "ai-imagegen-archive": "AI出图：出图归档与复盘。\n\n任务：读取操作面板参数，把提示词、成图反馈、修改意见或风格经验整理成可复用归档。\n\n输出：归档标题、使用场景、模型/平台、原始提示词、最终提示词、问题复盘、可复用经验、下次优化方向。\n\n归档建议：写入 山竹智能体知识库/AI出图/02-出图归档索引.md 或对应专题笔记。",
          "platform-product-mining": "平台自动找品。请使用 platform-product-mining Skill，读取操作面板参数，直接执行并归档。浏览器只用 Kimi WebBridge；登录、验证码、风控由用户处理。",
          "short-video-install-capabilities": "短视频带货系统能力安装 / 自检。请使用 short-video-install-capabilities Skill，检查必要插件、Kimi WebBridge、Vault 写入和工作流 Skills，并更新系统能力清单。",
          "product-records": "选品总记录。任务：默认读取最新 AI 选品评分结果，把所有候选品整理成可查询、可复用的选品总台账。资料读取优先级：1）用户指定笔记路径；2）最新 山竹智能体知识库/短视频带货/AI选品评分/；3）已有选品记录；4）内容形式判断、短视频脚本、制作视频相关记录。\n\n必须写入/更新：山竹智能体知识库/短视频带货/选品记录/00-选品总记录.md。\n\n总记录结构必须包含：商品名称、平台/链接、价格、佣金、评分/TOP 排名、推荐理由、风险点、当前状态（待测/已出脚本/已出视频/已跑量/已淘汰）、关联评分笔记、关联内容形式判断、关联脚本、关联视频提示词/制作记录、评论反馈、跑量数据、下一步动作。\n\n如果用户在“选择商品/历史记录”里选了某个商品或选择“查看单品历史情况/脚本”，就只汇总该商品的历史选品情况、已生成脚本、视频记录和下一轮建议。若用户选择“生成/更新选品总台账”，就汇总所有商品。不要只生成单条空记录。",
          "product-selection-score": "AI 选品评分。请使用 product-selection-score Skill。候选商品输入优先级：用户粘贴数据 > 执行前重新扫描并读取 山竹智能体知识库/短视频带货/平台找品/ 最新一份找品产出；不要把 AI选品评分 目录里的旧评分结果当成本轮输入。输出评分、TOP 推荐、风险和下一步；评分后默认用 Kimi WebBridge 为 TOP3 商品采集真实主图，保存到 山竹智能体知识库/短视频带货/素材库/商品主图/，并把本地主图路径写入评分结果，供后续图生视频读取。",
          "product-content-fit": "内容形式判断。请使用 product-content-fit Skill，读取操作面板参数和产品资料，判断图文、AI 视频、真人实拍、直播切片或混合打法，并归档。",
          "video-duration-calculator": "视频秒数测算。请使用 video-duration-calculator Skill，读取操作面板参数，判断推荐时长、备用测试时长、结构占比和删改建议。",
          "jimeng-kling-prompt-builder": "即梦/可灵提示词生成。请使用 jimeng-kling-prompt-builder Skill，读取操作面板参数和脚本/商品图；如果参考图为空，默认读取最新 AI选品评分 结果里的 TOP3 本地主图路径，或扫描 山竹智能体知识库/短视频带货/素材库/商品主图/ 最新主图。强制要求：输出给即梦/可灵的主提示词必须包含带货口播/旁白、符合视频内容和产品场景的音乐/BGM、字幕/CTA；即使用户没有单独填写，也要自动补齐。不要只输出无声画面提示词。输出可复制的视频提示词、负面词和分镜建议，并归档。",
          "ai-video-submit-confirm": "AI 视频平台提交确认。请使用 ai-video-submit-confirm Skill 和 Kimi WebBridge，填入提示词；如果读取到的视频提示词缺少带货口播/旁白或符合内容的音乐/BGM要求，先自动补齐后再填入平台。如果参考图为空，默认读取最新 AI选品评分/TOP3主图归档里的本地主图路径并尝试上传；点击生成前必须等待用户明确确认。",
          "short-video-scripting": "脚本口播生成。请使用 short-video-scripting Skill，读取操作面板参数和上游资料，生成钩子、口播、分镜、字幕、BGM、CTA，并归档。",
          "showcase-confirm-add": "确认添加橱窗 / 选品车。请使用 showcase-confirm-add Skill 和 Kimi WebBridge，先整理待添加清单并等待用户确认；确认前不得点击添加。",
          "novel-project-create": "写小说：新建小说项目。\n\n任务：根据用户填写的【项目名】在 山竹智能体知识库/写小说/作品项目/ 下创建一个独立小说项目。项目名就是后续首页显示的名字；不要覆盖已有同名项目；如果同名项目已存在，先提示用户换名或确认使用现有项目。\n\n必须创建：\n1. 00-项目总控.md：包含 frontmatter（title、project、status、stage、current_node、current_node_path、current_chapter、updated、summary、cssclasses: [senxue-workflow-page]）。新项目创建完成后的 current_node 写“世界观设定”，current_node_path 写该项目的 02-世界观设定.md，并写入 senxue-workflow 代码块：page: novel-project-workbench、project_name、project_path。\n2. 01-爆款参考与仿写.md：page: novel-project-bestseller。\n3. 02-世界观设定.md：page: novel-project-worldbuilding。\n4. 03-人设关系.md：page: novel-project-character。\n5. 04-大纲规划.md：page: novel-project-outline。\n6. 05-正文续写.md：page: novel-project-draft。\n7. 06-质检润色.md：page: novel-project-qc。\n8. 章节正文/00-章节目录.md。\n\n同时写入首版项目卡：目标平台、题材、读者、核心爽点、主角方向、禁区、下一步建议。\n\n完成后输出：创建的文件列表、建议先打开 02-世界观设定.md 继续。",
          "novel-project-bestseller": "写小说：项目内爆款参考 / 仿写改造。\n\n任务：先读取用户填写的小说项目路径下的 00-项目总控.md、01-爆款参考与仿写.md、02-设定库.md；再按题材和样本做爆款拆解与差异化改造。\n\n输出并归档回当前项目的 01-爆款参考与仿写.md：爆款候选表、可仿结构、不可沿用元素、差异化设定、开篇钩子、前 10 章爽点建议。\n\n要求：需要最新榜单时先联网核验并给出来源；读不到字段写“未读取到”；不复制原文表达。",
          "novel-project-worldbuilding": "写小说：项目内世界观设定。\n\n任务：先读取当前小说项目路径下的 00-项目总控.md、01-爆款参考与仿写.md、02-世界观设定.md；再补齐世界规则、时代背景、势力、地点、限制条件和不能破坏的设定边界。\n\n输出并归档回当前项目的 02-世界观设定.md：世界类型、核心规则、能力边界、势力关系、关键地点、资源/制度/等级、禁用设定、可用于章节冲突的设定清单。\n\n要求：先定世界规则，再做人设；不要设定堆砌，要服务剧情冲突和爽点。",
          "novel-project-character": "写小说：项目内人设关系。\n\n任务：先读取当前小说项目路径下的 00-项目总控.md、01-爆款参考与仿写.md、02-世界观设定.md、03-人设关系.md；再生成主角、反派、配角、关系张力、欲望、秘密、成长线和冲突触发器。\n\n输出并归档回当前项目的 03-人设关系.md：人物表、关系网、人物动机、秘密与代价、不可崩设定、前 10 章人物变化点、可制造冲突的场景。\n\n要求：人物要符合世界规则；不能只写标签，要有具体欲望、代价和行动方式。",
          "novel-project-settings": "写小说：项目内旧版设定库维护。\n\n任务：兼容旧项目。优先建议拆成 02-世界观设定.md 和 03-人设关系.md。若用户仍使用旧版 02-设定库.md，则读取项目总控、爆款参考、设定库、大纲后维护旧设定库。\n\n输出：保留已有设定并标注新增/修改/冲突。",
          "novel-project-outline": "写小说：项目内大纲规划。\n\n任务：先读取当前小说项目路径下的项目总控、世界观设定、人设关系、大纲和最近章节目录；再更新主线卷纲或章节场景卡。此流程合并主线/卷纲规划和章节大纲/场景卡。\n\n输出并归档回当前项目的 04-大纲规划.md：主线目标、阶段爽点、前 10/30 章节奏、下一章场景卡、伏笔表、结尾钩子、不能发生的事。\n\n要求：围绕当前项目连续推进；不要每次重新开书。",
          "novel-project-draft": "写小说：项目内正文续写。\n\n任务：先读取当前小说项目路径下的 00-项目总控.md、02-世界观设定.md、03-人设关系.md、04-大纲规划.md、章节正文/00-章节目录.md 和最近章节；再根据用户本次要求续写正文。\n\n输出：正文草稿、承接说明、下一章钩子、建议保存文件名。必要时把新章节归档到当前项目的 章节正文/ 文件夹。\n\n要求：保持人物状态、时间线和信息差连续；多用动作、对话、细节推进；少用空泛总结；不要提前泄露未到时机的信息。",
          "novel-project-qc": "写小说：项目内连续性 / 质检润色。\n\n任务：先读取当前小说项目路径下的世界观设定、人设关系、大纲、章节目录和待检查正文；再做时间线、伏笔、人物动机、节奏、AI 味和标点格式检查。\n\n输出并归档回当前项目的 06-质检润色.md：问题清单、严重程度、涉及章节、修复建议、润色后片段、后续禁止事项。\n\n要求：不要泛泛而谈；必须指出具体矛盾或具体 AI 腔句子。",
          "novel-bestseller-mining": "写小说：找爆款。\n\n任务：先读取用户填写的【项目名】；项目名必填，用于归档和首页继续节点显示。再按平台/来源、题材/关键词、榜单/范围和数量，寻找或整理小说爆款样本，并拆解可仿结构。\n\n输出：\n- 爆款候选表：书名/平台/题材/状态/热度证据/简介/开篇钩子/主角人设/核心爽点/节奏特征/可仿点/风险点。\n- TOP 推荐：最值得参考的 3 个方向。\n- 爆款共性总结：题材、人设、金手指、矛盾源、章节钩子。\n- 仿写切入建议：只仿结构、节奏和读者期待，不复制原文。\n- 下一步建议：进入“仿写爆款”。\n\n归档要求：归档到 山竹智能体知识库/写小说/找爆款/，文件 frontmatter 必须包含 project、current_node: 仿写爆款、current_node_path: 山竹智能体知识库/写小说/仿写爆款/00-仿写爆款.md、updated、summary。文件名优先用 日期-项目名-找爆款报告.md。归档后把报告链接写入 00-索引.md；不要再在操作页展示归档报告区。\n\n其他要求：如果需要最新榜单或外部页面，先联网核验并给出来源；不绕过登录、付费、验证码或风控；读不到字段写“未读取到”。",
          "novel-bestseller-imitation": "写小说：仿写爆款。\n\n任务：基于用户提供的爆款样本或找爆款报告，做差异化仿写方案。优先沿用用户填写的【项目名】；如果留空，就从上一环节 frontmatter 的 project 读取。仿题材机制、节奏、爽点和读者期待，不仿具体句子、专名、人物关系或核心桥段。\n\n输出：\n- 反抄袭边界：哪些元素不能沿用。\n- 仿写策略：可复用结构、必须差异化的设定。\n- 3 个差异化新书方向。\n- 10 个书名备选。\n- 3 版简介。\n- 主角/反派/金手指/核心矛盾设定。\n- 前 10 章爽点节奏表。\n- 开篇 300-800 字试写。\n\n归档要求：归档到 山竹智能体知识库/写小说/仿写爆款/，文件 frontmatter 必须包含 project、current_node: 项目初始化、current_node_path: 山竹智能体知识库/写小说/作品项目/00-作品项目初始化.md、updated、summary。文件名优先用 日期-项目名-仿写方案.md。\n\n要求：不要复刻原文表达；发现样本不足时先说明缺口，再给保守方案。",
          "novel-project-setup": "写小说：作品项目初始化。\n\n任务：读取用户填写的【项目名】，把一句话创意、目标平台/读者、题材类型、参考爆款和禁区整理成可长期写作的项目卡。如果该项目文件夹不存在，就在 山竹智能体知识库/写小说/作品项目/项目名/ 下创建项目；如果已存在，就更新项目总控。\n\n输出：作品定位、目标读者、核心卖点、主角承诺、主线矛盾、金手指/机制、前 3 秒式开篇钩子、平台风险、不能写的雷点、后续需要补齐的设定清单。\n\n项目记录要求：更新 00-项目总控.md frontmatter，必须包含 project、status、stage、current_node: 世界观设定、current_node_path: 该项目/02-世界观设定.md、updated、summary、cssclasses: [senxue-workflow-page]。下一步明确进入世界观设定。\n\n归档建议：山竹智能体知识库/写小说/作品项目/。",
          "novel-character-web": "写小说：人设关系网。\n\n任务：基于作品项目卡，生成主角、反派、配角、关系张力、欲望、秘密、成长线和冲突触发器。\n\n输出：人物表、关系网、人物动机、不可崩设定、可制造冲突的场景、前 10 章人物变化点。\n\n要求：人物不能只写标签，要有具体欲望、代价和行动方式。",
          "novel-worldbuilding": "写小说：世界观设定。\n\n任务：整理世界规则、时代背景、势力、地点、限制条件和设定边界。\n\n输出：世界观总表、核心规则、资源/等级/制度、势力关系、地图/地点、限制条件、不能破坏的规则、可用于章节冲突的设定清单。\n\n要求：避免设定堆砌，优先服务剧情冲突和爽点。",
          "novel-plot-arc": "写小说：主线 / 卷纲规划。\n\n任务：基于项目卡、人设和世界观，规划主线目标、阶段爽点、反转、卷尾钩子和持续追读理由。\n\n输出：主线一句话、第一卷目标、阶段事件表、每 3-5 章爽点安排、反派推进、伏笔埋设、卷尾钩子、前 30 章节奏表。\n\n要求：不要平均用力；前 3 章必须有明确钩子和反馈。",
          "novel-scene-card": "写小说：章节大纲 / 场景卡。\n\n任务：把卷纲或上一章状态拆成可直接写正文的章节场景卡。\n\n输出：本章目标、上章承接、时间地点、出场人物、冲突、信息差、关键动作、对话目标、爽点、结尾钩子、不能发生的事。\n\n要求：一章一目标，不要把多个大事件塞进同一场景卡。",
          "novel-timeline-foreshadowing": "写小说：时间线与伏笔检查。\n\n任务：检查大纲或正文中的时间线、人物信息差、伏笔回收、设定冲突和突兀新增设定。\n\n输出：问题清单、严重程度、涉及章节/人物、为什么有问题、修复建议、需要回收的伏笔表、后续禁止事项。\n\n要求：不要只说“需要优化”，要指出具体矛盾点。",
          "novel-chapter-draft": "写小说：正文续写。\n\n任务：基于上一章、场景卡和目标字数，续写一段可读正文。\n\n输出：正文；必要时附“承接说明”和“下一章钩子”。\n\n要求：多用动作、对话、细节和停顿推进；少用总结和空泛抒情；不跳过关键冲突；保持上一章状态连续；不要提前泄露未到时机的信息。",
          "novel-polish-qc": "写小说：润色去 AI 味 / 质检。\n\n任务：对正文片段进行去 AI 味润色或质检。\n\n输出：问题清单、修改原则、润色后正文、保留原意说明、标点/格式检查、节奏和爽点建议。\n\n要求：删除空泛总结、宏大抽象词、重复排比和 AI 腔；增加具体动作、物件、对话和人物反应。"
    };
    return prompts[workflow] || "";
  }

  toggleKnowledgeFolder(target) {
    const item = target.closest(".knowledge-tree-item.folder");
    const path = target.getAttribute("data-senxue-toggle-folder");
    if (!item || !path) return;
    const willOpen = !item.classList.contains("is-open");
    item.classList.toggle("is-open", willOpen);
    item.setAttribute("aria-expanded", String(willOpen));
    if (willOpen) {
      this.expandedKnowledgePaths.add(path);
      this.collapsedKnowledgePaths.delete(path);
    } else {
      this.expandedKnowledgePaths.delete(path);
      this.collapsedKnowledgePaths.add(path);
    }
  }

  switchModule(moduleName, root) {
    const dashboards = root ? [root] : this.getDashboardRoots();
    for (const dashboard of dashboards) {
      dashboard.dataset.senxueActiveModule = moduleName;
      dashboard.querySelectorAll("[data-senxue-module]").forEach((item) => {
        item.classList.toggle("nav-active", item.getAttribute("data-senxue-module") === moduleName);
      });
      dashboard.querySelectorAll(".module-view[data-senxue-view]").forEach((view) => {
        view.classList.toggle("is-active", view.getAttribute("data-senxue-view") === moduleName);
      });
    }
  }

  scheduleWorkflowPreviewMode() {
    this.workflowPreviewScheduleVersion += 1;
    const version = this.workflowPreviewScheduleVersion;
    this.runtimeScope.timeout(() => {
      if (version === this.workflowPreviewScheduleVersion) this.ensureWorkflowPreviewMode();
    }, 120);
  }

  async ensureWorkflowPreviewMode() {
    const leaves = this.app.workspace.getLeavesOfType("markdown");
    for (const leaf of leaves) {
      const view = leaf.view;
      if (!(view instanceof MarkdownView)) continue;
      if (!this.shouldForcePreviewFile(view.file)) continue;
      const state = view.getState();
      if (state.mode === "preview" && state.source === false) continue;
      try {
        await view.setState({ ...state, mode: "preview", source: false }, { history: false });
      } catch (error) {
        console.warn("Senxue workbench: failed to force preview mode", view.file?.path, error);
      }
    }
  }

  shouldForcePreviewFile(file) {
    if (!(file instanceof TFile)) return false;
    if (FORCE_PREVIEW_FILES.has(file.path)) return true;
    const frontmatter = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
    const classes = frontmatter.cssclasses || frontmatter.cssclass;
    if (Array.isArray(classes)) return classes.includes("senxue-workflow-page") || classes.includes("senxue-dashboard");
    if (typeof classes === "string") return /\bsenxue-(workflow-page|dashboard)\b/.test(classes);
    return false;
  }

  async openVaultPath(path) {
    if (!path) return;
    try {
      let file = findVaultFile(this.app, path, WORKBENCH_FILE, (candidate) => candidate instanceof TFile);
      if (!(file instanceof TFile)) {
        const fallbackPath = this.resolveAICodingProjectLegacyPath(path);
        if (fallbackPath && fallbackPath !== path) {
          file = findVaultFile(this.app, fallbackPath, WORKBENCH_FILE, (candidate) => candidate instanceof TFile);
          if (file instanceof TFile) path = fallbackPath;
        }
      }
      if (!(file instanceof TFile)) {
        await this.sleep(250);
        file = findVaultFile(this.app, path, WORKBENCH_FILE, (candidate) => candidate instanceof TFile);
      }
      if (!(file instanceof TFile)) {
        new Notice(`找不到知识库页面：${path}`);
        return false;
      }
      const leaf = this.app.workspace.getLeaf(false);
      await leaf.openFile(file, { active: true });
      this.app.workspace.setActiveLeaf(leaf, { focus: true });
      if (leaf.view instanceof MarkdownView) {
        const state = leaf.view.getState();
        await leaf.view.setState({ ...state, mode: "preview", source: false }, { history: false });
      }
      return true;
    } catch (error) {
      console.warn("Senxue workbench: failed to open vault path", path, error);
      new Notice("打开知识库条目失败");
      return false;
    }
  }

  resolveAICodingProjectLegacyPath(path) {
    if (!path || !path.includes("山竹智能体知识库/AI编程/项目库/")) return "";
    const legacyMap = {
      "01-需求拆解.md": "01-我的想法.md",
      "02-功能拆解.md": "02-功能清单.md",
      "03-第一版.md": "03-版本计划.md",
      "04-试用修改.md": "04-试用反馈.md",
      "05-添加功能.md": "05-修改记录.md",
      "06-交付复盘.md": "06-发布交付.md"
    };
    for (const [oldName, newName] of Object.entries(legacyMap)) {
      if (path.endsWith(`/${oldName}`)) return path.slice(0, -oldName.length) + newName;
    }
    return "";
  }

  async openClaudianPanel(options = {}) {
    try {
      const panel = await this.claudianAdapter.open(options);
      await this.refreshDashboard(false);
      return panel;
    } catch (error) {
      console.warn("Senxue workbench: failed to open Claudian", error);
      new Notice(error?.code === "UNAVAILABLE"
        ? "AI 对话插件未连接，请先在设置中启用山竹智能体"
        : "AI 对话没有准备好，请检查山竹智能体是否已启用，或关闭多余标签后重试");
      return null;
    }
  }

  sleep(ms) {
    return this.runtimeScope.sleep(ms);
  }

  scheduleRefresh() {
    this.refreshScheduleVersion += 1;
    const version = this.refreshScheduleVersion;
    this.runtimeScope.timeout(() => {
      if (version === this.refreshScheduleVersion) this.refreshDashboard(false);
    }, 350);
  }

  async pollConversationChanges() {
    const snapshot = this.claudianAdapter.getConversationSnapshot();
    const signature = createConversationSignature(snapshot);
    if (signature === this.lastConversationSignature) return;
    await this.refreshDashboard(false, snapshot);
  }

  async openWorkbench(startup) {
    const file = this.app.vault.getAbstractFileByPath(WORKBENCH_FILE);
    if (!(file instanceof TFile)) {
      if (!startup) new Notice(`找不到工作台首页：${WORKBENCH_FILE}`);
      return;
    }

    try {
      if (this.app.workspace.leftSplit && !this.app.workspace.leftSplit.collapsed) this.app.workspace.leftSplit.collapse();
      if (this.app.workspace.rightSplit && !this.app.workspace.rightSplit.collapsed) this.app.workspace.rightSplit.collapse();
    } catch (error) {
      console.warn("Senxue workbench: failed to collapse sidebars", error);
    }

    let leaf = this.app.workspace.getLeavesOfType("markdown")
      .find((candidate) => candidate.view && candidate.view.file && candidate.view.file.path === file.path);
    if (!leaf) leaf = this.app.workspace.getLeaf(false);

    await leaf.openFile(file, { active: true });
    this.app.workspace.setActiveLeaf(leaf, { focus: true });

    if (leaf.view instanceof MarkdownView) {
      const state = leaf.view.getState();
      await leaf.view.setState({ ...state, mode: "preview", source: false }, { history: false });
    }

    try {
      leaf.setPinned(true);
      this.app.workspace.requestSaveLayout();
    } catch (error) {
      console.warn("Senxue workbench: failed to save layout", error);
    }

    await this.refreshDashboard(false);
  }

  async ensureDashboardShell(root) {
    if (!root || root.querySelector(".dashboard-app-shell")) return true;
    const file = this.app.vault.getAbstractFileByPath(WORKBENCH_FILE);
    if (!(file instanceof TFile)) return false;

    const source = await this.app.vault.cachedRead(file);
    const shellStart = source.indexOf('<div class="dashboard-app-shell">');
    if (shellStart < 0) return false;
    const template = document.createElement("template");
    template.innerHTML = source.slice(shellStart).trim();
    const shell = template.content.querySelector(".dashboard-app-shell");
    if (!shell) return false;

    const container = root.querySelector(".markdown-preview-sizer") || root;
    shell.setAttribute("data-senxue-mounted", "plugin");
    container.appendChild(shell);
    const requestedModule = root.dataset.senxueActiveModule || "home";
    const hasRequestedModule = Boolean(
      shell.querySelector(`[data-senxue-view="${requestedModule}"]`)
    );
    this.switchModule(hasRequestedModule ? requestedModule : "home", root);
    return true;
  }

  refreshDashboard(manual, conversationSnapshot = null) {
    const signature = conversationSnapshot
      ? createConversationSignature(conversationSnapshot)
      : "";
    return this.dashboardRefresh.request({
      manual: Boolean(manual),
      snapshot: conversationSnapshot,
      signature
    });
  }

  async performDashboardRefresh({ manual, snapshot: conversationSnapshot }) {
    const dashboards = this.getDashboardRoots();

    try {
      for (const root of dashboards) await this.ensureDashboardShell(root);
      const data = await this.dashboardService.collect({
        conversationSnapshot,
        trendDays: this.conversationTrendDays
      });
      this.refreshWorkflowTaskFeedback();
      this.refreshProjectPlaceholderGrids();
      if (dashboards.length === 0) return { applied: true };
      for (const root of dashboards) this.renderDashboard(root, data);
      this.disableDashboardCardPreviews(document);
      if (manual) new Notice("Workbench data refreshed");
      return { applied: true };
    } catch (error) {
      console.warn("Senxue workbench: failed to refresh dashboard", error);
      const fallback = this.dashboardService.buildUnavailable({
        trendDays: this.conversationTrendDays
      });
      for (const root of dashboards) this.renderDashboard(root, fallback);
      this.disableDashboardCardPreviews(document);
      return { applied: false };
    }
  }

  getDashboardRoots() {
    return Array.from(document.querySelectorAll(".markdown-preview-view.senxue-dashboard"));
  }


  collectKnowledgeData() {
    const files = this.app.vault.getFiles();
    const visibleFiles = files.filter((file) => this.shouldShowVaultItem(file) && this.isWorkbenchKnowledgePath(file.path));
    const markdownFiles = visibleFiles.filter((file) => file.extension === "md");
    const root = this.app.vault.getAbstractFileByPath(WORKBENCH_KNOWLEDGE_ROOT);
    const children = Array.isArray(root?.children) ? root.children : [];
    const visibleChildren = children
      .filter((child) => this.shouldShowVaultItem(child))
      .filter((child) => Boolean(child?.children))
      .sort((a, b) => this.sortVaultItems(a, b));
    const tree = visibleChildren.map((child) => this.buildKnowledgeTreeNode(child, 0));
    const folders = tree.filter((node) => node.type === "folder");
    const rootNotes = tree.filter((node) => node.type === "file" && node.extension === "md");
    return { tree, folders, rootNotes, totalMarkdown: markdownFiles.length, totalFiles: visibleFiles.length };
  }

  isWorkbenchKnowledgePath(path) {
    return Boolean(path) && (path === WORKBENCH_KNOWLEDGE_ROOT || path.startsWith(`${WORKBENCH_KNOWLEDGE_ROOT}/`));
  }

  shouldShowVaultItem(item) {
    if (!item || !item.name) return false;
    if (item.name.startsWith(".")) return false;
    if (item.path && item.path.split("/").some((part) => part.startsWith("."))) return false;
    return true;
  }

  sortVaultItems(a, b) {
    const aFolder = Boolean(a?.children);
    const bFolder = Boolean(b?.children);
    if (aFolder !== bFolder) return aFolder ? -1 : 1;
    return (a?.name || "").localeCompare(b?.name || "", "zh-CN", { numeric: true });
  }

  buildKnowledgeTreeNode(item, depth) {
    const isFolder = Boolean(item?.children);
    if (!isFolder) {
      return {
        type: "file",
        name: item.basename || item.name,
        fileName: item.name,
        path: item.path,
        extension: item.extension || "",
        depth,
        time: item.stat?.mtime ? this.formatShortDate(item.stat.mtime) : "--",
        mtime: item.stat?.mtime || 0
      };
    }
    const children = (Array.isArray(item.children) ? item.children : [])
      .filter((child) => this.shouldShowVaultItem(child))
      .sort((a, b) => this.sortVaultItems(a, b))
      .map((child) => this.buildKnowledgeTreeNode(child, depth + 1));
    const fileCount = children.reduce((sum, child) => sum + (child.type === "folder" ? child.fileCount : 1), 0);
    const mdCount = children.reduce((sum, child) => sum + (child.type === "folder" ? child.mdCount : (child.extension === "md" ? 1 : 0)), 0);
    return {
      type: "folder",
      name: item.name,
      path: item.path,
      depth,
      children,
      fileCount,
      mdCount
    };
  }

  fileInfo(file) {
    return {
      path: file.path,
      name: file.basename || file.name.replace(/\.md$/i, ""),
      mtime: file.stat?.mtime || 0,
      time: file.stat?.mtime ? this.formatShortDate(file.stat.mtime) : "--"
    };
  }



  ensureFeatureHubCards(root) {
    if (!root) return;
    const grid = root.querySelector(".dashboard-feature-hub .feature-grid");
    if (!grid) return;
    const exists = (path) => Boolean(grid.querySelector(`[data-senxue-open-path="${path}"]`));
    if (!exists("山竹智能体知识库/AI出图/00-入口.md")) {
      const coding = grid.querySelector('[data-senxue-open-path="山竹智能体知识库/AI编程/00-入口.md"]');
      const card = document.createElement("a");
      card.className = "feature-card imagegen";
      card.setAttribute("data-senxue-open-path", "山竹智能体知识库/AI出图/00-入口.md");
      card.innerHTML = '<span class="feature-icon">图</span><span class="feature-badge warning">模型提醒</span><strong>AI出图</strong><em>提示词、人物一致性、商品图、封面图、风格参考</em><small>需接入 GPT图像 / 即梦 / 可灵</small>';
      if (coding) grid.insertBefore(card, coding);
      else grid.appendChild(card);
    }
  }

  renderDashboard(root, data) {
    this.ensureFeatureHubCards(root);
    this.disableDashboardCardPreviews(root);
    this.setField(root, "statusText", data.statusText);
    this.setField(root, "subtitle", data.subtitle);
    this.setField(root, "openDialogCount", data.openDialogCount);
    this.setField(root, "userMessageTotal", data.userMessageTotal);
    this.setField(root, "charTotal", data.charTotal);
    this.setField(root, "todayUserMessageTotal", data.todayUserMessageTotal);
    this.setField(root, "activityMeta", data.activityMeta || "真实任务");
    this.renderConversationTrend(root, data.conversationTrend);
    this.renderActivity(root, data.recent || []);
    this.renderTasks(root, data.runningTasks || []);
    this.renderEmployees(root, data.employees || []);
    this.renderKnowledge(root, data.knowledge || { folders: [], rootNotes: [] });
    this.renderData(root, data.dataCards || []);
    this.removeLegacyUsageFloat();
    this.disableDashboardCardPreviews(root);
  }

  removeLegacyUsageFloat() {
    document.querySelectorAll(".usage-float-box, #senxue-usage-orb").forEach((node) => node.remove());
    try {
      window.localStorage?.removeItem("senxue-usage-float-position");
    } catch (_) {}
  }

  disableDashboardCardPreviews(root) {
    if (!root) return;
    root.querySelectorAll(".feature-card, .quick-tile").forEach((card) => {
      card.classList.remove("internal-link");
      card.removeAttribute("data-href");
      card.removeAttribute("href");
      card.setAttribute("role", "button");
      card.setAttribute("tabindex", "0");
    });
  }

  setField(root, field, value) {
    const el = root.querySelector(`[data-senxue-field="${field}"]`);
    if (el) el.textContent = value == null ? "--" : String(value);
  }

  renderTasks(root, tasks) {
    const list = root.querySelector("[data-senxue-tasks-list]");
    if (!list) return;
    list.replaceChildren();
    if (!tasks.length) {
      list.appendChild(this.createEmpty("还没有从工作台发出的任务。选择业务板块后，填写信息并确认执行即可。"));
      return;
    }
    tasks.forEach((task) => {
      const card = this.createModuleCard(task.title, task.summary, [
        { text: task.status, cls: task.rawStatus === "failed" ? "status-error" : (task.rawStatus === "running" ? "status-running" : "status-standby") },
        { text: task.time || "--", cls: "purple" },
        { text: task.meta || "工作台任务" }
      ]);
      if (task.resultSummary) {
        const result = document.createElement("div");
        result.className = "senxue-task-result";
        result.textContent = `结果：${task.resultSummary}`;
        card.appendChild(result);
      }
      if (task.error) {
        const error = document.createElement("div");
        error.className = "senxue-task-error";
        error.textContent = `失败原因：${task.error}`;
        card.appendChild(error);
      }
      const actions = document.createElement("div");
      actions.className = "senxue-task-actions";
      const openable = (task.outputPaths || []).find((item) => item?.exists && item?.resolvedPath);
      if (openable) {
        const openButton = document.createElement("button");
        openButton.type = "button";
        openButton.className = "ai-action-button primary";
        openButton.setAttribute("data-senxue-open-result", openable.resolvedPath);
        openButton.textContent = "打开结果";
        actions.appendChild(openButton);
      }
      if (task.error && task.prompt) {
        const copyButton = document.createElement("button");
        copyButton.type = "button";
        copyButton.className = "ai-action-button";
        copyButton.setAttribute("data-senxue-copy-task-prompt", task.id);
        copyButton.textContent = "复制详细指令";
        actions.appendChild(copyButton);
      }
      if (actions.childElementCount) card.appendChild(actions);
      list.appendChild(card);
    });
  }

  renderEmployees(root, employees) {
    const list = root.querySelector("[data-senxue-employees-list]");
    if (!list) return;
    list.replaceChildren();
    if (!employees.length) {
      list.appendChild(this.createEmpty("当前没有打开的 AI 对话。点击右上角“新建对话”即可创建。"));
      return;
    }
    employees.forEach((employee) => {
      const card = this.createModuleCard(employee.title, employee.summary || STANDBY_TEXT, [
        { text: employee.status, cls: employee.running ? "status-running" : "status-standby" },
        { text: `${employee.messageCount} 条消息`, cls: "purple" },
        { text: employee.lastActive ? this.formatTime(employee.lastActive) : "--" }
      ]);
      list.appendChild(card);
    });
  }

  renderKnowledge(root, knowledge) {
    const list = root.querySelector("[data-senxue-knowledge-list]");
    if (!list) return;
    list.replaceChildren();
    const tree = knowledge.tree || [];
    if (!tree.length) {
      list.appendChild(this.createEmpty("暂未读取到知识库文件。"));
      return;
    }
    const treeWrap = document.createElement("div");
    treeWrap.className = "knowledge-file-tree";
    tree.forEach((node) => treeWrap.appendChild(this.createKnowledgeTreeNode(node)));
    list.appendChild(treeWrap);
  }

  renderData(root, cards) {
    const list = root.querySelector("[data-senxue-data-list]");
    if (!list) return;
    list.replaceChildren();
    if (!cards.length) {
      list.appendChild(this.createEmpty("暂时没有可核对的数据。"));
      return;
    }
    cards.forEach((card) => {
      const node = this.createModuleCard(`${card.title}: ${card.value}`, card.desc, [{ text: card.badge || "数据", cls: "gold" }]);
      list.appendChild(node);
    });
  }

  createModuleCard(title, desc, badges) {
    const card = document.createElement("div");
    card.className = "module-card";
    const head = document.createElement("div");
    head.className = "module-card-head";
    const titleEl = document.createElement("div");
    titleEl.className = "module-card-title";
    titleEl.textContent = title || "未命名";
    head.appendChild(titleEl);
    const descEl = document.createElement("div");
    descEl.className = "module-card-desc";
    descEl.textContent = desc || STANDBY_TEXT;
    const meta = document.createElement("div");
    meta.className = "module-card-meta";
    (badges || []).forEach((badge) => meta.appendChild(this.createBadge(badge.text, badge.cls)));
    card.append(head, descEl, meta);
    return card;
  }

  createBadge(text, cls) {
    const badge = document.createElement("span");
    badge.className = `module-badge ${cls || ""}`.trim();
    badge.textContent = text || "--";
    return badge;
  }

  createEmpty(text) {
    const empty = document.createElement("div");
    empty.className = "module-empty";
    empty.textContent = text;
    return empty;
  }

  createKnowledgeTreeNode(node) {
    const item = document.createElement("div");
    item.className = `knowledge-tree-item ${node.type}`;
    item.style.setProperty("--depth", String(node.depth || 0));

    if (node.type === "folder") {
      const defaultOpen = (node.depth || 0) === 0 && !this.collapsedKnowledgePaths.has(node.path);
      const isOpen = this.expandedKnowledgePaths.has(node.path) || defaultOpen;
      item.classList.toggle("is-open", isOpen);
      item.setAttribute("aria-expanded", String(isOpen));

      const row = document.createElement("button");
      row.className = "knowledge-tree-row folder-row";
      row.setAttribute("data-senxue-toggle-folder", node.path);
      row.title = node.path;

      const caret = document.createElement("span");
      caret.className = "knowledge-caret";
      caret.textContent = "›";
      const icon = document.createElement("span");
      icon.className = "knowledge-kind-icon";
      icon.textContent = "▰";
      const name = document.createElement("span");
      name.className = "knowledge-tree-name";
      name.textContent = node.name;
      const meta = document.createElement("small");
      meta.className = "knowledge-tree-meta";
      meta.textContent = `${node.mdCount || 0} 笔记 · ${node.fileCount || 0} 文件`;
      row.append(caret, icon, name, meta);

      const children = document.createElement("div");
      children.className = "knowledge-tree-children";
      (node.children || []).forEach((child) => children.appendChild(this.createKnowledgeTreeNode(child)));
      item.append(row, children);
      return item;
    }

    const row = document.createElement("a");
    row.className = "knowledge-tree-row file-row";
    row.setAttribute("data-senxue-open-path", node.path);
    row.href = node.path;
    row.title = node.path;
    const spacer = document.createElement("span");
    spacer.className = "knowledge-caret is-file";
    spacer.textContent = "";
    const icon = document.createElement("span");
    icon.className = "knowledge-kind-icon";
    icon.textContent = this.fileIcon(node.extension);
    const name = document.createElement("span");
    name.className = "knowledge-tree-name";
    name.textContent = node.name;
    const meta = document.createElement("small");
    meta.className = "knowledge-tree-meta";
    meta.textContent = node.extension ? `${node.extension} · ${node.time || "--"}` : (node.time || "--");
    row.append(spacer, icon, name, meta);
    item.appendChild(row);
    return item;
  }

  fileIcon(extension) {
    if (extension === "md") return "◇";
    if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(extension)) return "◉";
    if (["xlsx", "xls", "csv"].includes(extension)) return "▦";
    if (["pdf", "doc", "docx", "ppt", "pptx"].includes(extension)) return "▤";
    return "•";
  }

  renderActivity(root, recent) {
    const list = root.querySelector("[data-senxue-activity-list]");
    if (!list) return;
    list.replaceChildren();
    if (!recent.length) {
      list.appendChild(this.createActivityItem("✦", "暂无最近任务", "等待你发出新任务", "--"));
      return;
    }
    const icons = ["♙", "✦", "◇", "▵", "☷"];
    recent.forEach((item, index) => {
      const summary = item.summary || (item.count ? `上下文累计 ${item.count} 条任务` : "最近工作总结");
      list.appendChild(this.createActivityItem(icons[index % icons.length], item.title, summary, item.time));
    });
  }

  createActivityItem(icon, title, summary, time) {
    const item = document.createElement("div");
    item.className = "activity-item";
    const iconEl = document.createElement("span");
    iconEl.className = "activity-icon";
    iconEl.textContent = icon;
    const contentEl = document.createElement("span");
    contentEl.className = "activity-content";
    const titleEl = document.createElement("span");
    titleEl.className = "activity-title";
    titleEl.textContent = title;
    const summaryEl = document.createElement("span");
    summaryEl.className = "activity-summary";
    summaryEl.title = summary;
    summaryEl.textContent = summary;
    contentEl.append(titleEl, summaryEl);
    const timeEl = document.createElement("span");
    timeEl.className = "activity-time";
    timeEl.textContent = time;
    item.append(iconEl, contentEl, timeEl);
    return item;
  }

  renderConversationTrend(root, trend) {
    const safeTrend = trend || buildConversationTrend({ available: false }, this.conversationTrendDays);
    this.setField(root, "trendStart", safeTrend.startLabel);
    this.setField(root, "trendEnd", safeTrend.endLabel);
    this.setField(
      root,
      "trendSummary",
      !safeTrend.available
        ? "无法读取本机 AI 对话"
        : (safeTrend.empty
          ? "该范围内暂无对话更新"
          : `近 ${safeTrend.days} 天共更新 ${this.formatNumber(safeTrend.total)} 个对话`)
    );
    this.setField(
      root,
      "trendMeta",
      safeTrend.available
        ? `统计范围：近 ${safeTrend.days} 天 · 每个对话只按最近更新时间计入一次`
        : "请确认山竹智能体已启用；工作台不会用 0 代替不可用数据"
    );
    root.querySelectorAll("[data-senxue-trend-days]").forEach((button) => {
      const active = Number(button.getAttribute("data-senxue-trend-days")) === safeTrend.days;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", String(active));
    });
    this.renderChart(root, safeTrend.values || [], safeTrend.points || []);
  }

  renderChart(root, values, pointMetadata = []) {
    const line = root.querySelector("[data-senxue-chart-line]");
    const area = root.querySelector("[data-senxue-chart-area]");
    const dot = root.querySelector("[data-senxue-chart-dot]");
    const pointGroup = root.querySelector("[data-senxue-chart-points]");
    if (!line || !area) return;
    const points = this.buildChartPoints(values);
    const linePath = this.buildSmoothPath(points);
    area.setAttribute("d", `${linePath} L600,190 L0,190 Z`);
    line.setAttribute("d", linePath);
    const last = points[points.length - 1];
    if (dot && last) {
      dot.setAttribute("cx", String(last.x));
      dot.setAttribute("cy", String(last.y));
      dot.style.display = pointGroup ? "none" : "";
    }
    if (!pointGroup) return;
    pointGroup.replaceChildren();
    points.forEach((point, index) => {
      const metadata = pointMetadata[index] || {};
      const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      circle.setAttribute("class", "chart-point");
      circle.setAttribute("cx", String(point.x));
      circle.setAttribute("cy", String(point.y));
      circle.setAttribute("r", points.length > 7 ? "3" : "4.5");
      circle.setAttribute("tabindex", "0");
      circle.setAttribute("role", "img");
      const label = `${metadata.label || `第 ${index + 1} 天`}：${Number(metadata.value ?? values[index] ?? 0)} 个对话`;
      circle.setAttribute("aria-label", label);
      const title = document.createElementNS("http://www.w3.org/2000/svg", "title");
      title.textContent = label;
      circle.appendChild(title);
      pointGroup.appendChild(circle);
    });
  }

  buildChartPoints(values) {
    const width = 600, top = 18, bottom = 155;
    const safeValues = values.length ? values : [0, 0];
    const min = 0;
    const max = Math.max(0, ...safeValues);
    const spread = Math.max(1, max);
    return safeValues.map((value, index) => {
      const x = safeValues.length === 1 ? width : (index / (safeValues.length - 1)) * width;
      const normalized = (value - min) / spread;
      const y = bottom - normalized * (bottom - top);
      return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 };
    });
  }

  buildSmoothPath(points) {
    if (!points.length) return "M0,155 L600,155";
    if (points.length === 1) return `M0,${points[0].y} L600,${points[0].y}`;
    let path = `M${points[0].x},${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const midX = (prev.x + curr.x) / 2;
      path += ` C${midX},${prev.y} ${midX},${curr.y} ${curr.x},${curr.y}`;
    }
    return path;
  }

  formatNumber(value) {
    return new Intl.NumberFormat("zh-CN").format(Number(value || 0));
  }

  formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false });
  }

  formatShortDate(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleDateString("zh-CN", { month: "2-digit", day: "2-digit" });
  }

  dateKey(date) {
    return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
  }
};








