const {
  normalizeTaskStore,
  applyTaskSnapshot,
  extractOutputPaths
} = require("./task-store.cjs");
const {
  buildConversationMetrics,
  buildConversationTrend
} = require("./dashboard-model.cjs");

const STANDBY_TEXT = "暂无最新结果";
const TASK_MATCH_WINDOW_MS = 30 * 1000;
const TASK_TIME_ONLY_WINDOW_MS = 3 * 1000;

function normalizeTimestamp(value, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) return Number(fallback) || Date.now();
  return number < 10000000000 ? number * 1000 : number;
}

function extractMessageText(message) {
  let text = "";
  if (typeof message?.displayContent === "string" && message.displayContent.trim()) {
    text = message.displayContent;
  } else if (typeof message?.content === "string" && message.content.trim()) {
    text = message.content;
  } else if (Array.isArray(message?.contentBlocks)) {
    text = message.contentBlocks
      .filter((block) => block && block.type === "text")
      .map((block) => block.content || "")
      .join(" ");
  } else if (message?.content != null) {
    try { text = JSON.stringify(message.content); } catch (_) { text = String(message.content); }
  }
  return text
    .replace(/<current_note>[\s\S]*?<\/current_note>/g, " ")
    .replace(/<editor_selection[\s\S]*?<\/editor_selection>/g, " ")
    .replace(/<browser_selection[\s\S]*?<\/browser_selection>/g, " ")
    .replace(/<environment_context>[\s\S]*?<\/environment_context>/g, " ")
    .replace(/<turn_aborted>[\s\S]*?<\/turn_aborted>/g, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getMessageInterruptionReason(message) {
  const contentBlocks = Array.isArray(message?.contentBlocks) ? message.contentBlocks : [];
  const rawValues = [
    message?.displayContent,
    message?.content,
    ...contentBlocks.map((block) => block?.content || block?.text || "")
  ];
  if (rawValues.some((value) => /claudian-interrupted/.test(String(value || "")))) {
    return "user";
  }
  const hasStructuredError = Boolean(message?.error) || contentBlocks.some((block) => (
    block?.type === "error" || block?.status === "error" || Boolean(block?.error)
  ));
  const hasOfficialErrorText = rawValues.some((value) => (
    /(?:^|\r?\n)\s*(?:\u274c\s*)?(?:\*\*)?Error(?:\*\*)?\s*:/i.test(String(value || ""))
  ));
  return hasStructuredError || hasOfficialErrorText ? "error" : "";
}

function normalizeMessages(messages, conversation, nowValue) {
  if (!Array.isArray(messages)) return [];
  const fallback = normalizeTimestamp(
    conversation?.updatedAt || conversation?.createdAt,
    nowValue
  );
  return messages.map((message, index) => {
    const rawRole = String(message?.role || message?.type || "").toLowerCase();
    const role = /assistant|ai|model/.test(rawRole)
      ? "assistant"
      : (/user|human/.test(rawRole) ? "user" : rawRole);
    const interruptionReason = role === "assistant" ? getMessageInterruptionReason(message) : "";
    return {
      index,
      role,
      timestamp: normalizeTimestamp(
        message?.timestamp || message?.createdAt || message?.updatedAt,
        fallback
      ),
      text: role === "user" || role === "assistant" ? extractMessageText(message) : "",
      interrupted: Boolean(interruptionReason),
      interruptionReason
    };
  }).filter((message) => message.role);
}

function selectTaskTurnMessages(messages, task, allTasks = []) {
  const submittedAt = Number(task?.submittedAt || task?.createdAt || 0);
  const candidates = (messages || [])
    .filter((message) => message.role === "user" && message.text)
    .map((message) => {
      const difference = Math.abs(Number(message.timestamp || 0) - submittedAt);
      const textMatch = promptMatchesMessage(task?.prompt, message.text);
      return { message, difference, textMatch };
    })
    .filter((candidate) => (
      candidate.difference <= TASK_MATCH_WINDOW_MS
      && (candidate.textMatch || candidate.difference <= TASK_TIME_ONLY_WINDOW_MS)
    ))
    .sort((left, right) => (
      Number(right.textMatch) - Number(left.textMatch)
      || left.difference - right.difference
    ));
  const matchedUser = candidates[0]?.message;
  if (!matchedUser) {
    return {
      matchedTaskTurn: false,
      messages: (messages || []).filter((message) => (
        message.role === "assistant" && Number(message.timestamp || 0) > submittedAt
      ))
    };
  }
  const boundaryTasks = (allTasks || []).filter((candidate) => (
    candidate?.id !== task?.id
    && candidate?.prompt
    && (
      (task?.conversationId && candidate?.conversationId === task.conversationId)
      || (task?.tabId && candidate?.tabId === task.tabId)
    )
  ));
  const nextTaskUser = (messages || []).find((message) => (
    message.role === "user"
    && message.index > matchedUser.index
    && boundaryTasks.some((candidate) => promptMatchesMessage(candidate.prompt, message.text))
  ));
  const endIndex = nextTaskUser ? nextTaskUser.index : Number.POSITIVE_INFINITY;
  return {
    matchedTaskTurn: true,
    messages: (messages || []).filter((message) => (
      message.index > matchedUser.index && message.index < endIndex
    ))
  };
}

function comparableText(value) {
  return String(value || "").toLowerCase().replace(/\s+/g, "").trim();
}

function promptMatchesMessage(prompt, messageText) {
  const expected = comparableText(prompt);
  const actual = comparableText(messageText);
  if (!expected || !actual) return false;
  const expectedProbe = expected.slice(0, 160);
  const actualProbe = actual.slice(0, 160);
  return actual.includes(expectedProbe) || expected.includes(actualProbe);
}

function addSnapshotConversationCandidates(tabRecords, conversations, tasks) {
  const records = [...(tabRecords || [])];
  const knownConversationIds = new Set(records.map((record) => record?.conversationId).filter(Boolean));
  const activeTasks = normalizeTaskStore(tasks)
    .filter((task) => ["preparing", "submitted", "running"].includes(task.status));
  const activeConversationIds = new Set(activeTasks.map((task) => task.conversationId).filter(Boolean));
  const unboundTimes = activeTasks
    .filter((task) => !task.tabId && !task.conversationId)
    .map((task) => Number(task.submittedAt || task.createdAt || 0))
    .filter(Boolean);
  if (!unboundTimes.length && !activeConversationIds.size) return records;
  for (const conversation of conversations || []) {
    if (!conversation?.id || knownConversationIds.has(conversation.id)) continue;
    const userTimes = Array.isArray(conversation.userMessageTimestamps)
      ? conversation.userMessageTimestamps.map(Number).filter(Boolean)
      : [];
    const nearby = userTimes.some((timestamp) => (
      unboundTimes.some((taskTime) => Math.abs(timestamp - taskTime) <= TASK_MATCH_WINDOW_MS)
    ));
    const boundTask = activeTasks.find((task) => task.conversationId === conversation.id);
    if (!nearby && !boundTask) continue;
    records.push({
      id: boundTask?.tabId || "",
      conversationId: conversation.id,
      isStreaming: false,
      hasPendingConversationSave: false
    });
    knownConversationIds.add(conversation.id);
  }
  return records;
}

function findUnboundTaskMatch(task, tabRecords, conversationById, usedConversationIds, nowValue) {
  if (task?.tabId || task?.conversationId) return null;
  if (!["preparing", "submitted", "running"].includes(task?.status)) return null;
  const taskTime = Number(task.submittedAt || task.createdAt || 0);
  if (!taskTime) return null;
  let best = null;
  for (const record of tabRecords || []) {
    const conversationId = record?.conversationId;
    if (!conversationId || usedConversationIds.has(conversationId)) continue;
    const conversation = conversationById.get(conversationId);
    const messages = normalizeMessages(
      record.runtimeMessages?.length ? record.runtimeMessages : conversation?.messages,
      conversation,
      nowValue
    );
    for (const message of messages.filter((item) => item.role === "user" && item.text)) {
      const difference = Math.abs(Number(message.timestamp || 0) - taskTime);
      if (difference > TASK_MATCH_WINDOW_MS) continue;
      const textMatch = promptMatchesMessage(task.prompt, message.text);
      if (!textMatch && difference > TASK_TIME_ONLY_WINDOW_MS) continue;
      const score = difference + (textMatch ? 0 : TASK_MATCH_WINDOW_MS);
      if (!best || score < best.score) best = { record, message, score };
    }
  }
  return best;
}

function isTrivialUserText(text) {
  return /^\s*((方案)?[ABC][\s，,：:]*确认|继续|确认|批准|开始|开始实现|执行|试试|c|c2|ok|yes|好|可以)\s*[。！!]?\s*$/i.test(text || "");
}

function makeTaskSummary(text) {
  const original = String(text || "");
  const cleaned = original
    .replace(/^(请|帮我|你能不能|你可以|我想要|我需要|麻烦你|继续，?|继续。?)/, "")
    .trim();
  let source = cleaned || original;
  source = source.replace(/[A-Za-z]:\\(?:[^\\\/:*?"<>|\r\n]+\\)*([^\\\/:*?"<>|\r\n]+)/g, (_match, name) => `文件：${name}`);
  source = source.replace(/\s+/g, " ").trim();
  if (/^继续$/.test(source) || /^continue$/i.test(source)) return "继续上一步任务";
  return source.length > 48 ? `${source.slice(0, 48)}...` : source;
}

function makeTaskTitle(text, conversationTitle) {
  const source = `${text || ""} ${conversationTitle || ""}`;
  if (/^\s*继续\s*$/i.test(text) || /^\s*continue\s*$/i.test(text)) return "继续上一步任务";
  if (/^\s*(批准|OK|ok|确认|执行)\s*$/.test(text)) return "确认执行任务";
  if (/知识库界面|Obsidian本身知识库|列表下所有|待命中|上下文最近|工作台风格|员工.*待命|最近动态.*总结/.test(source)) return "工作台知识库与动态优化";
  if (/账目|报销|发工资|工资表|五险一金|公积金|社保|个税|带公式|表格/.test(source)) return "公司账目工资表制作";
  if (/最近动态|标题|AI\s*(对话|框)|Claudian|新建对话|打开AI/.test(source)) return "AI对话入口与动态摘要";
  if (/趋势图|员工总数|任务总数|输入字符|真实数据|动态化|实际情况/.test(source)) return "工作台数据动态化";
  if (/左边|标签|知识库框架|文件列表|工作简述|正在跑的任务/.test(source)) return "工作台模块导航改造";
  if (/上架|商品|抖店|产品|小龙虾|库存/.test(source)) return "商品上架操作";
  if (/图片|主图|详情页|截图|设计图|image|png|jpg/.test(source)) return "图片与详情页处理";
  if (/工作台|界面|主题|Obsidian|CSS|首页/.test(source)) return "工作台界面改造";
  if (/插件|Homepage|Hider|CCswitch|安装|配置|启动/.test(source)) return "插件安装配置";
  if (/PPT|课件|课程|讲义|逐字稿|Word|docx|录播/.test(source)) return "课程课件迭代";
  if (/清理|整理|删除|移动|回收|备份|知识库/.test(source)) return "知识库整理与维护";
  if (/打开|空当接龙|游戏|网页|浏览器|Edge/.test(source)) return "外部应用操作";
  const clean = makeTaskSummary(text).replace(/[，。,.!！?？].*$/, "");
  return clean.length > 14 ? `${clean.slice(0, 14)}...` : clean || "新任务";
}

function getRuntimeTabs(plugin) {
  const runtimeTabs = [];
  let views = [];
  try { views = typeof plugin?.getAllViews === "function" ? plugin.getAllViews() : []; } catch (_) {}
  for (const view of views || []) {
    const rawTabs = view?.tabManager?.tabs;
    const values = rawTabs instanceof Map
      ? Array.from(rawTabs.values())
      : (Array.isArray(rawTabs) ? rawTabs : (rawTabs && typeof rawTabs === "object" ? Object.values(rawTabs) : []));
    for (const tab of values) {
      const state = tab?.state || {};
      runtimeTabs.push({
        id: tab?.id || state.id,
        conversationId: tab?.conversationId || state.conversationId,
        lifecycleState: tab?.lifecycleState || state.lifecycleState,
        isStreaming: Boolean(state.isStreaming || tab?.isStreaming),
        hasPendingConversationSave: Boolean(state.hasPendingConversationSave || tab?.hasPendingConversationSave),
        runtimeMessageCount: Array.isArray(state.messages) ? state.messages.length : 0,
        runtimeMessages: Array.isArray(state.messages) ? state.messages : []
      });
    }
  }
  return runtimeTabs;
}

function mergeTabRecords(openTabs, runtimeTabs) {
  const records = new Map();
  const order = [];
  const put = (partial, source, index) => {
    const conversationId = partial?.conversationId || partial?.state?.conversationId || null;
    const id = partial?.id || partial?.tabId || partial?.state?.id || null;
    const key = id || conversationId || `${source}-${index}`;
    if (!records.has(key)) {
      records.set(key, { id, conversationId });
      order.push(key);
    }
    const record = records.get(key);
    Object.assign(record, partial, {
      id: id || record.id,
      conversationId: conversationId || record.conversationId
    });
  };
  (openTabs || []).forEach((tab, index) => put(tab, "stored", index));
  (runtimeTabs || []).forEach((tab, index) => put(tab, "runtime", index));
  return order.map((key) => records.get(key));
}

function formatTime(timestamp) {
  const value = Number(timestamp);
  if (!value) return "--";
  return new Date(value).toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
}

function dateKey(date) {
  const value = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(value.getTime())) return "";
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");
  return `${value.getFullYear()}-${month}-${day}`;
}

function formatNumber(value) {
  return new Intl.NumberFormat("zh-CN").format(Number(value) || 0);
}

function buildEmployeeRecord(record, index, conversation, nowValue) {
  const messages = normalizeMessages(
    record.runtimeMessages?.length ? record.runtimeMessages : conversation?.messages,
    conversation,
    nowValue
  );
  const userMessages = messages.filter((message) => message.role === "user" && message.text);
  const assistantMessages = messages.filter((message) => message.role === "assistant");
  let latestUser = null;
  for (let cursor = userMessages.length - 1; cursor >= 0; cursor -= 1) {
    if (!isTrivialUserText(userMessages[cursor].text)) {
      latestUser = userMessages[cursor];
      break;
    }
  }
  latestUser ||= userMessages.at(-1) || null;
  const latestAssistant = assistantMessages.at(-1) || null;
  const latestAny = messages.at(-1) || null;
  const recentGapRunning = latestUser
    && (!latestAssistant || latestUser.timestamp > latestAssistant.timestamp)
    && nowValue - latestUser.timestamp < 8 * 60 * 1000;
  const running = Boolean(record.isStreaming || record.hasPendingConversationSave || recentGapRunning);
  const lastActive = latestAny?.timestamp || normalizeTimestamp(
    conversation?.updatedAt || conversation?.createdAt,
    nowValue
  );
  const title = latestUser
    ? makeTaskTitle(latestUser.text, conversation?.title)
    : (conversation?.title || `AI 对话 ${index + 1}`);
  const summary = running && latestUser
    ? makeTaskSummary(latestUser.text)
    : (latestUser ? `最近工作：${makeTaskSummary(latestUser.text)}` : STANDBY_TEXT);
  return {
    id: record.id || record.conversationId || `employee-${index}`,
    displayIndex: index + 1,
    conversationId: record.conversationId || conversation?.id || "",
    title: title || `AI 对话 ${index + 1}`,
    summary: summary || STANDBY_TEXT,
    status: running ? "执行中" : "待命中",
    running,
    lifecycleState: record.lifecycleState || "active",
    messageCount: Math.max(messages.length, record.runtimeMessageCount || 0),
    userMessageCount: userMessages.length,
    lastActive
  };
}

function unavailableUsage() {
  return {
    title: "今日累计",
    provider: "",
    main: "--",
    sub: "",
    meta: "等待山竹智能体数据同步",
    foot: "本地估算暂不可用",
    tone: "estimate"
  };
}

function createDashboardService(options = {}) {
  const claudian = options.claudian;
  const system = options.system;
  const basePath = String(options.basePath || "");
  const getTasks = typeof options.getTasks === "function" ? options.getTasks : () => [];
  const saveTasks = typeof options.saveTasks === "function" ? options.saveTasks : async () => {};
  const collectKnowledge = typeof options.collectKnowledge === "function" ? options.collectKnowledge : () => null;
  const now = typeof options.now === "function" ? options.now : Date.now;
  const logger = options.logger || console;

  function buildData({ connected, openDialogCount = 0, employees = [], conversationMetrics, conversationTrend }) {
    const nowValue = now();
    const records = normalizeTaskStore(getTasks());
    const statusLabels = {
      preparing: "准备中",
      submitted: "已提交",
      running: "执行中",
      interrupted: "已中断",
      completed: "已完成",
      failed: "失败"
    };
    const tasks = records.map((task) => ({
      ...task,
      status: statusLabels[task.status] || task.status || "准备中",
      rawStatus: task.status,
      time: task.updatedAt ? formatTime(task.updatedAt) : "--",
      summary: task.resultSummary || task.error || task.expectedOutput || "等待 AI 返回结果",
      meta: task.workflow || "工作台任务"
    }));
    const completed = records.filter((task) => task.status === "completed").length;
    const failed = records.filter((task) => task.status === "failed").length;
    const today = dateKey(new Date(nowValue));
    const todayTasks = records.filter((task) => dateKey(new Date(task.createdAt || 0)) === today).length;
    const recent = tasks.slice(0, 5).map((task) => ({
      title: task.title,
      summary: task.resultSummary || task.error || `${task.status} · ${task.expectedOutput || "等待结果"}`,
      time: task.time
    }));
    const metrics = conversationMetrics || buildConversationMetrics({ available: false }, nowValue);
    const trend = conversationTrend || buildConversationTrend({ available: false }, 7, nowValue);
    const metricValue = (value) => value == null ? "--" : formatNumber(value);
    const openCount = metrics.openConversationTotal == null
      ? openDialogCount
      : Math.max(openDialogCount, metrics.openConversationTotal);
    const latestConversation = metrics.latestUpdatedAt
      ? new Date(metrics.latestUpdatedAt).toLocaleString("zh-CN", {
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      })
      : "--";
    return {
      statusText: connected ? `AI 已连接 ${formatTime(nowValue)}` : "AI 对话插件未连接",
      subtitle: connected
        ? `本机共有 ${metricValue(metrics.conversationTotal)} 个 AI 对话，当前打开 ${openCount} 个；工作台记录 ${records.length} 个任务。`
        : `AI 对话暂时不可用；本机仍保留 ${records.length} 个工作台任务记录。`,
      openDialogCount: connected ? openCount : 0,
      userMessageTotal: records.length,
      charTotal: completed,
      todayUserMessageTotal: todayTasks,
      trendValues: trend.values,
      trendStart: trend.startLabel,
      trendEnd: trend.endLabel,
      trendMeta: trend.available ? `统计范围：近 ${trend.days} 天` : "本机数据当前不可用",
      activityMeta: recent.length ? `最近${recent.length}项` : "暂无任务",
      recent,
      employees: connected ? employees : [],
      runningTasks: tasks,
      knowledge: collectKnowledge(),
      conversationMetrics: metrics,
      conversationTrend: trend,
      dataCards: [
        { title: "工作台任务", value: records.length, desc: "只统计从工作台确认并发送的任务", badge: "本机" },
        { title: "已完成", value: completed, desc: "已收到对应 AI 回复的任务", badge: "真实" },
        { title: "失败", value: failed, desc: "打开、填入或发送失败的任务", badge: "可核对" },
        { title: "今日任务", value: todayTasks, desc: "今天从工作台实际发出的任务", badge: "今日" },
        { title: "本机 AI 对话", value: metricValue(metrics.conversationTotal), desc: metrics.available ? "山竹智能体保存在本机的全部对话" : "AI 对话插件当前未连接", badge: metrics.available ? "本机" : "未连接" },
        { title: "今日更新对话", value: metricValue(metrics.todayConversationTotal), desc: "今天新建或收到新回答的对话", badge: "今日" },
        { title: "打开的对话", value: metricValue(metrics.available ? openCount : null), desc: "当前在山竹智能体中打开的标签页", badge: "实时" },
        { title: "回答进行中", value: metricValue(metrics.streamingConversationTotal), desc: "当前仍在生成回答的对话", badge: "实时" },
        { title: "最近更新", value: latestConversation, desc: "最近一次本机对话变化时间", badge: "本机" }
      ],
      usage: unavailableUsage()
    };
  }

  async function syncTasks(tabRecords, conversationById) {
    const current = normalizeTaskStore(getTasks());
    const nowValue = now();
    const usedConversationIds = new Set(current.map((task) => task.conversationId).filter(Boolean));
    const recovered = new Map();
    for (const task of current) {
      const match = findUnboundTaskMatch(
        task,
        tabRecords,
        conversationById,
        usedConversationIds,
        nowValue
      );
      if (!match) continue;
      recovered.set(task.id, match);
      usedConversationIds.add(match.record.conversationId);
    }
    const next = current.map((task) => {
      if (["failed", "completed", "interrupted"].includes(task.status)) return task;
      const recoveredMatch = recovered.get(task.id);
      let tab = recoveredMatch?.record || (tabRecords || []).find((record) => {
        if (task.tabId && (record.id === task.tabId || record.tabId === task.tabId)) return true;
        return task.conversationId && record.conversationId === task.conversationId;
      });
      if (!tab && task.conversationId && conversationById.has(task.conversationId)) {
        tab = {
          id: task.tabId || "",
          conversationId: task.conversationId,
          isStreaming: false,
          hasPendingConversationSave: false
        };
      }
      if (!tab) return task;
      const taskForSnapshot = recoveredMatch ? {
        ...task,
        status: "submitted",
        submittedAt: Number(recoveredMatch.message.timestamp || task.createdAt || nowValue),
        tabId: tab.id || tab.tabId || "",
        conversationId: tab.conversationId || ""
      } : task;
      const conversation = conversationById.get(tab.conversationId || taskForSnapshot.conversationId);
      const rawMessages = tab.runtimeMessages?.length ? tab.runtimeMessages : conversation?.messages;
      const selectedTurn = selectTaskTurnMessages(
        normalizeMessages(rawMessages, conversation, nowValue),
        taskForSnapshot,
        current
      );
      const turnMessages = selectedTurn.messages;
      const assistantMessages = turnMessages
        .filter((message) => message.role === "assistant" && (message.text || message.interruptionReason))
        .map((message) => ({
          timestamp: message.timestamp,
          text: message.text,
          interrupted: message.interrupted,
          interruptionReason: message.interruptionReason
        }));
      const interruptionReason = assistantMessages.some((message) => message.interruptionReason === "error")
        ? "error"
        : (assistantMessages.find((message) => message.interruptionReason)?.interruptionReason || "");
      const updated = applyTaskSnapshot(taskForSnapshot, {
        tabId: tab.id || tab.tabId || taskForSnapshot.tabId,
        conversationId: tab.conversationId || taskForSnapshot.conversationId,
        isStreaming: Boolean(tab.isStreaming || tab.hasPendingConversationSave),
        interrupted: Boolean(interruptionReason),
        interruptionReason,
        assistantMessagesBelongToTaskTurn: selectedTurn.matchedTaskTurn,
        assistantMessages
      }, nowValue);
      const latestReply = assistantMessages
        .filter((message) => !message.interrupted)
        .sort((a, b) => a.timestamp - b.timestamp)
        .at(-1);
      if (latestReply && updated.status === "completed") {
        updated.outputPaths = extractOutputPaths(latestReply.text, {
          basePath,
          homeDir: system?.homeDirectory?.() || "",
          existsSync: (filePath) => Boolean(system?.pathExists?.(filePath))
        });
      }
      return updated;
    });
    if (JSON.stringify(next) !== JSON.stringify(current)) await saveTasks(next);
    return next;
  }

  async function collect(request = {}) {
    const trendDays = Number(request.trendDays) === 30 ? 30 : 7;
    const integration = claudian?.getStatus?.() || { available: false, plugin: null };
    const plugin = integration.plugin;
    const snapshot = request.conversationSnapshot
      || claudian?.getConversationSnapshot?.()
      || { available: false, conversations: [], openTabs: [] };
    const nowValue = now();
    const metrics = buildConversationMetrics(snapshot, nowValue);
    const trend = buildConversationTrend(snapshot, trendDays, nowValue);
    if (!plugin) {
      return buildData({ connected: false, conversationMetrics: metrics, conversationTrend: trend });
    }

    let tabState = null;
    try {
      tabState = await plugin.storage?.getTabManagerState?.();
    } catch (error) {
      logger.warn?.("Senxue workbench: failed to read Claudian tab state", error);
    }
    const openTabs = Array.isArray(tabState?.openTabs) ? tabState.openTabs : [];
    const runtimeTabs = getRuntimeTabs(plugin);
    const tabRecords = addSnapshotConversationCandidates(
      mergeTabRecords(openTabs, runtimeTabs),
      snapshot.conversations,
      getTasks()
    );
    const openDialogCount = Math.max(
      metrics.openConversationTotal || 0,
      openTabs.length,
      runtimeTabs.length
    );
    const conversationById = new Map();
    for (const record of tabRecords) {
      if (!record.conversationId || conversationById.has(record.conversationId)) continue;
      let conversation = null;
      try { conversation = plugin.getConversationSync?.(record.conversationId) || null; } catch (_) {}
      const syncHasMessages = Array.isArray(conversation?.messages) && conversation.messages.length > 0;
      if ((!conversation || !syncHasMessages) && typeof plugin.getConversationById === "function") {
        try {
          conversation = await plugin.getConversationById(record.conversationId) || conversation;
        } catch (_) {}
      }
      if (conversation) conversationById.set(record.conversationId, conversation);
    }
    await syncTasks(tabRecords, conversationById);
    const employees = tabRecords
      .map((record, index) => buildEmployeeRecord(
        record,
        index,
        conversationById.get(record.conversationId),
        nowValue
      ))
      .sort((a, b) => a.running !== b.running
        ? (a.running ? -1 : 1)
        : (b.lastActive || 0) - (a.lastActive || 0));
    return buildData({
      connected: true,
      openDialogCount,
      employees,
      conversationMetrics: metrics,
      conversationTrend: trend
    });
  }

  function buildUnavailable(request = {}) {
    const trendDays = Number(request.trendDays) === 30 ? 30 : 7;
    const nowValue = now();
    return buildData({
      connected: false,
      conversationMetrics: buildConversationMetrics({ available: false }, nowValue),
      conversationTrend: buildConversationTrend({ available: false }, trendDays, nowValue)
    });
  }

  return { collect, syncTasks, buildUnavailable };
}

module.exports = { createDashboardService };
