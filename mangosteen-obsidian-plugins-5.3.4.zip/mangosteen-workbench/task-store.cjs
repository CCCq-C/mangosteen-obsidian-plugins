const pathModule = require("path");
const { DISPLAY_KNOWLEDGE_ROOT, LEGACY_KNOWLEDGE_ROOT } = require("./vault-path.cjs");

const KNOWLEDGE_ROOTS = [DISPLAY_KNOWLEDGE_ROOT, LEGACY_KNOWLEDGE_ROOT];

function normalizeTaskStore(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item) => item && typeof item.id === "string" && item.id)
    .map((item) => ({
      ...item,
      params: Array.isArray(item.params) ? item.params : [],
      outputPaths: Array.isArray(item.outputPaths) ? item.outputPaths : []
    }))
    .sort((a, b) => Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0))
    .slice(0, 100);
}

function createTaskRecord(details, now = Date.now()) {
  const source = details || {};
  return {
    id: `senxue-task-${now}-${Math.random().toString(36).slice(2, 8)}`,
    workflow: String(source.workflow || ""),
    title: String(source.title || "执行当前任务"),
    params: Array.isArray(source.params)
      ? source.params.map((item) => ({ key: item.key || "参数", value: String(item.value || "") }))
      : [],
    prompt: String(source.prompt || ""),
    expectedOutput: String(source.expectedOutput || ""),
    createdAt: now,
    updatedAt: now,
    submittedAt: 0,
    completedAt: 0,
    tabId: "",
    conversationId: "",
    status: "preparing",
    resultSummary: "",
    outputPaths: [],
    error: ""
  };
}

function updateTaskRecord(tasks, taskId, patch) {
  const id = String(taskId || "");
  if (!id) return normalizeTaskStore(tasks);
  return normalizeTaskStore((Array.isArray(tasks) ? tasks : []).map((task) => (
    task?.id === id ? { ...task, ...(patch || {}) } : task
  )));
}

function applyTaskSnapshot(task, snapshot, now = Date.now()) {
  const next = { ...(task || {}) };
  const state = snapshot || {};
  if (state.tabId) next.tabId = state.tabId;
  if (state.conversationId) next.conversationId = state.conversationId;
  if (state.error) {
    next.status = "failed";
    next.error = String(state.error);
    next.updatedAt = now;
    return next;
  }
  if (["failed", "completed", "interrupted"].includes(next.status)) return next;
  if (state.isStreaming) {
    if (next.status !== "running") {
      next.status = "running";
      next.updatedAt = now;
    }
    return next;
  }
  if (state.interrupted) {
    next.status = "interrupted";
    next.interruptionReason = state.interruptionReason === "error" ? "error" : "user";
    next.interruptedAt = now;
    next.updatedAt = now;
    return next;
  }
  const submittedAt = Number(next.submittedAt || 0);
  const replies = (Array.isArray(state.assistantMessages) ? state.assistantMessages : [])
    .filter((message) => (
      String(message?.text || "").trim()
      && (state.assistantMessagesBelongToTaskTurn || Number(message?.timestamp || 0) > submittedAt)
    ))
    .sort((a, b) => Number(a.timestamp || 0) - Number(b.timestamp || 0));
  const latestReply = replies.at(-1);
  if (submittedAt && latestReply) {
    next.status = "completed";
    next.completedAt = now;
    next.updatedAt = now;
    const text = String(latestReply.text || "").replace(/\s+/g, " ").trim();
    next.resultSummary = text.length > 360 ? `${text.slice(0, 360)}...` : text;
  }
  return next;
}

function extractOutputPaths(text, options = {}) {
  const source = String(text || "");
  const basePath = String(options.basePath || "");
  const homeDir = String(options.homeDir || "");
  const existsSync = typeof options.existsSync === "function" ? options.existsSync : () => false;
  const candidates = [];
  const seen = new Set();
  const add = (rawPath) => {
    const value = String(rawPath || "").trim().replace(/^["']|["']$/g, "");
    if (!value || seen.has(value)) return;
    const looksLikePath = KNOWLEDGE_ROOTS.some((root) => value.startsWith(`${root}/`))
      || value.startsWith("/")
      || value.startsWith("~/")
      || /^[A-Za-z]:[\\/]/.test(value);
    if (!looksLikePath) return;
    seen.add(value);
    let resolvedPath = value;
    if (KNOWLEDGE_ROOTS.some((root) => value.startsWith(`${root}/`)) && basePath) {
      resolvedPath = pathModule.join(basePath, value);
    } else if (value.startsWith("~/") && homeDir) {
      resolvedPath = pathModule.join(homeDir, value.slice(2));
    }
    candidates.push({ path: value, resolvedPath, exists: Boolean(existsSync(resolvedPath)) });
  };

  for (const match of source.matchAll(/`([^`\n]+)`/g)) add(match[1]);
  for (const line of source.split(/\r?\n/)) {
    const match = line.match(/(?:^|[：:]\s*)((?:(?:山竹智能体知识库|森雪赚AI工作台知识库)\/|~\/|\/(?:Users|Volumes|tmp)\/|[A-Za-z]:[\\/]).+)$/);
    if (match) add(match[1].replace(/[。；;,，]+$/, ""));
  }
  return candidates;
}

module.exports = {
  normalizeTaskStore,
  createTaskRecord,
  updateTaskRecord,
  applyTaskSnapshot,
  extractOutputPaths
};
