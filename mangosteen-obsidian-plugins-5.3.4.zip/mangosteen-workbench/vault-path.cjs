"use strict";

const pathModule = require("path");

const LEGACY_KNOWLEDGE_ROOT = "森雪赚AI工作台知识库";
const DISPLAY_KNOWLEDGE_ROOT = "山竹智能体知识库";

function getVaultBasePath(adapter) {
  const value = adapter?.getBasePath?.() || adapter?.basePath || "";
  return typeof value === "string" ? value.trim() : "";
}

function resolvePluginRoot(basePath, manifestDir) {
  if (!basePath || !manifestDir) return "";
  return pathModule.join(basePath, ...String(manifestDir).replaceAll("\\", "/").split("/").filter(Boolean));
}

function normalizeVaultPath(input) {
  let value = String(input ?? "").trim().replaceAll("\\", "/").replace(/^\/+/, "");
  try {
    value = decodeURIComponent(value);
  } catch (_) {
    return null;
  }
  value = value.replace(/\/{2,}/g, "/");
  if (!value || value.includes("\0") || /^[A-Za-z]:/.test(value) || /^[a-z]+:\/\//i.test(value)) return null;
  if (value.split("/").some((part) => !part || part === "." || part === "..")) return null;
  return value;
}

function withKnowledgeRootAliases(input) {
  const paths = [input];
  if (input === DISPLAY_KNOWLEDGE_ROOT || input.startsWith(`${DISPLAY_KNOWLEDGE_ROOT}/`)) {
    paths.push(`${LEGACY_KNOWLEDGE_ROOT}${input.slice(DISPLAY_KNOWLEDGE_ROOT.length)}`);
  }
  if (input === LEGACY_KNOWLEDGE_ROOT || input.startsWith(`${LEGACY_KNOWLEDGE_ROOT}/`)) {
    paths.push(`${DISPLAY_KNOWLEDGE_ROOT}${input.slice(LEGACY_KNOWLEDGE_ROOT.length)}`);
  }
  return [...new Set(paths)];
}

function getPathCandidates(input) {
  const normalized = normalizeVaultPath(input);
  if (!normalized) return [];
  const candidates = [];
  for (const alias of withKnowledgeRootAliases(normalized)) {
    candidates.push(alias);
    if (!alias.toLowerCase().endsWith(".md")) candidates.push(`${alias}.md`);
  }
  return [...new Set(candidates)];
}

function findVaultFile(app, input, sourcePath = "", isFile = (value) => Boolean(value?.path)) {
  const candidates = getPathCandidates(input);
  if (!candidates.length) return null;

  for (const candidate of candidates) {
    const direct = app?.vault?.getAbstractFileByPath?.(candidate);
    if (isFile(direct)) return direct;
  }

  const files = app?.vault?.getMarkdownFiles?.() || [];
  const foldedCandidates = new Set(candidates.map((candidate) => candidate.normalize("NFC").toLocaleLowerCase("zh-CN")));
  const matched = files.find((file) => foldedCandidates.has(String(file?.path || "").normalize("NFC").toLocaleLowerCase("zh-CN")));
  if (isFile(matched)) return matched;

  for (const candidate of candidates) {
    const linkPath = candidate.replace(/\.md$/i, "");
    const linked = app?.metadataCache?.getFirstLinkpathDest?.(linkPath, sourcePath || "");
    if (isFile(linked)) return linked;
  }
  return null;
}

module.exports = {
  DISPLAY_KNOWLEDGE_ROOT,
  LEGACY_KNOWLEDGE_ROOT,
  findVaultFile,
  getPathCandidates,
  getVaultBasePath,
  normalizeVaultPath,
  resolvePluginRoot,
};
