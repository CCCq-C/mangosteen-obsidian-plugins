function assertFunctionContract(value, names, label = "runtime") {
  const missing = (names || []).filter((name) => typeof value?.[name] !== "function");
  if (missing.length) {
    throw new Error(`${label} missing required functions: ${missing.join(", ")}`);
  }
  return value;
}

function createResourceScope(options = {}) {
  const setTimeoutFn = options.setTimeoutFn || setTimeout;
  const clearTimeoutFn = options.clearTimeoutFn || clearTimeout;
  const timers = new Set();
  const cleanups = new Set();
  let disposed = false;

  function timeout(callback, delay) {
    if (disposed) return null;
    let timerId = null;
    timerId = setTimeoutFn(() => {
      timers.delete(timerId);
      if (!disposed) callback();
    }, delay);
    timers.add(timerId);
    return timerId;
  }

  function addCleanup(cleanup) {
    if (typeof cleanup !== "function") return () => {};
    if (disposed) {
      cleanup();
      return () => {};
    }
    cleanups.add(cleanup);
    return () => cleanups.delete(cleanup);
  }

  function sleep(delay) {
    if (disposed) return Promise.resolve(false);
    return new Promise((resolve) => {
      let settled = false;
      let timerId = null;
      let removeCleanup = () => {};
      const finish = (completed) => {
        if (settled) return;
        settled = true;
        removeCleanup();
        resolve(completed);
      };
      timerId = timeout(() => finish(true), delay);
      removeCleanup = addCleanup(() => {
        if (timerId !== null && timers.delete(timerId)) clearTimeoutFn(timerId);
        finish(false);
      });
    });
  }

  function dispose() {
    if (disposed) return [];
    disposed = true;
    const errors = [];
    for (const timerId of timers) {
      try {
        clearTimeoutFn(timerId);
      } catch (error) {
        errors.push(error);
      }
    }
    timers.clear();
    const ownedCleanups = Array.from(cleanups);
    cleanups.clear();
    for (const cleanup of ownedCleanups) {
      try {
        cleanup();
      } catch (error) {
        errors.push(error);
      }
    }
    return errors;
  }

  return {
    timeout,
    addCleanup,
    sleep,
    dispose,
    get disposed() {
      return disposed;
    }
  };
}

function createLatestRefreshCoordinator(options = {}) {
  const run = options.run;
  if (typeof run !== "function") throw new Error("refresh coordinator requires run");
  const onCommitted = typeof options.onCommitted === "function"
    ? options.onCommitted
    : () => {};
  const onError = typeof options.onError === "function"
    ? options.onError
    : () => {};
  let pending = null;
  let running = false;
  let disposed = false;

  function cancelledResult() {
    return { applied: false, cancelled: true };
  }

  function mergeRequest(current, next) {
    const hasSnapshot = next.snapshot !== null && next.snapshot !== undefined;
    return {
      ...current,
      ...next,
      manual: Boolean(current.manual || next.manual),
      snapshot: hasSnapshot ? next.snapshot : current.snapshot,
      signature: hasSnapshot
        ? (next.signature || "")
        : (next.signature || current.signature || "")
    };
  }

  function resolveBatch(batch, result) {
    for (const waiter of batch.waiters) waiter.resolve(result);
  }

  function rejectBatch(batch, error) {
    for (const waiter of batch.waiters) waiter.reject(error);
  }

  async function drain() {
    if (running || disposed) return;
    running = true;
    try {
      while (pending && !disposed) {
        const batch = pending;
        pending = null;
        try {
          const result = await run(batch.request);
          if (disposed) {
            resolveBatch(batch, cancelledResult());
            continue;
          }
          if (result?.applied && batch.request.signature) {
            onCommitted(batch.request.signature);
          }
          resolveBatch(batch, result);
        } catch (error) {
          if (disposed) {
            resolveBatch(batch, cancelledResult());
            continue;
          }
          try {
            onError(error);
          } catch (_) {}
          rejectBatch(batch, error);
        }
      }
    } finally {
      running = false;
    }
  }

  function request(nextRequest = {}) {
    if (disposed) return Promise.resolve(cancelledResult());
    return new Promise((resolve, reject) => {
      if (pending) {
        pending.request = mergeRequest(pending.request, nextRequest);
        pending.waiters.push({ resolve, reject });
      } else {
        pending = {
          request: {
            ...nextRequest,
            manual: Boolean(nextRequest.manual),
            signature: nextRequest.signature || ""
          },
          waiters: [{ resolve, reject }]
        };
      }
      void drain();
    });
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    if (pending) {
      resolveBatch(pending, cancelledResult());
      pending = null;
    }
  }

  return {
    request,
    dispose,
    get running() {
      return running;
    },
    get disposed() {
      return disposed;
    }
  };
}

module.exports = {
  assertFunctionContract,
  createResourceScope,
  createLatestRefreshCoordinator
};
