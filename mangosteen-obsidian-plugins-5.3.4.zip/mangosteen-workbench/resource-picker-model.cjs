function splitResourcePaths(value) {
  return String(value || "")
    .split("；")
    .map((item) => item.trim())
    .filter(Boolean);
}

function getResourceDisplayName(resourcePath) {
  const normalized = String(resourcePath || "").replace(/\\/g, "/").replace(/\/+$/, "");
  return normalized.split("/").pop() || normalized || "未命名材料";
}

function filterResourceOptions(options, query, limit = 20) {
  const keyword = String(query || "").trim().toLocaleLowerCase("zh-Hans-CN");
  if (keyword.length < 2) return [];
  return (Array.isArray(options) ? options : [])
    .filter((item) => `${item?.path || ""} ${item?.label || ""}`.toLocaleLowerCase("zh-Hans-CN").includes(keyword))
    .slice(0, Math.max(0, Number(limit) || 20));
}

module.exports = {
  splitResourcePaths,
  getResourceDisplayName,
  filterResourceOptions
};
