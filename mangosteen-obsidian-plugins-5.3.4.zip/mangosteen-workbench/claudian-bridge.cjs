function resolveClaudianIntegration(app) {
  const plugins = app?.plugins?.plugins || {};
  const commands = app?.commands?.commands || {};
  const pluginId = ["mangosteen-agent", "realclaudian", "claudian"].find((id) => plugins[id]);
  if (!pluginId) {
    return {
      available: false,
      plugin: null,
      pluginId: "",
      openCommandId: "",
      newTabCommandId: ""
    };
  }

  const commandPrefix = [pluginId, "mangosteen-agent", "realclaudian", "claudian"]
    .find((id) => commands[`${id}:open-view`]) || "";
  return {
    available: true,
    plugin: plugins[pluginId],
    pluginId,
    openCommandId: commandPrefix ? `${commandPrefix}:open-view` : "",
    newTabCommandId: commandPrefix && commands[`${commandPrefix}:new-tab`]
      ? `${commandPrefix}:new-tab`
      : ""
  };
}

function getActiveClaudianTab(integration) {
  const plugin = integration?.plugin;
  if (!plugin) return null;
  let views = [];
  try {
    const primary = plugin.getView?.();
    if (primary) views.push(primary);
  } catch (_) {}
  if (!views.length) {
    try {
      views = plugin.getAllViews?.() || [];
    } catch (_) {
      views = [];
    }
  }
  for (const view of views) {
    try {
      const tab = view?.getTabManager?.()?.getActiveTab?.();
      if (tab) return tab;
    } catch (_) {}
  }
  return null;
}

function isUsableInput(input) {
  return Boolean(input && input.disabled !== true && input.isConnected !== false);
}

function getActiveClaudianInput(integration, documentRef) {
  const tabInput = getActiveClaudianTab(integration)?.dom?.inputEl;
  if (isUsableInput(tabInput)) return tabInput;
  const activeInput = documentRef?.querySelector?.(
    ".claudian-active-input-slot textarea.claudian-input"
  );
  return isUsableInput(activeInput) ? activeInput : null;
}

async function waitForValue(readValue, options = {}) {
  const timeoutMs = Number(options.timeoutMs) || 3000;
  const intervalMs = Number(options.intervalMs) || 50;
  const sleep = options.sleep || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const startedAt = Date.now();
  let value = readValue();
  while (!value && Date.now() - startedAt < timeoutMs) {
    await sleep(intervalMs);
    value = readValue();
  }
  return value || null;
}

function dispatchExplicitSend(input, platform = "") {
  if (!input?.dispatchEvent) return false;
  const EventClass = input.ownerDocument?.defaultView?.KeyboardEvent
    || globalThis.KeyboardEvent;
  if (typeof EventClass !== "function") return false;
  const isMac = /Mac|iPhone|iPad|iPod/i.test(String(platform || ""));
  input.focus?.();
  const event = new EventClass("keydown", {
    key: "Enter",
    code: "Enter",
    bubbles: true,
    cancelable: true,
    composed: true,
    metaKey: isMac,
    ctrlKey: !isMac,
    altKey: false,
    shiftKey: false
  });
  input.dispatchEvent(event);
  return true;
}

function createAdapterError(code, message, cause) {
  const error = new Error(message);
  error.name = "ClaudianAdapterError";
  error.code = code;
  if (cause) error.cause = cause;
  return error;
}

function resetInputHeight(input) {
  if (!input?.style?.removeProperty) return;
  for (const property of ["height", "min-height", "max-height"]) {
    input.style.removeProperty(property);
  }
}

function isEditableInput(input, documentRef) {
  if (!input || input.disabled || input.readOnly || input.isConnected === false) return false;
  if (typeof input.getBoundingClientRect !== "function") return true;
  const rect = input.getBoundingClientRect();
  const getComputedStyle = input.ownerDocument?.defaultView?.getComputedStyle
    || documentRef?.defaultView?.getComputedStyle;
  const style = typeof getComputedStyle === "function"
    ? getComputedStyle(input)
    : { display: "block", visibility: "visible" };
  return rect.width > 0
    && rect.height > 0
    && style.display !== "none"
    && style.visibility !== "hidden";
}

function dispatchValueEvent(input, type, data) {
  const view = input?.ownerDocument?.defaultView;
  const EventClass = type === "input"
    ? (view?.InputEvent || view?.Event || globalThis.InputEvent || globalThis.Event)
    : (view?.Event || globalThis.Event);
  if (typeof EventClass !== "function" || !input?.dispatchEvent) return;
  const init = { bubbles: true };
  if (type === "input") Object.assign(init, { inputType: "insertText", data });
  input.dispatchEvent(new EventClass(type, init));
}

function setInputText(input, text) {
  if ("value" in input) {
    const proto = Object.getPrototypeOf(input);
    const valueSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (valueSetter) valueSetter.call(input, text);
    else input.value = text;
    dispatchValueEvent(input, "input", text);
    dispatchValueEvent(input, "change", text);
    return;
  }
  input.textContent = text;
  dispatchValueEvent(input, "input", text);
}

function createClaudianAdapter(options = {}) {
  const app = options.app;
  const documentRef = options.documentRef || globalThis.document;
  const platform = options.platform || "";
  const sleep = options.sleep || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));

  function getStatus() {
    return resolveClaudianIntegration(app);
  }

  function getActiveTab() {
    return getActiveClaudianTab(getStatus());
  }

  function getInput() {
    return getActiveClaudianInput(getStatus(), documentRef);
  }

  function getConversationSnapshot() {
    return collectLocalConversationSnapshot(getStatus());
  }

  async function open(openOptions = {}) {
    const integration = getStatus();
    if (!integration.available) {
      throw createAdapterError("UNAVAILABLE", "AI conversation plugin is unavailable");
    }
    try {
      if (typeof integration.plugin.activateView === "function") {
        await integration.plugin.activateView();
      } else if (integration.openCommandId) {
        const opened = await app?.commands?.executeCommandById?.(integration.openCommandId);
        if (opened === false) throw new Error("Claudian open command failed");
      } else {
        throw new Error("Claudian open command is unavailable");
      }
      if (app?.workspace?.rightSplit?.collapsed) app.workspace.rightSplit.expand();
      const activeTab = getActiveClaudianTab(integration);
      const activeInput = getActiveClaudianInput(integration, documentRef);
      const hasActiveConversation = Boolean(activeTab || isEditableInput(activeInput, documentRef));
      const shouldCreateConversation = Boolean(
        openOptions.newConversation
        || (openOptions.createIfMissing && !hasActiveConversation)
      );
      if (shouldCreateConversation) {
        if (!integration.newTabCommandId) {
          throw new Error("Claudian new-tab command is unavailable");
        }
        const created = app?.commands?.executeCommandById?.(integration.newTabCommandId);
        if (created === false) throw new Error("Claudian cannot create another tab");
        if (created && typeof created.catch === "function") {
          void created.catch(() => {});
        }
      }
      const input = await waitForValue(
        () => {
          const candidate = getActiveClaudianInput(integration, documentRef);
          return isEditableInput(candidate, documentRef) ? candidate : null;
        },
        { timeoutMs: 4000, intervalMs: 50, sleep }
      );
      if (!input) {
        throw createAdapterError("INPUT_NOT_READY", "Claudian active input is not ready");
      }
      return { integration, input, tab: getActiveClaudianTab(integration) };
    } catch (error) {
      if (error?.name === "ClaudianAdapterError") throw error;
      throw createAdapterError("OPEN_FAILED", "Claudian could not be opened", error);
    }
  }

  async function insertAndSend(text, insertOptions = {}) {
    const input = insertOptions.input || getInput();
    if (!input) {
      throw createAdapterError("INPUT_NOT_READY", "Claudian active input is not ready");
    }
    try {
      input.focus?.();
      setInputText(input, String(text || ""));
      if (insertOptions.send !== false) {
        const delay = Math.max(0, Number(insertOptions.sendDelayMs) || 0);
        if (delay) await sleep(delay);
        if (!dispatchExplicitSend(input, platform)) {
          throw createAdapterError("SEND_FAILED", "Claudian input did not accept the send command");
        }
      }
      return input;
    } finally {
      resetInputHeight(input);
    }
  }

  function resetInputHeights() {
    documentRef?.querySelectorAll?.(
      "textarea.claudian-input, .claudian-input-wrapper textarea, .claudian-input-container textarea"
    )?.forEach?.(resetInputHeight);
  }

  return {
    getStatus,
    getActiveTab,
    getInput,
    getConversationSnapshot,
    open,
    insertAndSend,
    resetInputHeights
  };
}

function toTimestamp(value) {
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? value.getTime() : 0;
  const numeric = Number(value);
  if (Number.isFinite(numeric) && numeric > 0) return numeric;
  const parsed = Date.parse(String(value || ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function readArray(readValue) {
  try {
    const value = readValue();
    return Array.isArray(value) ? value : [];
  } catch (_) {
    return [];
  }
}

function getManagerTabs(manager) {
  if (!manager) return [];
  const direct = readArray(() => manager.getAllTabs?.());
  if (direct.length) return direct;
  const legacy = readArray(() => manager.getTabs?.());
  if (legacy.length) return legacy;
  try {
    if (manager.tabs instanceof Map) return Array.from(manager.tabs.values());
    if (Array.isArray(manager.tabs)) return manager.tabs;
  } catch (_) {}
  return [];
}

function collectLocalConversationSnapshot(integration) {
  const plugin = integration?.plugin;
  if (!integration?.available || !plugin) {
    return { available: false, partial: false, conversations: [], openTabs: [] };
  }

  const metadata = readArray(() => plugin.getConversationList?.());
  const repositoryItems = readArray(() => plugin.conversationRepository?.getAll?.());
  const repositoryById = new Map(
    repositoryItems
      .filter((item) => item && typeof item.id === "string" && item.id)
      .map((item) => [item.id, item])
  );

  let views = readArray(() => plugin.getAllViews?.());
  if (!views.length) {
    try {
      const view = plugin.getView?.();
      if (view) views = [view];
    } catch (_) {}
  }

  const openTabs = [];
  const seenTabIds = new Set();
  const tabMessagesByConversationId = new Map();
  views.forEach((view, viewIndex) => {
    let manager = null;
    try {
      manager = view?.getTabManager?.() || view?.tabManager || null;
    } catch (_) {}
    getManagerTabs(manager).forEach((tab, tabIndex) => {
      if (!tab || typeof tab !== "object") return;
      const id = String(tab.id || tab.tabId || `view-${viewIndex}-tab-${tabIndex}`);
      if (seenTabIds.has(id)) return;
      seenTabIds.add(id);
      const conversationId = String(tab.conversationId || tab.state?.currentConversationId || "");
      const messages = Array.isArray(tab.state?.messages) ? tab.state.messages : [];
      if (conversationId && messages.length) {
        const current = tabMessagesByConversationId.get(conversationId) || [];
        if (messages.length > current.length) tabMessagesByConversationId.set(conversationId, messages);
      }
      openTabs.push({
        id,
        conversationId,
        isStreaming: Boolean(tab.state?.isStreaming || tab.isStreaming)
      });
    });
  });

  const sources = metadata.length ? metadata : repositoryItems;
  const seenConversationIds = new Set();
  const conversations = [];
  for (const item of sources) {
    if (!item || typeof item !== "object") continue;
    const id = typeof item.id === "string" ? item.id : "";
    if (!id || seenConversationIds.has(id)) continue;
    seenConversationIds.add(id);
    const repositoryItem = repositoryById.get(id) || null;
    const declaredMessageCount = Number.isFinite(Number(item.messageCount))
      ? Math.max(0, Number(item.messageCount))
      : null;
    let messages = Array.isArray(repositoryItem?.messages) ? repositoryItem.messages : [];
    const tabMessages = tabMessagesByConversationId.get(id) || [];
    if (tabMessages.length > messages.length) messages = tabMessages;
    const lastResponseAt = toTimestamp(item.lastResponseAt ?? repositoryItem?.lastResponseAt);
    const hasStoredMessageEvidence = (declaredMessageCount || 0) > 0 || lastResponseAt > 0;
    const messagesKnown = messages.length > 0 || !hasStoredMessageEvidence;
    const userMessages = messagesKnown ? messages.filter((message) => message?.role === "user") : [];
    const assistantMessages = messagesKnown ? messages.filter((message) => message?.role === "assistant") : [];

    conversations.push({
      id,
      title: String(item.title || repositoryItem?.title || "未命名对话"),
      providerId: String(item.providerId || repositoryItem?.providerId || ""),
      createdAt: toTimestamp(item.createdAt ?? repositoryItem?.createdAt),
      updatedAt: toTimestamp(item.updatedAt ?? repositoryItem?.updatedAt),
      lastResponseAt,
      messageCount: messagesKnown ? messages.length : declaredMessageCount,
      messagesKnown,
      userMessageCount: messagesKnown ? userMessages.length : null,
      assistantMessageCount: messagesKnown ? assistantMessages.length : null,
      userMessageTimestamps: userMessages.map((message) => toTimestamp(message.timestamp)).filter(Boolean),
      assistantMessageTimestamps: assistantMessages.map((message) => toTimestamp(message.timestamp)).filter(Boolean)
    });
  }

  return {
    available: true,
    partial: conversations.some((conversation) => !conversation.messagesKnown),
    conversations,
    openTabs
  };
}

function hashSignature(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function createConversationSignature(snapshot) {
  if (!snapshot?.available) return "unavailable";
  const conversations = (snapshot.conversations || [])
    .map((item) => [item.id, item.title, item.updatedAt, item.lastResponseAt, item.messageCount].join("|"))
    .sort()
    .join(";");
  const tabs = (snapshot.openTabs || [])
    .map((item) => [item.id, item.conversationId, item.isStreaming ? 1 : 0].join("|"))
    .sort()
    .join(";");
  return `${snapshot.conversations?.length || 0}:${snapshot.openTabs?.length || 0}:${hashSignature(`${conversations}#${tabs}`)}`;
}

module.exports = {
  resolveClaudianIntegration,
  getActiveClaudianTab,
  getActiveClaudianInput,
  waitForValue,
  dispatchExplicitSend,
  createClaudianAdapter,
  collectLocalConversationSnapshot,
  createConversationSignature
};
