const pathModule = require("path");
const { DISPLAY_KNOWLEDGE_ROOT } = require("./vault-path.cjs");

const ENABLED_BUSINESS_MODULES = Object.freeze([
  { id: "office", label: "日常办公" },
  { id: "commerce", label: "短视频带货" },
  { id: "media", label: "IP 内容生产" },
  { id: "image", label: "AI 出图" },
  { id: "coding", label: "AI 编程" },
  { id: "novel", label: "写小说" }
]);

function validateWorkflowParams(params, pathExists = () => true) {
  const items = Array.isArray(params) ? params : [];
  for (const item of items) {
    const value = String(item?.value || "").trim();
    if (item?.required === true && !value) {
      const key = item.key || "必要信息";
      return {
        valid: false,
        fieldKey: key,
        message: /项目名|项目名称/.test(key)
          ? "请先填写项目名，这是 AI 建立项目和保存结果所必需的。"
          : `请先填写${key}，这是 AI 完成任务所必需的。`
      };
    }
  }

  const groups = new Map();
  for (const item of items) {
    if (!item?.requiredGroup) continue;
    if (!groups.has(item.requiredGroup)) groups.set(item.requiredGroup, []);
    groups.get(item.requiredGroup).push(item);
  }
  for (const groupItems of groups.values()) {
    if (groupItems.some((item) => String(item?.value || "").trim())) continue;
    const keys = groupItems.map((item) => item.key || "必要信息");
    return {
      valid: false,
      fieldKey: keys[0],
      message: `请在${keys.join("、")}中至少填写一项，AI 才知道要处理什么。`
    };
  }

  for (const item of items) {
    const value = String(item?.value || "").trim();
    if (item?.pathKind !== "local" || !value) continue;
    const isAbsolute = pathModule.win32.isAbsolute(value) || pathModule.posix.isAbsolute(value);
    if (!isAbsolute) {
      return {
        valid: false,
        fieldKey: item.key || "本地文件",
        message: `“${value}”不是完整的绝对路径，请重新选择文件或文件夹。`
      };
    }
    if (!pathExists(value)) {
      return {
        valid: false,
        fieldKey: item.key || "本地文件",
        message: `没有找到“${value}”，请重新选择文件或检查路径。`
      };
    }
  }
  return { valid: true, fieldKey: "", message: "" };
}

function inferExpectedOutput(workflow) {
  const id = String(workflow || "");
  if (id === "office-file-import") return `${DISPLAY_KNOWLEDGE_ROOT}/日常办公/资料库`;
  if (/^office-/.test(id)) return `${DISPLAY_KNOWLEDGE_ROOT}/日常办公/输出记录（可交付文件还会保存到桌面）`;
  if (/^ai-coding-/.test(id)) return `${DISPLAY_KNOWLEDGE_ROOT}/AI编程/项目库或当前项目目录`;
  if (/^novel-/.test(id)) return `${DISPLAY_KNOWLEDGE_ROOT}/写小说/对应项目目录`;
  if (/^ai-imagegen-/.test(id)) return `${DISPLAY_KNOWLEDGE_ROOT}/AI出图/提示词记录或出图记录`;
  if (/^(platform-|product-|short-video-|ai-video-)/.test(id)) return `${DISPLAY_KNOWLEDGE_ROOT}/短视频带货/对应环节目录`;
  if (/^self-media-/.test(id)) return `${DISPLAY_KNOWLEDGE_ROOT}/IP内容生产/对应环节目录`;
  return "AI 完成后会在结果中告诉你保存位置";
}

function getEnabledBusinessModules() {
  return ENABLED_BUSINESS_MODULES.map((item) => ({ ...item }));
}

function isWorkbenchModuleEnabled(moduleId) {
  return ENABLED_BUSINESS_MODULES.some((item) => item.id === String(moduleId || ""));
}

function normalizeWorkflowInput(params) {
  return (Array.isArray(params) ? params : []).map((item) => {
    const normalized = {
      key: String(item?.key || "参数").trim() || "参数",
      value: String(item?.value || "").trim()
    };
    if (item?.required === true) normalized.required = true;
    if (item?.requiredGroup) normalized.requiredGroup = String(item.requiredGroup);
    if (item?.pathKind) normalized.pathKind = String(item.pathKind);
    return normalized;
  });
}

function buildWorkflowTask(details = {}) {
  const workflow = String(details.workflow || "").trim();
  return {
    workflow,
    title: String(details.title || "执行当前任务").trim() || "执行当前任务",
    params: normalizeWorkflowInput(details.params),
    expectedOutput: String(details.expectedOutput || inferExpectedOutput(workflow)).trim(),
    prompt: String(details.prompt || "").trim()
  };
}

module.exports = {
  validateWorkflowParams,
  inferExpectedOutput,
  getEnabledBusinessModules,
  isWorkbenchModuleEnabled,
  normalizeWorkflowInput,
  buildWorkflowTask
};
