function isWithin(timestamp, start, end) {
  return Number(timestamp) >= start && Number(timestamp) < end;
}

function getEffectiveConversationTimestamp(item) {
  return Math.max(
    Number(item?.lastResponseAt) || 0,
    Number(item?.updatedAt) || 0,
    Number(item?.createdAt) || 0
  );
}

function buildConversationMetrics(snapshot, nowValue = Date.now()) {
  const available = Boolean(snapshot?.available);
  const conversations = available && Array.isArray(snapshot.conversations)
    ? snapshot.conversations
    : [];
  const openTabs = available && Array.isArray(snapshot.openTabs) ? snapshot.openTabs : [];
  const now = new Date(nowValue);
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
  const partial = Boolean(snapshot?.partial || conversations.some((item) => !item.messagesKnown));
  const messageTotal = (field) => conversations.reduce(
    (sum, item) => sum + (Number(item?.[field]) || 0),
    0
  );
  const todayMessageTotal = (field) => conversations.reduce(
    (sum, item) => sum + (Array.isArray(item?.[field])
      ? item[field].filter((timestamp) => isWithin(timestamp, dayStart, dayEnd)).length
      : 0),
    0
  );

  return {
    available,
    partial,
    conversationTotal: available ? conversations.length : null,
    todayConversationTotal: available
      ? conversations.filter((item) => isWithin(getEffectiveConversationTimestamp(item), dayStart, dayEnd)).length
      : null,
    openConversationTotal: available ? openTabs.length : null,
    streamingConversationTotal: available
      ? openTabs.filter((item) => item?.isStreaming).length
      : null,
    userMessageTotal: available && !partial ? messageTotal("userMessageCount") : null,
    assistantMessageTotal: available && !partial ? messageTotal("assistantMessageCount") : null,
    todayUserMessageTotal: available && !partial ? todayMessageTotal("userMessageTimestamps") : null,
    todayAssistantMessageTotal: available && !partial ? todayMessageTotal("assistantMessageTimestamps") : null,
    latestUpdatedAt: available
      ? conversations.reduce((latest, item) => Math.max(latest, getEffectiveConversationTimestamp(item)), 0)
      : 0
  };
}

function buildConversationTrend(snapshot, days = 7, nowValue = Date.now()) {
  const rangeDays = Number(days) === 30 ? 30 : 7;
  const available = Boolean(snapshot?.available);
  const now = new Date(nowValue);
  const end = Number.isNaN(now.getTime())
    ? new Date()
    : new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const points = Array.from({ length: rangeDays }, (_, index) => {
    const date = new Date(
      end.getFullYear(),
      end.getMonth(),
      end.getDate() - (rangeDays - 1 - index)
    );
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return {
      dateKey: `${date.getFullYear()}-${month}-${day}`,
      label: `${month}/${day}`,
      timestamp: date.getTime(),
      value: 0
    };
  });
  const pointByDate = new Map(points.map((point) => [point.dateKey, point]));
  let total = 0;

  if (available) {
    const conversations = Array.isArray(snapshot?.conversations) ? snapshot.conversations : [];
    for (const item of conversations) {
      const timestamp = getEffectiveConversationTimestamp(item);
      if (!timestamp) continue;
      const date = new Date(timestamp);
      if (Number.isNaN(date.getTime())) continue;
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const day = String(date.getDate()).padStart(2, "0");
      const point = pointByDate.get(`${date.getFullYear()}-${month}-${day}`);
      if (!point) continue;
      point.value += 1;
      total += 1;
    }
  }

  return {
    available,
    days: rangeDays,
    points,
    values: points.map((point) => point.value),
    total: available ? total : null,
    startLabel: points[0]?.label || "--",
    endLabel: points.at(-1)?.label || "--",
    empty: available ? total === 0 : true
  };
}

module.exports = { buildConversationMetrics, buildConversationTrend };
